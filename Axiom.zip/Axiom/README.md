# Axiom — AI Agent Runtime

> **LLM provides intelligence. Runtime provides trust.**

Axiom 是一个可扩展、自演化、高可靠性的 AI Agent Runtime。它不是简单的聊天机器人，而是位于模型与现实环境之间的控制层。

## 核心设计理念

### Evidence-Driven
系统不因模型认为正确就执行。关键行为必须基于工具结果、文件变化、测试结果和权限状态。

### 模型不拥有最终权限
LLM 负责推理、规划、生成方案。Runtime 负责执行、权限、安全、状态管理。

## 架构

```
User
 |
CLI
 |
Runtime API
 |
Event Bus (中央事件总线)
 |
+-----------------+------------------+------------------+
|                 |                  |                  |
Agent Engine     Skill System      Tool System       Policy Engine
|                 |                  |                  |
+-----------------+------------------+------------------+
|
Model Adapter (抽象接口)
|
Claude / GPT / DeepSeek / Ollama
```

## 功能

- **多模型支持**: Anthropic Claude, OpenAI GPT, DeepSeek, Ollama/LlamaCpp
- **Event Bus**: 所有模块通过事件通信，支持回放和调试
- **Agent 引擎**: Agent 状态机 (Created→Planning→Executing→Verifying→Completed)
- **Skill 系统**: 可复用的能力模块，支持 Draft→Candidate→Validated→Active→Deprecated 生命周期
- **Tool 系统**: 7 个内置工具 + Sandbox 安全执行
- **Policy Engine**: Constitution 核心规则 + 能力式权限控制
- **Token 追踪**: 实时 token 统计和多模型费用估算
- **Git 集成**: 仓库状态检测、分支管理

## 编译

### 依赖

- GCC 12+ / Clang 15+ (C++17)
- CMake 3.16+
- libcurl-dev

所有第三方库已内置（nlohmann/json），无需网络下载。

### 编译步骤

```bash
mkdir build && cd build
cmake ..
make -j$(nproc)
```

## 使用

### 交互模式

```bash
./axiom
```

进入配置向导，选择 AI 提供商、输入 API Key、设置工作目录。

### 对话命令

| 命令 | 说明 |
|------|------|
| `/help` | 显示帮助 |
| `/stats` | 查看 token 使用和费用 |
| `/git` | 查看 Git 仓库状态 |
| `/events` | 查看运行时事件 |
| `/skills` | 列出加载的 Skill |
| `/rules` | 显示 Constitution 规则 |
| `/clear` | 清屏 |
| `exit` / `quit` | 退出 |

### 自助检测

```bash
./axiom --self-test-all        # 运行所有自检
./axiom --self-test-event-bus  # EventBus 单元测试
./axiom --self-test-policy     # PolicyEngine 测试
./axiom --self-test-tools      # ToolSystem 往返测试
```

### 加载 Skill

```bash
./axiom --skill examples/skills/code_review.json
```

## 模块说明

| 模块 | 文件 | 职责 |
|------|------|------|
| EventBus | `event_bus.hpp/cpp` | 17 种事件类型，pub/sub + 异步队列 + 历史 |
| AgentEngine | `agent_engine.hpp/cpp` | Agent 生命周期、对话循环、Tool 编排 |
| SkillSystem | `skill_system.hpp/cpp` | Skill 加载、验证、激活、系统提示词生成 |
| ToolSystem | `tool_system.hpp/cpp` | ToolBroker + Sandbox + 7 个内置工具 |
| PolicyEngine | `policy_engine.hpp/cpp` | Constitution (4 核心规则) + 能力权限 |
| ModelAdapter | `model_adapter.hpp/cpp` | IModelAdapter 抽象接口 + 4 个适配器 |
| Runtime | `runtime.hpp/cpp` | 整合所有模块，生命周期管理 |
| CLI | `cli.hpp/cpp` | 交互式终端界面 + 配置向导 |
| TokenTracker | `token_tracker.hpp/cpp` | Token 统计 + 多模型价格表 |
| GitManager | `git_manager.hpp/cpp` | Git 状态、分支、同步管理 |

## Builtin Tools

| 工具 | 说明 |
|------|------|
| `read_file` | 读取文件内容（最大 1MB） |
| `write_file` | 创建或覆盖文件 |
| `edit_file` | 精确文本替换 |
| `list_directory` | 列出目录内容 |
| `run_terminal` | 安全沙盒命令执行 |
| `search_files` | 按文件名模式搜索 |
| `grep` | 正则搜索文件内容 |

## Constitution Rules

1. **No Secret Leakage**: 不向文件或命令写入凭据、API Key
2. **No Forgery**: 如实报告工具结果，不伪造测试通过
3. **No Bypass**: 不尝试绕过权限或沙盒
4. **Protect User Data**: 不执行破坏性操作

## Directory Structure

```
Axiom/
├── CMakeLists.txt
├── README.md
├── include/
│   ├── axiom/
│   │   ├── runtime.hpp
│   │   ├── event_bus.hpp
│   │   ├── agent_engine.hpp
│   │   ├── skill_system.hpp
│   │   ├── tool_system.hpp
│   │   ├── policy_engine.hpp
│   │   ├── model_adapter.hpp
│   │   ├── cli.hpp
│   │   ├── token_tracker.hpp
│   │   └── git_manager.hpp
│   └── nlohmann/
│       └── json.hpp          # 内置单头文件 JSON 库
├── src/
│   ├── main.cpp
│   ├── runtime.cpp
│   ├── event_bus.cpp
│   ├── agent_engine.cpp
│   ├── skill_system.cpp
│   ├── tool_system.cpp
│   ├── policy_engine.cpp
│   ├── model_adapter.cpp
│   ├── adapters/
│   │   └── claude_adapter.cpp  # 所有 4 个适配器实现
│   ├── cli.cpp
│   ├── token_tracker.cpp
│   └── git_manager.cpp
└── examples/
    └── skills/
        └── code_review.json
```

## License

MIT License
