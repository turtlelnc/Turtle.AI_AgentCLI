#include "axiom/tool_system.hpp"
#include <fstream>
#include <sstream>
#include <cstdio>
#include <array>
#include <algorithm>
#include <regex>

namespace axiom {

// ──────────────────────────────────────────────────────
// Sandbox
// ──────────────────────────────────────────────────────

Sandbox::Sandbox() {
    allowed_prefixes_ = {
        "ls ", "cat ", "head ", "tail ", "grep ", "find ",
        "pwd", "whoami", "date", "echo ", "wc ", "git ",
        "npm ", "make ", "cmake ", "g++ ", "gcc ", "clang",
        "python", "python3", "node ", "cargo ", "go ",
        "diff ", "patch ", "sed ", "awk ", "sort ", "uniq ",
        "du ", "df ", "ps ", "kill ", "curl ", "wget ",
        "./", "mkdir ", "touch ", "cp ", "mv ", "rm ", "chmod ",
        "tar ", "zip ", "unzip", "docker ", "pip ", "pip3 ",
        "ssh ", "scp "
    };

    dangerous_patterns_ = {
        "rm -rf /", "rm -rf ~", "rm -rf /", "sudo ", "chmod 777 /",
        "dd if=", "> /dev/sda", "mkfs", "fdisk", "shutdown",
        "reboot", "halt", ":(){:|:&};:", "> /etc/", "> ~/.ssh/",
        "chown -R /", "> /boot/", "> /sys/", "> /proc/",
        "wget", "curl.*|.*sh", "> /etc/passwd"
    };
}

bool Sandbox::isAllowed(const std::string& command) const {
    if (isDangerous(command)) return false;

    for (const auto& prefix : allowed_prefixes_) {
        if (command.find(prefix) == 0 || command == prefix.substr(0, prefix.length()-1)) {
            return true;
        }
    }
    return false;
}

bool Sandbox::isDangerous(const std::string& command) const {
    for (const auto& pattern : dangerous_patterns_) {
        if (command.find(pattern) != std::string::npos) return true;
    }
    return false;
}

std::string Sandbox::blockReason(const std::string& command) const {
    if (isDangerous(command)) {
        for (const auto& pattern : dangerous_patterns_) {
            if (command.find(pattern) != std::string::npos)
                return "Dangerous pattern blocked: " + pattern;
        }
    }
    for (const auto& prefix : allowed_prefixes_) {
        if (command.find(prefix) == 0) return "";
    }
    return "Command not in allowed-safe-subset. Add prefix to whitelist.";
}

std::string Sandbox::wrap(const std::string& command) const {
    // Future: wrap with bubblewrap/firejail
    return command;
}

void Sandbox::addAllowedPrefix(const std::string& prefix) {
    allowed_prefixes_.push_back(prefix);
}

void Sandbox::addBlockedPattern(const std::string& pattern) {
    dangerous_patterns_.push_back(pattern);
}

// ──────────────────────────────────────────────────────
// ToolBroker
// ──────────────────────────────────────────────────────

ToolBroker::ToolBroker(EventBus& bus) : event_bus_(bus) {
    registerBuiltinTools();
}

void ToolBroker::registerTool(const ToolDefinition& tool) {
    tools_.push_back(tool);
    event_bus_.publish({EventType::SkillLoaded, "ToolBroker",
                        {{"tool_name", tool.name}}});
}

void ToolBroker::registerBuiltinTools() {
    using namespace std::placeholders;

    registerTool({"read_file", "Read file contents (max 1MB). Returns content with line numbers.",
                  nlohmann::json::parse(R"({"type":"object","properties":{"path":{"type":"string","description":"File path to read"}},"required":["path"]})"),
                  [this](const nlohmann::json& a) { return toolReadFile(a); }});

    registerTool({"write_file", "Write content to a file (creates or overwrites).",
                  nlohmann::json::parse(R"({"type":"object","properties":{"path":{"type":"string","description":"Target file path"},"content":{"type":"string","description":"Content to write"}},"required":["path","content"]})"),
                  [this](const nlohmann::json& a) { return toolWriteFile(a); }});

    registerTool({"edit_file", "Edit file by replacing exact text match.",
                  nlohmann::json::parse(R"({"type":"object","properties":{"path":{"type":"string","description":"File path"},"old_text":{"type":"string","description":"Text to find"},"new_text":{"type":"string","description":"Replacement text"}},"required":["path","old_text","new_text"]})"),
                  [this](const nlohmann::json& a) { return toolEditFile(a); }});

    registerTool({"list_directory", "List contents of a directory.",
                  nlohmann::json::parse(R"({"type":"object","properties":{"path":{"type":"string","description":"Directory path"}},"required":["path"]})"),
                  [this](const nlohmann::json& a) { return toolListDirectory(a); }});

    registerTool({"run_terminal", "Execute shell command (safety-restricted).",
                  nlohmann::json::parse(R"({"type":"object","properties":{"command":{"type":"string","description":"Shell command"}},"required":["command"]})"),
                  [this](const nlohmann::json& a) { return toolRunTerminal(a); }});

    registerTool({"search_files", "Search files by name pattern.",
                  nlohmann::json::parse(R"({"type":"object","properties":{"pattern":{"type":"string","description":"File name pattern"},"directory":{"type":"string","description":"Search root"}},"required":["pattern"]})"),
                  [this](const nlohmann::json& a) { return toolSearchFiles(a); }});

    registerTool({"grep", "Search file contents using regex pattern.",
                  nlohmann::json::parse(R"({"type":"object","properties":{"pattern":{"type":"string","description":"Regex pattern"},"path":{"type":"string","description":"File or directory to search"}},"required":["pattern","path"]})"),
                  [this](const nlohmann::json& a) { return toolGrep(a); }});
}

ToolResult ToolBroker::execute(const std::string& name, const nlohmann::json& params) {
    // Guard against null params
    const nlohmann::json& safe_params = params.is_null()
        ? nlohmann::json::object() : params;

    auto start = std::chrono::steady_clock::now();

    event_bus_.publish({EventType::ToolPreCall, "ToolBroker",
                        {{"tool", name}, {"params", params}}});

    ToolResult result;
    result.success = false;

    for (const auto& tool : tools_) {
        if (tool.name == name) {
            try {
                result.data = tool.handler(safe_params);
                result.success = result.data.value("success", false);
                result.output = result.data.value("output",
                    result.data.value("content",
                        result.data.value("error",
                            result.data.dump())));
            } catch (const std::exception& e) {
                result.data = {{"success", false}, {"error", e.what()}};
                result.output = e.what();
            }
            break;
        }
    }

    if (!result.success && result.output.empty()) {
        result.data = {{"success", false}, {"error", "Tool not found: " + name}};
        result.output = "Tool not found: " + name;
    }

    auto end = std::chrono::steady_clock::now();
    result.duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);

    event_bus_.publish({EventType::ToolPostCall, "ToolBroker",
                        {{"tool", name}, {"success", result.success},
                         {"duration_ms", result.duration.count()}}});

    return result;
}

void ToolBroker::cancel(const std::string& callId) {
    event_bus_.publish({EventType::ToolCancelled, "ToolBroker", {{"call_id", callId}}});
}

std::vector<ToolSchema> ToolBroker::getToolsSchema() const {
    std::vector<ToolSchema> schema;
    for (const auto& tool : tools_) {
        schema.push_back({tool.name, tool.description, tool.parameters});
    }
    return schema;
}

bool ToolBroker::hasTool(const std::string& name) const {
    for (const auto& t : tools_)
        if (t.name == name) return true;
    return false;
}

const ToolDefinition* ToolBroker::getTool(const std::string& name) const {
    for (const auto& t : tools_)
        if (t.name == name) return &t;
    return nullptr;
}

// ─── Helper: safe path resolution ────────────────────
static std::string safePath(const std::string& path) {
    // Prevent path traversal
    if (path.find("..") != std::string::npos) return "";
    return path;
}

static bool isAbsolutePath(const std::string& path) {
    return !path.empty() && path[0] == '/';
}

std::string ToolBroker::executeShell(const std::string& cmd) {
    std::array<char, 256> buffer;
    std::string result;
    FILE* pipe = popen((cmd + " 2>&1").c_str(), "r");
    if (!pipe) return "Error: Failed to execute";
    while (fgets(buffer.data(), buffer.size(), pipe) != nullptr)
        result += buffer.data();
    pclose(pipe);
    return result;
}

bool ToolBroker::writeFileContent(const std::string& path, const std::string& content) {
    try {
        std::ofstream file(path, std::ios::out | std::ios::trunc);
        if (!file.is_open()) return false;
        file << content;
        return true;
    } catch (...) { return false; }
}

std::string ToolBroker::readFileContent(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) return "";
    std::stringstream buf;
    buf << file.rdbuf();
    return buf.str();
}

// ─── Builtin tool implementations ────────────────────

nlohmann::json ToolBroker::toolReadFile(const nlohmann::json& args) {
    std::string path = safePath(args.value("path", ""));
    if (path.empty()) return {{"success", false}, {"error", "Invalid path"}};

    std::string content = readFileContent(path);
    if (content.empty() && !std::ifstream(path).good())
        return {{"success", false}, {"error", "Cannot read: " + path}};

    // Truncate at 1MB
    constexpr size_t kMaxRead = 1024 * 1024;
    if (content.size() > kMaxRead)
        content = content.substr(0, kMaxRead) + "\n... [truncated at 1MB]";

    return {{"success", true}, {"content", content}, {"size", content.size()}};
}

nlohmann::json ToolBroker::toolWriteFile(const nlohmann::json& args) {
    std::string path = safePath(args.value("path", ""));
    if (path.empty()) return {{"success", false}, {"error", "Invalid path"}};
    std::string content = args.value("content", "");

    if (writeFileContent(path, content)) {
        event_bus_.publish({EventType::FileChanged, "ToolBroker", {{"path", path}}});
        return {{"success", true}, {"message", "Written: " + path}};
    }
    return {{"success", false}, {"error", "Cannot write: " + path}};
}

nlohmann::json ToolBroker::toolEditFile(const nlohmann::json& args) {
    std::string path = safePath(args.value("path", ""));
    if (path.empty()) return {{"success", false}, {"error", "Invalid path"}};
    std::string old_text = args.value("old_text", "");
    std::string new_text = args.value("new_text", "");

    std::string content = readFileContent(path);
    if (content.empty()) return {{"success", false}, {"error", "Cannot read: " + path}};

    size_t pos = content.find(old_text);
    if (pos == std::string::npos)
        return {{"success", false}, {"error", "Text not found in file"}};

    content.replace(pos, old_text.length(), new_text);
    if (writeFileContent(path, content)) {
        event_bus_.publish({EventType::FileChanged, "ToolBroker", {{"path", path}}});
        return {{"success", true}, {"message", "Edited: " + path}};
    }
    return {{"success", false}, {"error", "Cannot write: " + path}};
}

nlohmann::json ToolBroker::toolListDirectory(const nlohmann::json& args) {
    std::string path = safePath(args.value("path", "."));
    if (path.empty()) return {{"success", false}, {"error", "Invalid path"}};

    std::string output = executeShell("ls -la \"" + path + "\"");
    return {{"success", true}, {"listing", output}};
}

nlohmann::json ToolBroker::toolRunTerminal(const nlohmann::json& args) {
    std::string cmd = args.value("command", "");
    if (cmd.empty()) return {{"success", false}, {"error", "Missing command"}};

    if (!sandbox_.isAllowed(cmd)) {
        std::string reason = sandbox_.blockReason(cmd);
        event_bus_.publish({EventType::PermissionDenied, "ToolBroker",
                            {{"command", cmd}, {"reason", reason}}});
        return {{"success", false}, {"error", "Blocked: " + reason}};
    }

    std::string output = executeShell(sandbox_.wrap(cmd));
    return {{"success", true}, {"output", output}};
}

nlohmann::json ToolBroker::toolSearchFiles(const nlohmann::json& args) {
    std::string pattern = args.value("pattern", "*");
    std::string dir = safePath(args.value("directory", "."));
    if (dir.empty()) dir = ".";

    std::string output = executeShell("find \"" + dir + "\" -name \"" + pattern + "\" -type f 2>/dev/null | head -50");
    return {{"success", true}, {"files", output}};
}

nlohmann::json ToolBroker::toolGrep(const nlohmann::json& args) {
    std::string pattern = args.value("pattern", "");
    std::string path = safePath(args.value("path", "."));
    if (pattern.empty()) return {{"success", false}, {"error", "Missing pattern"}};
    if (path.empty()) path = ".";

    std::string output = executeShell("grep -rn --color=never \"" + pattern + "\" \"" + path + "\" 2>/dev/null | head -50");
    return {{"success", true}, {"matches", output}};
}

} // namespace axiom
