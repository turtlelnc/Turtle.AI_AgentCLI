#include "axiom/markdown.hpp"
#include <regex>
#include <sstream>
#include <algorithm>

namespace axiom {

MarkdownRenderer::MarkdownRenderer() = default;

// ─── 块级解析 ────────────────────────────────────────

std::vector<MarkdownRenderer::Block> MarkdownRenderer::parseBlocks(const std::string& text) const {
    std::vector<Block> blocks;
    std::istringstream stream(text);
    std::string line;
    Block current;
    current.type = BlockType::Paragraph;

    auto flushBlock = [&]() {
        if (!current.lines.empty()) {
            blocks.push_back(current);
            current.lines.clear();
        }
        current.type = BlockType::Paragraph;
        current.header_level = 0;
        current.language.clear();
    };

    bool in_code_block = false;
    std::string code_lang;

    while (std::getline(stream, line)) {
        // Trim trailing \r
        if (!line.empty() && line.back() == '\r') line.pop_back();

        // ── Code block fence ──
        if (line.rfind("```", 0) == 0) {
            if (!in_code_block) {
                flushBlock();
                in_code_block = true;
                code_lang = line.substr(3);
                // Trim whitespace from language
                code_lang.erase(0, code_lang.find_first_not_of(" \t"));
                current.type = BlockType::CodeBlock;
                current.language = code_lang;
            } else {
                flushBlock();
                in_code_block = false;
            }
            continue;
        }

        if (in_code_block) {
            current.lines.push_back(line);
            continue;
        }

        // ── Horizontal rule ──
        if (line == "---" || line == "***" || line == "___" || line == "* * *") {
            flushBlock();
            current.type = BlockType::HRule;
            current.lines.push_back("");
            flushBlock();
            continue;
        }

        // ── Header ──
        if (line.rfind("# ", 0) == 0) {
            flushBlock();
            current.type = BlockType::Header;
            current.header_level = 1;
            current.lines.push_back(line.substr(2));
            flushBlock();
            continue;
        }
        if (line.rfind("## ", 0) == 0) {
            flushBlock();
            current.type = BlockType::Header;
            current.header_level = 2;
            current.lines.push_back(line.substr(3));
            flushBlock();
            continue;
        }
        if (line.rfind("### ", 0) == 0) {
            flushBlock();
            current.type = BlockType::Header;
            current.header_level = 3;
            current.lines.push_back(line.substr(4));
            flushBlock();
            continue;
        }
        if (line.rfind("#### ", 0) == 0) {
            flushBlock();
            current.type = BlockType::Header;
            current.header_level = 4;
            current.lines.push_back(line.substr(5));
            flushBlock();
            continue;
        }

        // ── Blockquote ──
        if (line.rfind("> ", 0) == 0 || line == ">") {
            if (current.type != BlockType::Blockquote) {
                flushBlock();
                current.type = BlockType::Blockquote;
            }
            current.lines.push_back(line == ">" ? "" : line.substr(2));
            continue;
        }

        // ── Unordered list ──
        std::regex ul_re(R"(^[\s]*[-*+]\s+(.+))");
        std::smatch ul_match;
        if (std::regex_match(line, ul_match, ul_re)) {
            if (current.type != BlockType::ListItem) {
                flushBlock();
                current.type = BlockType::ListItem;
            }
            current.lines.push_back(ul_match[1].str());
            continue;
        }

        // ── Ordered list ──
        std::regex ol_re(R"(^[\s]*\d+\.\s+(.+))");
        std::smatch ol_match;
        if (std::regex_match(line, ol_match, ol_re)) {
            if (current.type != BlockType::OrderedItem) {
                flushBlock();
                current.type = BlockType::OrderedItem;
            }
            current.lines.push_back(ol_match[1].str());
            continue;
        }

        // ── Table separator line (|---|:---|) — skip silently ──
        if (line.find('|') != std::string::npos
            && line.find_first_not_of("|-: \t") == std::string::npos) {
            // This is a table separator, keep current table type
            continue;
        }

        // ── Table row ──
        if (line.find('|') != std::string::npos) {
            if (current.type != BlockType::Table) {
                flushBlock();
                current.type = BlockType::Table;
            }
            current.lines.push_back(line);
            continue;
        }

        // ── Empty line: paragraph separator ──
        if (line.empty() || line.find_first_not_of(" \t") == std::string::npos) {
            flushBlock();
            continue;
        }

        // ── Normal paragraph text ──
        if (current.type != BlockType::Paragraph) {
            flushBlock();
        }
        current.type = BlockType::Paragraph;
        current.lines.push_back(line);
    }

    flushBlock();
    return blocks;
}

// ─── 行内渲染 ────────────────────────────────────────

std::string MarkdownRenderer::renderInline(const std::string& text) const {
    std::string result;
    result.reserve(text.size() + 64);

    size_t i = 0;
    while (i < text.size()) {
        // Bold: **text** or __text__
        if (i + 3 < text.size() && text[i] == '*' && text[i+1] == '*') {
            size_t end = text.find("**", i + 2);
            if (end != std::string::npos) {
                result += Ansi::Bold;
                result += text.substr(i + 2, end - i - 2);
                result += Ansi::Reset;
                i = end + 2;
                continue;
            }
        }
        if (i + 3 < text.size() && text[i] == '_' && text[i+1] == '_') {
            size_t end = text.find("__", i + 2);
            if (end != std::string::npos) {
                result += Ansi::Bold;
                result += text.substr(i + 2, end - i - 2);
                result += Ansi::Reset;
                i = end + 2;
                continue;
            }
        }

        // Italic: *text* or _text_ (but not **)
        if (i + 1 < text.size() && text[i] == '*' && text[i+1] != '*') {
            size_t end = text.find('*', i + 1);
            if (end != std::string::npos && end > i + 1) {
                result += Ansi::Italic;
                result += text.substr(i + 1, end - i - 1);
                result += Ansi::Reset;
                i = end + 1;
                continue;
            }
        }
        if (i + 1 < text.size() && text[i] == '_' && text[i+1] != '_') {
            size_t end = text.find('_', i + 1);
            if (end != std::string::npos && end > i + 1) {
                result += Ansi::Italic;
                result += text.substr(i + 1, end - i - 1);
                result += Ansi::Reset;
                i = end + 1;
                continue;
            }
        }

        // Inline code: `text`
        if (text[i] == '`') {
            size_t end = text.find('`', i + 1);
            if (end != std::string::npos) {
                result += Ansi::Cyan;
                result += text.substr(i + 1, end - i - 1);
                result += Ansi::Reset;
                i = end + 1;
                continue;
            }
        }

        // Regular character
        result += text[i];
        ++i;
    }

    return result;
}

// ─── 块级渲染 ────────────────────────────────────────

std::string MarkdownRenderer::renderCodeBlock(const Block& block) const {
    std::string out;
    // Language label
    std::string lang = block.language.empty() ? "code" : block.language;
    out += std::string(Ansi::Dim) + "+- " + lang + " " +
           std::string(width_ - 4 - static_cast<int>(lang.size()), '-') + Ansi::Reset + "\n";

    for (const auto& line : block.lines) {
        out += std::string(Ansi::Dim) + "| " + Ansi::Reset;
        // Truncate per line
        std::string display = line;
        if (static_cast<int>(display.size()) > width_ - 4)
            display = display.substr(0, width_ - 7) + "...";
        out += display;
        out += std::string(width_ - 3 - static_cast<int>(display.size()), ' ');
        out += std::string(Ansi::Dim) + "|" + Ansi::Reset + "\n";
    }

    out += std::string(Ansi::Dim) + "+" + std::string(width_ - 1, '-') + Ansi::Reset + "\n";
    return out;
}

std::string MarkdownRenderer::renderListItem(const Block& block, int order) const {
    std::string out;
    for (const auto& line : block.lines) {
        if (order > 0) {
            out += "  " + std::string(Ansi::Green) + std::to_string(order++) + "." + Ansi::Reset + " ";
        } else {
            out += "  " + Ansi::bullet() + " ";
        }
        // Word-wrap
        std::string rendered = renderInline(line);
        int prefix_len = 5;
        size_t pos = 0;
        bool first = true;
        while (pos < rendered.size()) {
            if (!first) out += std::string(prefix_len, ' ');
            first = false;
            size_t chunk = std::min(size_t(width_ - prefix_len - 2), rendered.size() - pos);
            // Try to break at word boundary
            if (pos + chunk < rendered.size()) {
                size_t space = rendered.rfind(' ', pos + chunk);
                if (space != std::string::npos && space > pos) chunk = space - pos;
            }
            out += rendered.substr(pos, chunk) + "\n";
            pos += chunk;
            while (pos < rendered.size() && rendered[pos] == ' ') pos++;
        }
    }
    return out;
}

std::string MarkdownRenderer::renderTable(const Block& block) const {
    if (block.lines.size() < 2) return "";

    // Parse header row and separator row
    auto splitCols = [](const std::string& row) -> std::vector<std::string> {
        std::vector<std::string> cols;
        size_t start = 0;
        // Skip leading |
        if (!row.empty() && row[0] == '|') start = 1;
        while (start < row.size()) {
            size_t end = row.find('|', start);
            if (end == std::string::npos) {
                std::string col = row.substr(start);
                // Trim
                while (!col.empty() && col.back() == ' ') col.pop_back();
                while (!col.empty() && col.front() == ' ') col.erase(0, 1);
                if (!col.empty()) cols.push_back(col);
                break;
            }
            std::string col = row.substr(start, end - start);
            while (!col.empty() && col.back() == ' ') col.pop_back();
            while (!col.empty() && col.front() == ' ') col.erase(0, 1);
            cols.push_back(col);
            start = end + 1;
        }
        return cols;
    };

    auto header_cols = splitCols(block.lines[0]);
    int ncols = header_cols.size();
    if (ncols == 0) return "";

    // Calculate column widths
    std::vector<int> widths(ncols, 3);
    for (size_t r = 0; r < block.lines.size(); ++r) {
        auto cols = splitCols(block.lines[r]);
        for (int c = 0; c < ncols && c < static_cast<int>(cols.size()); ++c) {
            widths[c] = std::max(widths[c], static_cast<int>(cols[c].size()));
        }
    }

    // Clamp total width
    int total_width = 1; // left border
    for (int w : widths) total_width += w + 3; // " col "
    if (total_width > width_) {
        int excess = total_width - width_;
        for (int c = ncols - 1; c >= 0 && excess > 0; --c) {
            int reduction = std::min(excess, widths[c] - 3);
            if (reduction > 0) { widths[c] -= reduction; excess -= reduction; }
        }
    }

    std::string out;

    auto drawLine = [&](char left, char mid, char right, char fill) {
        out += std::string(Ansi::Dim);
        out += left;
        for (int c = 0; c < ncols; ++c) {
            out += std::string(widths[c] + 2, fill);
            out += (c < ncols - 1) ? mid : right;
        }
        out += std::string(Ansi::Reset) + "\n";
    };

    drawLine('+', '+', '+', '-');

    // Header row
    out += std::string(Ansi::Dim) + "|" + Ansi::Reset;
    for (int c = 0; c < ncols; ++c) {
        out += " " + Ansi::bold(renderInline(header_cols[c]));
        out += std::string(widths[c] - static_cast<int>(header_cols[c].size()), ' ');
        out += std::string(Ansi::Dim) + " |" + Ansi::Reset;
    }
    out += "\n";

    drawLine('+', '+', '+', '-');

    // Data rows (skip header and separator)
    for (size_t r = 1; r < block.lines.size(); ++r) {
        // Skip separator line
        if (block.lines[r].find("---") != std::string::npos &&
            block.lines[r].find_first_not_of("|-: \t") == std::string::npos)
            continue;

        auto cols = splitCols(block.lines[r]);
        out += std::string(Ansi::Dim) + "|" + Ansi::Reset;
        for (int c = 0; c < ncols; ++c) {
            std::string cell = c < static_cast<int>(cols.size()) ? renderInline(cols[c]) : "";
            out += " " + cell;
            int cell_len = c < static_cast<int>(cols.size()) ? static_cast<int>(cols[c].size()) : 0;
            if (cell_len < widths[c]) out += std::string(widths[c] - cell_len, ' ');
            out += std::string(Ansi::Dim) + " |" + Ansi::Reset;
        }
        out += "\n";
    }

    drawLine('+', '+', '+', '-');
    return out;
}

std::string MarkdownRenderer::renderBlockquote(const Block& block) const {
    std::string out;
    for (const auto& line : block.lines) {
        out += std::string(Ansi::Dim) + "| " + Ansi::Reset;
        out += renderInline(line) + "\n";
    }
    return out;
}

std::string MarkdownRenderer::renderBlock(const Block& block) const {
    switch (block.type) {
        case BlockType::Header: {
            std::string prefix;
            std::string style;
            if (block.header_level == 1) {
                prefix = "\n";
                style = std::string(Ansi::Bold) + Ansi::Cyan;
            } else if (block.header_level == 2) {
                prefix = "\n";
                style = std::string(Ansi::Bold) + Ansi::Blue;
            } else {
                style = Ansi::Bold;
            }
            return prefix + style + renderInline(block.lines[0]) + Ansi::Reset + "\n";
        }
        case BlockType::CodeBlock:
            return renderCodeBlock(block);
        case BlockType::ListItem:
            return renderListItem(block);
        case BlockType::OrderedItem:
            return renderListItem(block, 1);
        case BlockType::Blockquote:
            return renderBlockquote(block);
        case BlockType::HRule:
            return Ansi::hr() + "\n";
        case BlockType::Table:
            return renderTable(block);
        case BlockType::Paragraph: {
            std::string out;
            for (const auto& line : block.lines) {
                std::string rendered = renderInline(line);
                // Word-wrap
                size_t pos = 0;
                while (pos < rendered.size()) {
                    size_t chunk = std::min(size_t(width_ - 2), rendered.size() - pos);
                    if (pos + chunk < rendered.size()) {
                        size_t space = rendered.rfind(' ', pos + chunk);
                        if (space != std::string::npos && space > pos) chunk = space - pos;
                    }
                    out += " " + rendered.substr(pos, chunk) + "\n";
                    pos += chunk;
                    while (pos < rendered.size() && rendered[pos] == ' ') pos++;
                }
            }
            return out + "\n";
        }
    }
    return "";
}

// ─── 主渲染入口 ──────────────────────────────────────

std::string MarkdownRenderer::render(const std::string& markdown) const {
    auto blocks = parseBlocks(markdown);
    std::string out;
    for (const auto& block : blocks) {
        out += renderBlock(block);
    }
    return out;
}

} // namespace axiom
