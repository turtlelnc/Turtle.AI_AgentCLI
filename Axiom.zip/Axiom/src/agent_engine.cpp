#include "axiom/agent_engine.hpp"
#include "axiom/token_tracker.hpp"
#include <random>
#include <sstream>
#include <iostream>
#include <regex>

namespace axiom {

AgentEngine::AgentEngine(EventBus& bus, ToolBroker& tools, PolicyEngine& policy,
                         SkillSystem& skills, IModelAdapter& model)
    : event_bus_(bus), tools_(tools), policy_(policy),
      skills_(skills), model_adapter_(model) {}

// ─── ID generation ───────────────────────────────────

std::string AgentEngine::generateId() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static const char hex[] = "0123456789abcdef";
    std::string id("agent-");
    for (int i = 0; i < 8; ++i) id += hex[gen() % 16];
    return id;
}

// ─── Agent lifecycle ─────────────────────────────────

std::string AgentEngine::createAgent(const AgentConfig& config) {
    Agent agent;
    agent.id = generateId();
    agent.config = config;
    agent.state = AgentState::Created;

    agents_[agent.id] = agent;
    event_bus_.publish({EventType::AgentStarted, "AgentEngine",
                        {{"agent_id", agent.id}, {"goal", config.goal}}});
    return agent.id;
}

std::string AgentEngine::spawnSubAgent(const std::string& parent_id,
                                        const AgentConfig& config) {
    AgentConfig sub = config;
    if (sub.allowed_tools.empty()) {
        // Sub-agents get a restricted toolset by default
        sub.allowed_tools = {"read_file", "list_directory", "grep", "search_files"};
    }
    sub.max_turns = std::min(sub.max_turns, 20);  // Shorter leash for sub-agents

    std::string id = createAgent(sub);
    if (!id.empty()) {
        agents_[id].parent_id = parent_id;
    }
    return id;
}

void AgentEngine::transitionState(Agent& agent, AgentState new_state) {
    AgentState old = agent.state;
    agent.state = new_state;

    EventType evt;
    switch (new_state) {
        case AgentState::Executing:  evt = EventType::AgentStarted; break;
        case AgentState::Paused:     evt = EventType::AgentPaused; break;
        case AgentState::Completed:  evt = EventType::AgentCompleted; break;
        case AgentState::Failed:     evt = EventType::AgentFailed; break;
        default: return;
    }

    event_bus_.publish({evt, "AgentEngine",
                        {{"agent_id", agent.id}, {"from", agentStateName(old)},
                         {"to", agentStateName(new_state)}}});
}

// ─── System prompt ───────────────────────────────────

std::string AgentEngine::buildSystemPrompt(const Agent& agent) {
    std::string prompt = skills_.buildSystemPrompt(agent.config.skills);

    if (!agent.config.system_prompt_extra.empty()) {
        prompt += "\n# Additional Instructions\n" + agent.config.system_prompt_extra;
    }

    prompt += "\n# Current Task\n" + agent.config.goal + "\n";

    return prompt;
}

// ─── Permission check for tools ──────────────────────

bool AgentEngine::checkToolPermission(const Agent& agent, const std::string& tool_name) {
    // Map tool to capability
    Capability cap;
    if (tool_name == "read_file" || tool_name == "list_directory" ||
        tool_name == "search_files" || tool_name == "grep") {
        cap = Capability::FilesystemRead;
    } else if (tool_name == "write_file" || tool_name == "edit_file") {
        cap = Capability::FilesystemWrite;
    } else if (tool_name == "run_terminal") {
        cap = Capability::ProcessExecute;
    } else {
        return true;  // Unknown tool, let it through but log
    }

    std::string reason;
    if (!policy_.checkConstitution(tool_name, {}, reason)) {
        event_bus_.publish({EventType::PermissionDenied, "AgentEngine",
                            {{"agent_id", agent.id}, {"tool", tool_name},
                             {"reason", reason}}});
        return false;
    }

    return policy_.checkPermission(agent.id, cap);
}

// ─── Main agent loop (流式 + 观察者) ────────────────

void AgentEngine::runAgent(const std::string& id) {
    Agent* agent_ptr = getAgent(id);
    if (!agent_ptr) return;
    Agent& agent = *agent_ptr;

    transitionState(agent, AgentState::Executing);

    // Build initial messages
    agent.messages.clear();
    ChatMessage sys_msg;
    sys_msg.role = "system";
    sys_msg.content = buildSystemPrompt(agent);
    agent.messages.push_back(sys_msg);

    auto tools_schema = tools_.getToolsSchema();

    while (agent.turn_count < agent.config.max_turns && !interrupted_) {
        agent.turn_count++;

        // ── Streaming: 实时输出 AI 思考过程 ──
        bool thinking_started = false;
        ChatResponse response;

        response = model_adapter_.sendStreaming(
            api_key_, current_model_, agent.messages, tools_schema,
            [&](const std::string& chunk) {
                if (!thinking_started) {
                    thinking_started = true;
                }
                if (observer_.onThinking) {
                    observer_.onThinking(chunk);
                }
            });

        if (observer_.onThinkingComplete) {
            observer_.onThinkingComplete();
        }

        if (!response.success) {
            if (agent.turn_count > 1) {
                transitionState(agent, AgentState::Failed);
                return;
            }
            ChatMessage err_msg;
            err_msg.role = "user";
            err_msg.content = "Previous request failed: " + response.error_message + ". Please retry.";
            agent.messages.push_back(err_msg);
            continue;
        }

        total_input_tokens_ += response.input_tokens;
        total_output_tokens_ += response.output_tokens;
        agent.total_input_tokens += response.input_tokens;
        agent.total_output_tokens += response.output_tokens;

        // ── Cost callback ──
        if (observer_.onTurnComplete) {
            ModelPricing pricing = TokenTracker::getModelPrice(current_model_);
            double cost = (static_cast<double>(response.input_tokens) / 1000000.0) * pricing.input_price_per_1m +
                          (static_cast<double>(response.output_tokens) / 1000000.0) * pricing.output_price_per_1m;
            observer_.onTurnComplete(response.input_tokens, response.output_tokens, cost);
        }

        // Handle tool calls — 实时显示
        if (!response.tool_calls.empty()) {
            // Store assistant message with tool_calls
            ChatMessage assistant_msg;
            assistant_msg.role = "assistant";
            assistant_msg.content = response.content;
            assistant_msg.tool_calls = response.tool_calls;
            agent.messages.push_back(assistant_msg);

            // Execute each tool with observer callbacks
            bool is_claude = (model_adapter_.providerName().find("Claude") != std::string::npos);

            for (size_t i = 0; i < response.tool_calls.size(); ++i) {
                const auto& tc = response.tool_calls[i];

                // Permission check
                if (!agent.config.allowed_tools.empty()) {
                    bool found = false;
                    for (const auto& at : agent.config.allowed_tools) {
                        if (tc.name == at) { found = true; break; }
                    }
                    if (!found) continue;
                }
                if (!checkToolPermission(agent, tc.name)) continue;

                // ── Pre-call observer ──
                nlohmann::json params = tc.arguments.is_null() ? tc.input : tc.arguments;
                if (observer_.onToolPreCall) {
                    observer_.onToolPreCall(tc.name, params);
                }

                // Execute
                ToolResult result = tools_.execute(tc.name, params);

                // ── Post-call observer ──
                if (observer_.onToolPostCall) {
                    observer_.onToolPostCall(tc.name, result);
                }

                // Format result as message
                if (is_claude) {
                    nlohmann::json content_blocks = nlohmann::json::array();
                    nlohmann::json block;
                    block["type"] = "tool_result";
                    block["tool_use_id"] = tc.id;
                    block["content"] = result.success ? result.data.dump() : result.output;
                    if (!result.success) block["is_error"] = true;
                    content_blocks.push_back(block);
                    ChatMessage result_msg;
                    result_msg.role = "user";
                    result_msg.content_blocks = content_blocks;
                    agent.messages.push_back(result_msg);
                } else {
                    ChatMessage tool_msg;
                    tool_msg.role = "tool";
                    tool_msg.tool_call_id = tc.id;
                    tool_msg.content = result.data.dump();
                    agent.messages.push_back(tool_msg);
                }
            }

            continue;  // Loop back for model to process tool results
        }

        // No tool calls — agent is done
        ChatMessage final_msg;
        final_msg.role = "assistant";
        final_msg.content = response.content;
        agent.messages.push_back(final_msg);

        event_bus_.publish({EventType::AgentCompleted, "AgentEngine",
                            {{"agent_id", agent.id},
                             {"content", response.content},
                             {"turns", agent.turn_count}}});

        transitionState(agent, AgentState::Completed);
        return;
    }

    if (interrupted_) {
        transitionState(agent, AgentState::Paused);
    } else if (agent.turn_count >= agent.config.max_turns) {
        transitionState(agent, AgentState::Failed);
        event_bus_.publish({EventType::AgentFailed, "AgentEngine",
                            {{"reason", "max_turns_exceeded"}, {"agent_id", agent.id}}});
    }
}

void AgentEngine::pauseAgent(const std::string& id) {
    Agent* agent = getAgent(id);
    if (agent && agent->state == AgentState::Executing) {
        transitionState(*agent, AgentState::Paused);
    }
}

void AgentEngine::resumeAgent(const std::string& id) {
    Agent* agent = getAgent(id);
    if (agent && agent->state == AgentState::Paused) {
        transitionState(*agent, AgentState::Executing);
        runAgent(id);
    }
}

Agent* AgentEngine::getAgent(const std::string& id) {
    auto it = agents_.find(id);
    return it != agents_.end() ? &it->second : nullptr;
}

const Agent* AgentEngine::getAgent(const std::string& id) const {
    auto it = agents_.find(id);
    return it != agents_.end() ? &it->second : nullptr;
}

} // namespace axiom
