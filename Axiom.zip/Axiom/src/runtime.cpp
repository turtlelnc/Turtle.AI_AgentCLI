#include "axiom/runtime.hpp"
#include "axiom/markdown.hpp"
#include <iostream>
#include <thread>

namespace axiom {

// ──────────────────────────────────────────────────────
// Runtime
// ──────────────────────────────────────────────────────

Runtime::Runtime() = default;

Runtime::Runtime(const RuntimeConfig& config) : config_(config) {}

Runtime::~Runtime() {
    if (running_) shutdown();
}

bool Runtime::initialize(const RuntimeConfig& config) {
    config_ = config;

    // 1. Create Event Bus
    event_bus_ = std::make_unique<EventBus>();

    // 2. Create Policy Engine
    policy_engine_ = std::make_unique<PolicyEngine>(*event_bus_);

    // 3. Create Tool Broker
    tool_broker_ = std::make_unique<ToolBroker>(*event_bus_);

    // 4. Create Skill System
    skill_system_ = std::make_unique<SkillSystem>(*event_bus_);

    // 5. Load skills from directory if specified
    if (!config.skills_dir.empty()) {
        size_t loaded = skill_system_->loadSkillsFromDirectory(config.skills_dir);
        event_bus_->publish({EventType::SkillLoaded, "Runtime",
                             {{"count", static_cast<int>(loaded)},
                              {"source", config.skills_dir}}});
    }

    // 6. Activate default system skill
    if (!config.system_skill_name.empty()) {
        skill_system_->activateSkill(config.system_skill_name);
    }

    // 7. Create Model Adapter
    model_adapter_ = AdapterFactory::create(config.provider);
    if (!model_adapter_) {
        event_bus_->publish({EventType::RuntimeError, "Runtime",
                             {{"error", "Failed to create model adapter"}}});
        return false;
    }

    // 8. Create Agent Engine
    agent_engine_ = std::make_unique<AgentEngine>(
        *event_bus_, *tool_broker_, *policy_engine_, *skill_system_, *model_adapter_);
    agent_engine_->setApiKey(config.api_key);
    agent_engine_->setModel(config.model);

    // 9. Create Token Tracker
    token_tracker_ = std::make_unique<TokenTracker>();
    token_tracker_->setModel(config.model);

    // 10. Create Git Manager
    git_manager_ = std::make_unique<GitManager>();

    // Log startup event
    event_bus_->publish({EventType::RuntimeReady, "Runtime",
                         {{"provider", AdapterFactory::providerName(config.provider)},
                          {"model", config.model},
                          {"work_dir", config.work_dir}}});

    return true;
}

void Runtime::start() {
    running_ = true;
    event_bus_->publish({EventType::RuntimeStarting, "Runtime", {}});

    // Log available tools
    auto schema = tool_broker_->getToolsSchema();
    event_bus_->publish({EventType::RuntimeReady, "Runtime",
                         {{"tools_available", static_cast<int>(schema.size())}}});
}

void Runtime::shutdown() {
    running_ = false;
    event_bus_->publish({EventType::RuntimeStopping, "Runtime", {}});

    // Pump any remaining events
    event_bus_->pump();
}

std::string Runtime::processUserPrompt(const std::string& prompt) {
    if (!running_) return "Runtime not started";

    event_bus_->publish({EventType::UserPromptSubmitted, "Runtime",
                         {{"prompt_length", static_cast<int>(prompt.length())}}});

    // Create a single-turn agent for this prompt
    AgentConfig config;
    config.goal = prompt;
    config.model = config_.model;
    config.work_dir = config_.work_dir;
    config.max_turns = 50;

    // Load active skills
    for (const auto* skill : skill_system_->activeSkills()) {
        config.skills.push_back(skill->name);
    }

    std::string agent_id = agent_engine_->createAgent(config);

    // Grant default permissions
    policy_engine_->grantTemporary(agent_id, Capability::FilesystemRead,
                                    std::chrono::minutes(30));
    policy_engine_->grantTemporary(agent_id, Capability::FilesystemWrite,
                                    std::chrono::minutes(30));
    policy_engine_->grantTemporary(agent_id, Capability::ProcessExecute,
                                    std::chrono::minutes(30));

    // Run agent
    agent_engine_->runAgent(agent_id);

    const Agent* agent = agent_engine_->getAgent(agent_id);
    if (!agent) return "Agent execution failed";

    // Record tokens
    token_tracker_->recordTokens(agent->total_input_tokens,
                                  agent->total_output_tokens);

    // Find the last assistant message
    std::string result;
    for (auto it = agent->messages.rbegin(); it != agent->messages.rend(); ++it) {
        if (it->role == "assistant" && !it->content.empty()) {
            result = it->content;
            break;
        }
    }

    return result.empty() ? "Task completed (no textual output)" : result;
}

// ─── Self-tests ──────────────────────────────────────

bool Runtime::selfTestEventBus() {
    std::cout << "[SelfTest] EventBus..." << std::endl;

    int received = 0;
    auto id = event_bus_->subscribe(EventType::RuntimeReady,
        [&](const Event&) { received++; });

    event_bus_->publish({EventType::RuntimeReady, "SelfTest", {{"test", true}}});
    event_bus_->pump();

    event_bus_->unsubscribe(id);

    bool pass = (received == 1);
    std::cout << (pass ? "  PASS" : "  FAIL") << " (events received: " << received << ")" << std::endl;
    return pass;
}

bool Runtime::selfTestPolicy() {
    std::cout << "[SelfTest] PolicyEngine..." << std::endl;

    // Test constitution: dangerous command should be blocked
    std::string reason;
    bool blocked = !policy_engine_->checkConstitution("run_terminal",
        {{"command", "rm -rf /"}}, reason);
    std::cout << (blocked ? "  PASS" : "  FAIL") << " dangerous command blocked: " << reason << std::endl;

    // Test constitution: safe command should pass
    bool allowed = policy_engine_->checkConstitution("run_terminal",
        {{"command", "ls -la"}}, reason);
    std::cout << (allowed ? "  PASS" : "  FAIL") << " safe command allowed" << std::endl;

    return blocked && allowed;
}

bool Runtime::selfTestToolSystem() {
    std::cout << "[SelfTest] ToolSystem..." << std::endl;

    int pass = 0, fail = 0;
    auto check = [&](bool ok, const std::string& name) {
        if (ok) { pass++; std::cout << "  PASS: " << name << std::endl; }
        else { fail++; std::cout << "  FAIL: " << name << std::endl; }
    };

    // 1. All builtin tools registered
    int count = 0;
    for (const auto& name : {"read_file", "write_file", "edit_file",
                              "list_directory", "run_terminal", "search_files", "grep"}) {
        if (tool_broker_->hasTool(name)) count++;
    }
    check(count == 7, "7 builtin tools registered");

    // 2. write_file + read_file round-trip
    tool_broker_->execute("write_file", {{"path", "/tmp/axiom_test.txt"}, {"content", "Hello Axiom!"}});
    auto rr = tool_broker_->execute("read_file", {{"path", "/tmp/axiom_test.txt"}});
    check(rr.success && rr.data.value("content", "").find("Hello Axiom!") != std::string::npos,
          "write + read round-trip");

    // 3. edit_file
    tool_broker_->execute("write_file", {{"path", "/tmp/axiom_edit.txt"}, {"content", "abc old xyz"}});
    auto er = tool_broker_->execute("edit_file", {{"path", "/tmp/axiom_edit.txt"},
                                                   {"old_text", "old"}, {"new_text", "NEW"}});
    check(er.success, "edit_file exact replace");
    auto er2 = tool_broker_->execute("read_file", {{"path", "/tmp/axiom_edit.txt"}});
    check(er2.success && er2.data.value("content", "").find("abc NEW xyz") != std::string::npos,
          "edit_file content verified");

    // 4. list_directory
    auto ld = tool_broker_->execute("list_directory", {{"path", "/tmp"}});
    check(ld.success, "list_directory " + std::string("/tmp"));

    // 5. run_terminal (safe command)
    auto rt = tool_broker_->execute("run_terminal", {{"command", "echo axiom_test_ok"}});
    check(rt.success && rt.data.value("output", "").find("axiom_test_ok") != std::string::npos,
          "run_terminal safe command");

    // 6. run_terminal (dangerous command blocked)
    auto rd = tool_broker_->execute("run_terminal", {{"command", "rm -rf /"}});
    check(!rd.success, "run_terminal blocks dangerous command");

    // 7. grep files
    auto gr = tool_broker_->execute("grep", {{"pattern", "Hello"}, {"path", "/tmp/axiom_test.txt"}});
    check(gr.success, "grep finds pattern");

    // 8. search_files
    auto sf = tool_broker_->execute("search_files", {{"pattern", "axiom_test*"}, {"directory", "/tmp"}});
    check(sf.success, "search_files finds test file");

    // 9. null params safety
    auto np = tool_broker_->execute("read_file", nlohmann::json::value_t::null);
    check(!np.success, "null params handled safely");

    // 10. unknown tool
    auto unk = tool_broker_->execute("nonexistent_tool", {});
    check(!unk.success, "unknown tool rejected");

    std::cout << "  Results: " << pass << " passed, " << fail << " failed" << std::endl;
    return fail == 0;
}

bool Runtime::selfTestSkills() {
    std::cout << "[SelfTest] SkillSystem..." << std::endl;
    int pass = 0, fail = 0;
    auto check = [&](bool ok, const std::string& name) {
        if (ok) { pass++; std::cout << "  PASS: " << name << std::endl; }
        else { fail++; std::cout << "  FAIL: " << name << std::endl; }
    };

    // 1. Register skill programmatically
    Skill s;
    s.name = "test-skill";
    s.version = "1.0.0";
    s.description = "Test skill";
    s.instructions = "You are a test assistant.";
    s.state = SkillState::Candidate;
    skill_system_->registerSkill(s);
    check(skill_system_->getSkill("test-skill") != nullptr, "register skill");

    // 2. Validate skill
    check(skill_system_->validateSkill("test-skill"), "validate skill");
    auto* vs = skill_system_->getSkill("test-skill");
    check(vs && vs->state == SkillState::Validated, "skill state=Validated");

    // 3. Activate skill
    check(skill_system_->activateSkill("test-skill"), "activate skill");
    auto* as = skill_system_->getSkill("test-skill");
    check(as && as->state == SkillState::Active, "skill state=Active");

    // 4. List active skills
    auto active = skill_system_->activeSkills();
    check(!active.empty(), "active skills non-empty");

    // 5. Build system prompt
    std::string prompt = skill_system_->buildSystemPrompt();
    check(prompt.find("Axiom") != std::string::npos, "system prompt contains Axiom");
    check(prompt.find("test-skill") != std::string::npos, "system prompt contains skill");

    // 6. Deprecate
    skill_system_->deprecateSkill("test-skill");
    auto* ds = skill_system_->getSkill("test-skill");
    check(ds && ds->state == SkillState::Deprecated, "skill state=Deprecated");

    // 7. Dynamic skill proposal
    auto cand = skill_system_->proposeSkill("agent-1", "Learned from executing a file search");
    check(!cand.proposed_name.empty(), "dynamic skill proposal");

    std::cout << "  Results: " << pass << " passed, " << fail << " failed" << std::endl;
    return fail == 0;
}

bool Runtime::selfTestMarkdown() {
    std::cout << "[SelfTest] MarkdownRenderer..." << std::endl;
    int pass = 0, fail = 0;
    auto check = [&](bool ok, const std::string& name) {
        if (ok) { pass++; std::cout << "  PASS: " << name << std::endl; }
        else { fail++; std::cout << "  FAIL: " << name << std::endl; }
    };

    MarkdownRenderer md;
    md.setWidth(72);

    // 1. Bold
    std::string r1 = md.render("Hello **world**!");
    check(r1.find("world") != std::string::npos && r1.find("**") == std::string::npos,
          "bold formatting");

    // 2. Italic
    std::string r2 = md.render("This is *italic* text.");
    check(r2.find("italic") != std::string::npos && r2.find("*italic*") == std::string::npos,
          "italic formatting");

    // 3. Inline code
    std::string r3 = md.render("Use `printf()` to print.");
    check(r3.find("printf()") != std::string::npos && r3.find("`") == std::string::npos,
          "inline code");

    // 4. Headers
    std::string r4 = md.render("# Title\n\nContent.");
    check(r4.find("Title") != std::string::npos && r4.find("# ") == std::string::npos,
          "header rendering");

    // 5. Code block
    std::string r5 = md.render("```cpp\nint main() {}\n```");
    check(r5.find("int main() {}") != std::string::npos, "code block");

    // 6. Unordered list
    std::string r6 = md.render("- item one\n- item two");
    check(r6.find("item one") != std::string::npos && r6.find("- ") == std::string::npos,
          "unordered list");

    // 7. Blockquote
    std::string r7 = md.render("> quoted text");
    check(r7.find("quoted text") != std::string::npos && r7.find("> ") == std::string::npos,
          "blockquote");

    // 8. Table
    std::string r8 = md.render("| Name | Value |\n|------|-------|\n| foo  | 42    |");
    check(!r8.empty() && r8.find("foo") != std::string::npos, "table rendering");

    // 9. Horizontal rule
    std::string r9 = md.render("before\n\n---\n\nafter");
    check(r9.find("before") != std::string::npos && r9.find("after") != std::string::npos,
          "horizontal rule");

    // 10. Empty input
    check(md.render("").empty(), "empty input");

    std::cout << "  Results: " << pass << " passed, " << fail << " failed" << std::endl;
    return fail == 0;
}

bool Runtime::selfTestAll() {
    std::cout << "\n======== Axiom Self-Test Suite ========\n" << std::endl;
    bool all_pass = true;
    all_pass &= selfTestEventBus();
    all_pass &= selfTestPolicy();
    all_pass &= selfTestToolSystem();
    all_pass &= selfTestSkills();
    all_pass &= selfTestMarkdown();
    std::cout << "\n========================================" << std::endl;
    std::cout << (all_pass ? "ALL TESTS PASSED" : "SOME TESTS FAILED") << std::endl;
    return all_pass;
}

} // namespace axiom
