#include "axiom/cli.hpp"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <clocale>
#include <csignal>
#include <algorithm>
#include <sstream>
#include <sys/ioctl.h>
#include <unistd.h>
#include <sys/stat.h>

namespace axiom {

// Global interrupt flag
static std::atomic<bool> g_interrupted(false);

static void signalHandler(int) {
    g_interrupted = true;
    std::cout << "\nInterrupted. Type 'exit' to quit." << std::endl;
}

CLI::CLI(Runtime& runtime) : runtime_(runtime) {
    std::setlocale(LC_ALL, "en_US.UTF-8");
}

CLI::~CLI() = default;

std::string CLI::fixUtf8Encoding(const std::string& input) {
    std::string result;
    result.reserve(input.size());
    for (size_t i = 0; i < input.size(); ++i) {
        unsigned char c = static_cast<unsigned char>(input[i]);
        if (c < 0x80) {
            result += static_cast<char>(c);
        } else if ((c & 0xE0) == 0xC0 && i + 1 < input.size()) {
            result += input[i]; result += input[++i];
        } else if ((c & 0xF0) == 0xE0 && i + 2 < input.size()) {
            result += input[i]; result += input[++i]; result += input[++i];
        } else if ((c & 0xF8) == 0xF0 && i + 3 < input.size()) {
            result += input[i]; result += input[++i]; result += input[++i]; result += input[++i];
        } else {
            result += '?';
        }
    }
    return result;
}

void CLI::clearScreen() {
    std::cout << "\033[2J\033[H" << std::flush;
}

void CLI::showBanner() {
    std::cout << R"(
+=============================================================+
|                                                             |
|        AAA   XX   XX  III   OOO   MM   MM                  |
|       A   A   X X    III  O   O  M M M M                  |
|       AAAAA    X      III  O   O  M  M  M                  |
|       A   A   X X     III  O   O  M     M                  |
|       A   A  XX   XX  III   OOO   M     M                  |
|                                                             |
|            AI Agent Runtime — Evidence-Driven               |
|            LLM provides intelligence.                       |
|            Runtime provides trust.                          |
+=============================================================+
)" << std::endl;
}

void CLI::showWelcome() {
    clearScreen();
    showBanner();
    std::cout << " Welcome to Axiom — AI Agent Runtime\n" << std::endl;
    std::cout << " Features:" << std::endl;
    std::cout << "  * Multi-provider: Claude | OpenAI | DeepSeek | Ollama" << std::endl;
    std::cout << "  * Event-driven architecture" << std::endl;
    std::cout << "  * Constitution-based security (4 core rules)" << std::endl;
    std::cout << "  * Skill system with lifecycle management" << std::endl;
    std::cout << "  * Sandboxed tool execution (7 builtin tools)" << std::endl;
    std::cout << "  * Real-time token & cost tracking" << std::endl;
    std::cout << "  * Git integration" << std::endl;
    std::cout << std::endl;
}

void CLI::showHelp() {
    std::cout << R"(
+-------------------------------------------------------------+
|  Commands                                                   |
+-------------------------------------------------------------+
|  /help         Show this help                              |
|  /stats        Show token usage & cost                     |
|  /git          Show git repository status                  |
|  /events       Show recent runtime events                  |
|  /skills       List loaded skills                          |
|  /rules        Show Constitution rules                     |
|  /clear        Clear screen                                |
|  exit / quit   End session                                 |
+-------------------------------------------------------------+
)" << std::endl;
}

void CLI::showAgentStatus() {
    const auto& events = runtime_.eventBus().recentEvents(10);
    std::cout << "\nRecent Events (" << events.size() << "):" << std::endl;
    for (const auto& e : events) {
        std::cout << "  [" << e.typeName() << "] ";
        std::string data_str = e.data.dump();
        if (data_str.length() > 60) data_str = data_str.substr(0, 57) + "...";
        std::cout << data_str << std::endl;
    }
}

void CLI::showSessionSummary() {
    auto& tracker = runtime_.tokenTracker();
    int64_t total = tracker.getTotalInputTokens() + tracker.getTotalOutputTokens();
    std::cout << R"(
+=============================================================+
|  Session Summary                                            |
+=============================================================+
|  Input Tokens:   )" << std::setw(10) << tracker.getTotalInputTokens() << R"(                     |
|  Output Tokens:  )" << std::setw(10) << tracker.getTotalOutputTokens() << R"(                     |
|  Total Tokens:   )" << std::setw(10) << total << R"(                     |
|  ---------------------------------------------------------  |
|  Estimated Cost: $)" << std::fixed << std::setprecision(6)
     << std::setw(10) << tracker.getTotalCostUSD() << R"( USD               |
+=============================================================+
)" << std::endl;
}

void CLI::displayAIResponse(const std::string& content) {
    std::string rendered = md_.render(fixUtf8Encoding(content));
    std::cout << "\n" << rendered;
}

void CLI::displayError(const std::string& message) {
    std::cerr << "\n*** Error: " << message << std::endl;
}

std::string CLI::getInput(const std::string& prompt) {
    std::cout << "\n+-[ " << prompt << " ]----------------------------------------+" << std::endl;
    std::cout << "+> " << std::flush;

    std::string input;
    std::getline(std::cin, input);

    // 检测多行粘贴：缓冲区中是否有更多数据
    if (std::cin.rdbuf()->in_avail() > 0) {
        std::string line;
        int extra_lines = 0;
        while (std::cin.rdbuf()->in_avail() > 0 && std::getline(std::cin, line)) {
            if (!input.empty()) input += "\n";
            input += line;
            extra_lines++;
        }
        if (extra_lines > 0) {
            std::cout << Ansi::dim("[Pasted " + std::to_string(extra_lines + 1)
                                   + " lines, " + std::to_string(input.size())
                                   + " chars]") << std::endl;
        }
    } else if (input.size() > 400) {
        // 单行但很长
        std::cout << Ansi::dim("[Pasted 1 line, " + std::to_string(input.size())
                               + " chars]") << std::endl;
    }

    return input;
}

bool CLI::handleInternalCommand(const std::string& input) {
    if (input.empty()) return true;

    if (input == "exit" || input == "quit") return false;

    if (input == "/help") { showHelp(); return true; }

    if (input == "/stats") {
        auto& tracker = runtime_.tokenTracker();
        std::cout << "\n  Tokens: " << tracker.getTotalInputTokens() + tracker.getTotalOutputTokens()
                  << " | Cost: $" << std::fixed << std::setprecision(6) << tracker.getTotalCostUSD()
                  << std::endl;
        return true;
    }

    if (input == "/git") {
        if (GitManager::isGitAvailable()) {
            auto status = runtime_.gitManager().checkStatus(work_dir_);
            if (status.is_repo) {
                std::cout << "\n  Branch: " << status.current_branch
                          << " | Changed: " << status.modified_files.size()
                          << " files | Behind remote: " << status.commits_behind << std::endl;
            } else {
                std::cout << "\n  Not a git repository" << std::endl;
            }
        }
        return true;
    }

    if (input == "/events") { showAgentStatus(); return true; }

    if (input == "/skills") {
        auto skills = runtime_.skillSystem().listSkills();
        std::cout << "\n  Skills (" << skills.size() << "):" << std::endl;
        for (const auto& s : skills) {
            std::cout << "    * " << s.name << " (" << skillStateName(s.state)
                      << ") v" << s.version << " — " << s.description << std::endl;
        }
        return true;
    }

    if (input == "/rules") {
        auto rules = runtime_.policyEngine().constitution().rules();
        std::cout << "\n  Constitution Rules:" << std::endl;
        for (size_t i = 0; i < rules.size(); ++i) {
            std::cout << "    " << (i+1) << ". " << rules[i] << std::endl;
        }
        return true;
    }

    if (input == "/clear") { clearScreen(); return true; }

    return true;
}

// ─── 配置持久化 ────────────────────────────────────

static std::string getConfigDir() {
    const char* home = std::getenv("HOME");
    if (!home) home = std::getenv("USERPROFILE");
    std::string dir = home ? std::string(home) + "/.axiom" : ".axiom";
    mkdir(dir.c_str(), 0700);  // ensure exists, ignore error
    return dir;
}

void CLI::saveConfig() {
    nlohmann::json j;
    j["provider"] = static_cast<int>(selected_provider_);
    j["api_key"] = api_key_;
    j["model"] = model_;
    j["work_dir"] = work_dir_;
    j["use_git"] = use_git_;

    std::string path = getConfigDir() + "/config.json";
    std::ofstream f(path);
    if (f.is_open()) {
        f << j.dump(2) << std::endl;
    }
}

bool CLI::loadConfig() {
    std::string path = getConfigDir() + "/config.json";
    std::ifstream f(path);
    if (!f.is_open()) return false;

    try {
        nlohmann::json j;
        f >> j;
        int p = j.value("provider", -1);
        if (p >= 0 && p <= 3) selected_provider_ = static_cast<ProviderType>(p);
        else return false;
        api_key_ = j.value("api_key", "");
        model_ = j.value("model", "");
        work_dir_ = j.value("work_dir", ".");
        use_git_ = j.value("use_git", true);
        return true;
    } catch (...) {
        return false;
    }
}

// ─── 配置向导 ────────────────────────────────────────

bool CLI::runConfigWizard() {
    // ── 检查是否有已保存的配置 ──
    if (loadConfig()) {
        std::cout << R"(
+-------------------------------------------------------------+
|  Saved configuration found:                                 |
+-------------------------------------------------------------+
|  Provider: )" << AdapterFactory::providerName(selected_provider_) << std::string(
    30 - AdapterFactory::providerName(selected_provider_).length(), ' ') << R"(|
|  Model:    )" << model_ << std::string(30 - std::min(size_t(30), model_.length()), ' ') << R"(|
|  Work Dir: )" << work_dir_ << std::string(30 - std::min(size_t(30), work_dir_.length()), ' ') << R"(|
+-------------------------------------------------------------+
)" << std::endl;
        std::cout << "\nReuse saved configuration? (y/n) [y]: ";
        std::string reuse;
        std::getline(std::cin, reuse);
        if (reuse != "n" && reuse != "N") {
            // Build runtime config from saved values
            RuntimeConfig config;
            config.provider = selected_provider_;
            config.api_key = api_key_;
            config.model = model_;
            config.work_dir = work_dir_;
            config.use_git = use_git_;
            if (runtime_.initialize(config)) return true;
        }
    }

    std::cout << R"(
+-------------------------------------------------------------+
|  Configuration Wizard                                       |
+-------------------------------------------------------------+

Select AI Provider:
  1. Anthropic Claude  (api.anthropic.com)
  2. OpenAI            (api.openai.com)
  3. DeepSeek          (api.deepseek.com)
  4. Ollama/LlamaCpp   (localhost:11434)
)" << std::endl;

    std::cout << "\nEnter choice [1-4]: ";
    int choice;
    std::cin >> choice;
    std::cin.ignore();

    switch (choice) {
        case 1: selected_provider_ = ProviderType::Claude; model_ = "claude-sonnet-4-20250514"; break;
        case 2: selected_provider_ = ProviderType::OpenAI; model_ = "gpt-4o-mini"; break;
        case 3: selected_provider_ = ProviderType::DeepSeek; model_ = "deepseek-chat"; break;
        case 4: selected_provider_ = ProviderType::Ollama; model_ = "llama3"; break;
        default:
            std::cerr << "Invalid choice" << std::endl;
            return false;
    }

    if (selected_provider_ != ProviderType::Ollama) {
        std::cout << "API Key: ";
        std::getline(std::cin, api_key_);
        if (api_key_.empty()) {
            std::cerr << "API key required" << std::endl;
            return false;
        }
    }

    std::cout << "Model [" << model_ << "]: ";
    std::string model_input;
    std::getline(std::cin, model_input);
    if (!model_input.empty()) model_ = model_input;

    std::cout << "Working directory [.]: ";
    std::getline(std::cin, work_dir_);
    if (work_dir_.empty()) work_dir_ = ".";

    std::cout << "Enable Git integration? (y/n) [y]: ";
    std::string git_input;
    std::getline(std::cin, git_input);
    use_git_ = (git_input != "n" && git_input != "N");

    RuntimeConfig config;
    config.provider = selected_provider_;
    config.api_key = api_key_;
    config.model = model_;
    config.work_dir = work_dir_;
    config.use_git = use_git_;

    if (!runtime_.initialize(config)) {
        std::cerr << "Failed to initialize runtime" << std::endl;
        return false;
    }

    // ── 保存配置 ──
    saveConfig();

    std::cout << R"(
+=============================================================+
|  Configuration saved to ~/.axiom/config.json                |
+=============================================================+
|  Provider: )" << AdapterFactory::providerName(selected_provider_) << std::string(
    40 - AdapterFactory::providerName(selected_provider_).length(), ' ') << R"(|
|  Model:    )" << model_ << std::string(40 - std::min(size_t(40), model_.length()), ' ') << R"(|
|  Work Dir: )" << work_dir_ << std::string(40 - std::min(size_t(40), work_dir_.length()), ' ') << R"(|
|  Git:      )" << (use_git_ ? "Enabled" : "Disabled") << std::string(32, ' ') << R"(|
+=============================================================+
)" << std::endl;

    return true;
}

void CLI::chatLoop() {
    std::cout << "\nChat started. Type 'exit' to quit, '/help' for commands." << std::endl;
    std::cout << "Constitution active: 4 core rules protecting your system.\n" << std::endl;

    // ── Agent 观察者每次循环重新赋值 ──
    AgentObserver obs;

    // 订阅 EventBus 实时事件
    auto evt_id = runtime_.eventBus().subscribeAll(
        [](const Event& e) {
            if (e.type == EventType::PermissionDenied) {
                std::cout << "  " << Ansi::Red << "[DENIED]" << Ansi::Reset
                          << " " << e.data.value("reason", "") << std::endl;
            } else if (e.type == EventType::FileChanged) {
                std::cout << "  " << Ansi::Yellow << "[FILE]" << Ansi::Reset
                          << " " << e.data.value("path", "") << std::endl;
            }
        });

    runtime_.agentEngine().setObserver(obs);

    while (!g_interrupted && runtime_.isRunning()) {
        std::string input = getInput("You");

        if (!handleInternalCommand(input)) break;
        if (input.empty() || input[0] == '/') continue;
        if (g_interrupted) break;

        // ── 直接通过 Agent 引擎运行（带观察者） ──
        AgentConfig config;
        config.goal = input;
        config.model = model_;
        config.work_dir = work_dir_;
        config.max_turns = 50;

        // 加载活跃 Skill
        for (const auto* skill : runtime_.skillSystem().activeSkills()) {
            config.skills.push_back(skill->name);
        }

        std::string agent_id = runtime_.agentEngine().createAgent(config);

        // 确保引擎使用当前模型
        runtime_.agentEngine().setModel(model_);

        // 授予默认权限
        runtime_.policyEngine().grantTemporary(agent_id, Capability::FilesystemRead,
                                                std::chrono::minutes(30));
        runtime_.policyEngine().grantTemporary(agent_id, Capability::FilesystemWrite,
                                                std::chrono::minutes(30));
        runtime_.policyEngine().grantTemporary(agent_id, Capability::ProcessExecute,
                                                std::chrono::minutes(30));

        // 累积流式输出，不直接显示 raw text
        std::string accumulated_text;

        // 观察者：显示流式输出 + 累积用于 Markdown 渲染
        bool first_chunk = true;
        obs.onThinking = [&accumulated_text, &first_chunk](const std::string& chunk) {
            if (first_chunk) {
                std::cout << Ansi::dim("... ") << std::flush;
                first_chunk = false;
            }
            std::cout << chunk << std::flush;
            accumulated_text += chunk;
        };
        obs.onThinkingComplete = []() {
            std::cout << std::endl;
        };

        // 工具调用可见
        obs.onToolPreCall = [](const std::string& name, const nlohmann::json& params) {
            std::cout << "\n  " << Ansi::Bold << Ansi::Yellow << "[EXEC] " << Ansi::Reset
                      << name;
            std::string ps = params.dump();
            if (ps.length() > 80) ps = ps.substr(0, 77) + "...";
            std::cout << " " << Ansi::dim(ps) << std::endl;
        };
        obs.onToolPostCall = [](const std::string& name, const ToolResult& result) {
            if (result.success) {
                std::cout << "  " << Ansi::Green << " OK " << Ansi::Reset
                          << name << " (" << result.duration.count() << "ms)" << std::endl;
            } else {
                std::cout << "  " << Ansi::Red << Ansi::Bold << "FAIL" << Ansi::Reset
                          << " " << name << ": " << result.output.substr(0, 80) << std::endl;
            }
        };
        obs.onTurnComplete = [](int64_t in_tok, int64_t out_tok, double cost) {
            std::cout << Ansi::dim("  [" + std::to_string(in_tok + out_tok)
                                  + " tokens, $" + std::to_string(cost).substr(0,7) + "]")
                      << std::endl;
        };

        // 运行 Agent
        try {
            runtime_.agentEngine().runAgent(agent_id);
        } catch (const std::exception& e) {
            std::cout << "\n  " << Ansi::Red << Ansi::Bold << "ERROR" << Ansi::Reset
                      << " " << e.what() << std::endl;
        } catch (...) {
            std::cout << "\n  " << Ansi::Red << Ansi::Bold << "ERROR" << Ansi::Reset
                      << " unknown exception" << std::endl;
        }

        // 获取 Agent 最终消息（兜底：如果流式未工作）
        const Agent* agent = runtime_.agentEngine().getAgent(agent_id);
        if (agent) {
            // 从最后一条 assistant 消息提取内容
            std::string final_content;
            for (auto it = agent->messages.rbegin(); it != agent->messages.rend(); ++it) {
                if (it->role == "assistant" && !it->content.empty()) {
                    final_content = it->content;
                    break;
                }
            }
            // 流式文本优先，否则用 final_content
            if (accumulated_text.empty()) accumulated_text = final_content;
        }

        // 渲染 Markdown 输出
        if (!accumulated_text.empty()) {
            std::cout << "\n" << md_.render(fixUtf8Encoding(accumulated_text));
        }

        if (agent) {
            // 记录 token
            runtime_.tokenTracker().recordTokens(
                agent->total_input_tokens, agent->total_output_tokens);

            // 显示最终回答（如果流式输出没有以换行结尾）
            std::cout << std::endl;

            // 最终 Token 汇总
            int64_t total = runtime_.tokenTracker().getTotalInputTokens()
                          + runtime_.tokenTracker().getTotalOutputTokens();
            if (total > 0) {
                std::cout << "   Session: " << total << " tokens | $"
                          << std::fixed << std::setprecision(4)
                          << runtime_.tokenTracker().getTotalCostUSD() << std::endl;
            }
        }

        if (g_interrupted) {
            runtime_.agentEngine().interrupt();
            runtime_.agentEngine().clearInterrupt();
            std::cout << "\nInterrupted." << std::endl;
        }
    }

    runtime_.eventBus().unsubscribe(evt_id);
}

int CLI::run(int argc, char* argv[]) {
    std::signal(SIGINT, signalHandler);

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--self-test-event-bus") {
            Runtime temp_rt;
            temp_rt.initialize({ProviderType::OpenAI, "", "", "test", "."});
            return temp_rt.selfTestEventBus() ? 0 : 1;
        }
        if (arg == "--self-test-policy") {
            Runtime temp_rt;
            temp_rt.initialize({ProviderType::OpenAI, "", "", "test", "."});
            return temp_rt.selfTestPolicy() ? 0 : 1;
        }
        if (arg == "--self-test-tools") {
            Runtime temp_rt;
            temp_rt.initialize({ProviderType::OpenAI, "", "", "test", "."});
            return temp_rt.selfTestToolSystem() ? 0 : 1;
        }
        if (arg == "--self-test-skills") {
            Runtime temp_rt;
            temp_rt.initialize({ProviderType::OpenAI, "", "", "test", "."});
            return temp_rt.selfTestSkills() ? 0 : 1;
        }
        if (arg == "--self-test-markdown") {
            Runtime temp_rt;
            temp_rt.initialize({ProviderType::OpenAI, "", "", "test", "."});
            return temp_rt.selfTestMarkdown() ? 0 : 1;
        }
        if (arg == "--self-test-all") {
            Runtime temp_rt;
            temp_rt.initialize({ProviderType::OpenAI, "", "", "test", "."});
            return temp_rt.selfTestAll() ? 0 : 1;
        }
        if (arg == "--skill" && i + 1 < argc) {
            RuntimeConfig config;
            config.provider = ProviderType::OpenAI;
            config.work_dir = ".";
            if (!runtime_.initialize(config)) return 1;
            runtime_.skillSystem().loadSkill(argv[++i]);
            runtime_.start();
            chatLoop();
            return 0;
        }
        if (arg == "--help" || arg == "-h") {
            std::cout << "Axiom — AI Agent Runtime" << std::endl;
            std::cout << "  axiom                     Interactive mode" << std::endl;
            std::cout << "  axiom --self-test-all     Run all self-tests" << std::endl;
            std::cout << "  axiom --self-test-event-bus" << std::endl;
            std::cout << "  axiom --self-test-policy" << std::endl;
            std::cout << "  axiom --self-test-tools" << std::endl;
            std::cout << "  axiom --skill <file>      Load skill and start chat" << std::endl;
            return 0;
        }
    }

    showWelcome();
    if (!runConfigWizard()) return 1;
    runtime_.start();

    // ── 终端宽度自动检测 ──
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col > 20) {
        md_.setWidth(ws.ws_col - 2);
    }

    // ── 启动摘要：项目状态 + 建议 ──
    {
        // 检测项目类型
        bool has_cmake = std::ifstream(work_dir_ + "/CMakeLists.txt").good();
        bool has_package = std::ifstream(work_dir_ + "/package.json").good();
        bool has_python = std::ifstream(work_dir_ + "/requirements.txt").good()
                       || std::ifstream(work_dir_ + "/pyproject.toml").good();
        bool has_rust = std::ifstream(work_dir_ + "/Cargo.toml").good();

        std::cout << "\n" << Ansi::bold("Project Summary") << std::endl;
        std::cout << "  Directory : " << work_dir_ << std::endl;

        if (use_git_ && GitManager::isGitAvailable()) {
            auto gs = runtime_.gitManager().checkStatus(work_dir_);
            if (gs.is_repo) {
                std::cout << "  Git       : " << Ansi::Green << gs.current_branch << Ansi::Reset;
                if (gs.has_uncommitted_changes)
                    std::cout << " (" << gs.modified_files.size() << " files modified)";
                if (gs.is_behind_remote)
                    std::cout << " " << Ansi::Yellow << "[" << gs.commits_behind << " behind]" << Ansi::Reset;
                std::cout << std::endl;
            }
        }

        // 项目类型检测
        std::cout << "  Project   : ";
        if (has_cmake) std::cout << "C++/CMake ";
        if (has_package) std::cout << "Node.js ";
        if (has_python) std::cout << "Python ";
        if (has_rust) std::cout << "Rust ";
        if (!has_cmake && !has_package && !has_python && !has_rust)
            std::cout << "generic";
        std::cout << std::endl;

        // 工具 + Skill 数量
        auto tools = runtime_.toolBroker().getToolsSchema();
        auto skills = runtime_.skillSystem().listSkills();
        std::cout << "  Tools     : " << tools.size() << " available";
        if (!skills.empty()) std::cout << " | Skills: " << skills.size() << " loaded";
        std::cout << std::endl;

        // Constitution 状态
        std::cout << "  Security  : " << Ansi::Green << "Constitution active"
                  << Ansi::Reset << " (4 rules)" << std::endl;

        // 实用建议
        std::cout << "\n" << Ansi::dim("Quick start:") << std::endl;
        if (has_cmake)
            std::cout << Ansi::dim("  > \"Check the build status of this project\"") << std::endl;
        else if (has_python)
            std::cout << Ansi::dim("  > \"Find and explain the main entry point\"") << std::endl;
        else
            std::cout << Ansi::dim("  > \"Give me an overview of this project\"") << std::endl;
        std::cout << Ansi::dim("  > Try /skills to see skills, /help for commands") << std::endl;
        std::cout << std::endl;
    }

    std::cout << Ansi::dim(std::string(md_.width(), '-')) << std::endl;
    chatLoop();
    showSessionSummary();
    runtime_.shutdown();
    std::cout << "\nGoodbye." << std::endl;

    return 0;
}

} // namespace axiom
