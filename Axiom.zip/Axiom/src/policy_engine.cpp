#include "axiom/policy_engine.hpp"
#include <algorithm>
#include <ctime>

namespace axiom {

// ──────────────────────────────────────────────────────
// Constitution
// ──────────────────────────────────────────────────────

Constitution::Constitution() {
    // Rule 1: No secret leakage
    rules_.push_back({"no-secret-leakage",
        [](const std::string& action, const nlohmann::json& params) -> bool {
            if (action != "write_file" && action != "run_terminal") return true;
            std::string content = params.value("content", params.value("command", ""));
            // Check for common credential patterns
            std::vector<std::string> patterns = {
                "API_KEY=", "api_key=", "SECRET=", "password=", "token=",
                ".env", "credentials", "~/.ssh/", "~/.aws/", "id_rsa",
                "Bearer ", "x-api-key:"
            };
            for (const auto& p : patterns) {
                if (content.find(p) != std::string::npos) return false;
            }
            return true;
        }, "Do not write secrets, API keys, or credentials to files or commands"});

    // Rule 2: No result forgery
    rules_.push_back({"no-forgery",
        [](const std::string& action, const nlohmann::json&) -> bool {
            return true; // Enforced at Agent level (Evidence-driven verification)
        }, "Do not fabricate tool results or test outcomes"});

    // Rule 3: No permission bypass
    rules_.push_back({"no-bypass",
        [](const std::string& action, const nlohmann::json& params) -> bool {
            if (action != "run_terminal") return true;
            std::string cmd = params.value("command", "");
            std::vector<std::string> bypass = {
                "--dangerously-skip-permissions", "--no-sandbox",
                "sudo", "su -", "chmod 777", "setfacl"
            };
            for (const auto& b : bypass) {
                if (cmd.find(b) != std::string::npos) return false;
            }
            return true;
        }, "Do not attempt to bypass permission or sandbox restrictions"});

    // Rule 4: Protect user data
    rules_.push_back({"protect-user-data",
        [](const std::string& action, const nlohmann::json& params) -> bool {
            if (action == "run_terminal") {
                std::string cmd = params.value("command", "");
                std::vector<std::string> destructive = {
                    "rm -rf", "shred", "> /dev/", "dd if=", "mkfs",
                    "format", "fdisk", "fsck"
                };
                for (const auto& d : destructive) {
                    if (cmd.find(d) != std::string::npos) return false;
                }
            }
            return true;
        }, "Do not destroy or corrupt user data"});
}

bool Constitution::validate(const std::string& action_type,
                             const nlohmann::json& params) const {
    for (const auto& rule : rules_) {
        if (!rule.check(action_type, params)) return false;
    }
    return true;
}

std::string Constitution::violationReason(const std::string& action_type,
                                           const nlohmann::json& params) const {
    for (const auto& rule : rules_) {
        if (!rule.check(action_type, params)) {
            return "Constitution violation [" + rule.name + "]: " + rule.description;
        }
    }
    return "";
}

std::vector<std::string> Constitution::rules() const {
    std::vector<std::string> result;
    for (const auto& r : rules_) result.push_back(r.name + ": " + r.description);
    return result;
}

// ──────────────────────────────────────────────────────
// PolicyEngine
// ──────────────────────────────────────────────────────

PolicyEngine::PolicyEngine(EventBus& bus) : event_bus_(bus) {
    // Default safe capabilities
    default_allowed_ = {
        Capability::FilesystemRead,
        Capability::GitRead
    };
}

bool PolicyEngine::checkPermission(const std::string& agent_id,
                                    Capability capability,
                                    const std::string& scope) const {
    // Check constitution first
    std::string dummy_reason;
    if (!checkConstitution("permission_check",
                           {{"capability", capabilityName(capability)}, {"scope", scope}},
                           dummy_reason)) {
        return false;
    }

    // Check agent-specific grants
    auto it = grants_.find(agent_id);
    if (it != grants_.end()) {
        for (const auto& perm : it->second) {
            if (perm.capability == capability && !perm.isExpired()) {
                if (perm.scope.empty() || perm.scope == scope) {
                    return true;
                }
            }
        }
    }

    // Check global defaults
    if (!default_deny_all_) {
        for (auto c : default_allowed_) {
            if (c == capability) return true;
        }
    }

    // Publish denied event
    const_cast<PolicyEngine*>(this)->event_bus_.publish(
        {EventType::PermissionDenied, "PolicyEngine",
         {{"agent_id", agent_id}, {"capability", capabilityName(capability)}}});

    return false;
}

bool PolicyEngine::checkConstitution(const std::string& action_type,
                                      const nlohmann::json& params,
                                      std::string& out_reason) const {
    if (!constitution_.validate(action_type, params)) {
        out_reason = constitution_.violationReason(action_type, params);
        return false;
    }
    return true;
}

void PolicyEngine::grantTemporary(const std::string& agent_id,
                                   Capability capability,
                                   std::chrono::seconds lifetime,
                                   const std::string& scope) {
    Permission p;
    p.capability = capability;
    p.scope = scope;
    p.lifetime = lifetime;
    p.source = "user";
    p.granted_at = std::chrono::system_clock::now();

    grants_[agent_id].push_back(p);

    event_bus_.publish({EventType::PermissionGranted, "PolicyEngine",
                        {{"agent_id", agent_id},
                         {"capability", capabilityName(capability)},
                         {"lifetime_seconds", lifetime.count()}}});
}

void PolicyEngine::revoke(const std::string& agent_id, Capability capability) {
    auto it = grants_.find(agent_id);
    if (it == grants_.end()) return;

    it->second.erase(
        std::remove_if(it->second.begin(), it->second.end(),
            [capability](const Permission& p) { return p.capability == capability; }),
        it->second.end());
}

void PolicyEngine::loadConfig(const nlohmann::json& config) {
    default_deny_all_ = config.value("default_deny_all", false);
    // Parse additional default allowances from config
}

nlohmann::json PolicyEngine::getConfig() const {
    return {{"default_deny_all", default_deny_all_}};
}

std::string PolicyEngine::maskApiKey(const std::string& key) {
    if (key.length() <= 16) return "****";
    return key.substr(0, 8) + "********" + key.substr(key.length() - 4);
}

} // namespace axiom
