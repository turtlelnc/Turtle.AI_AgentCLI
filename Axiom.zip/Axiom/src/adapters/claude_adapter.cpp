#include "axiom/model_adapter.hpp"
#include <curl/curl.h>
#include <sstream>
#include <iostream>
#include <cstring>
#include <unordered_map>

namespace {

struct CurlGlobal {
    CurlGlobal()  { curl_global_init(CURL_GLOBAL_ALL); }
    ~CurlGlobal() { curl_global_cleanup(); }
};
static CurlGlobal g_curl_init;

size_t writeCb(void* c, size_t s, size_t n, std::string* u) {
    u->append(static_cast<char*>(c), s * n); return s * n;
}

std::string curlPost(const std::string& url, const std::string& data,
                     const std::string& key, const std::string& prov) {
    CURL* c = curl_easy_init();
    if (!c) return R"({"error":"CURL init"})";
    struct curl_slist* h = nullptr;
    h = curl_slist_append(h, "Content-Type: application/json");
    if (!key.empty()) {
        if (prov == "Anthropic") {
            h = curl_slist_append(h, ("x-api-key: " + key).c_str());
            h = curl_slist_append(h, "anthropic-version: 2023-06-01");
        } else h = curl_slist_append(h, ("Authorization: Bearer " + key).c_str());
    }
    curl_easy_setopt(c, CURLOPT_URL, url.c_str());
    curl_easy_setopt(c, CURLOPT_HTTPHEADER, h);
    curl_easy_setopt(c, CURLOPT_POSTFIELDS, data.c_str());
    curl_easy_setopt(c, CURLOPT_TIMEOUT, 120L);
    curl_easy_setopt(c, CURLOPT_SSL_VERIFYPEER, 1L);
    curl_easy_setopt(c, CURLOPT_SSL_VERIFYHOST, 2L);
    std::string r;
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, writeCb);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, &r);
    CURLcode rc = curl_easy_perform(c);
    curl_slist_free_all(h); curl_easy_cleanup(c);
    return (rc == CURLE_OK) ? r : R"({"error":")" + std::string(curl_easy_strerror(rc)) + R"("})";
}

// SSE streaming with tool_call delta accumulation
struct SseToolCall {
    std::string id, type, name, arg_buf;
};
struct SseResult {
    std::string text;
    std::vector<axiom::ToolCall> tool_calls;
    int64_t input_tokens = 0;
    int64_t output_tokens = 0;
};

std::string curlPostSSE_v2(const std::string& url, const std::string& data,
                           const std::string& key,
                           std::function<void(const std::string&)> onChunk,
                           SseResult& out) {
    CURL* c = curl_easy_init();
    if (!c) return "CURL init failed";
    struct curl_slist* h = nullptr;
    h = curl_slist_append(h, "Content-Type: application/json");
    h = curl_slist_append(h, ("Authorization: Bearer " + key).c_str());
    curl_easy_setopt(c, CURLOPT_URL, url.c_str());
    curl_easy_setopt(c, CURLOPT_HTTPHEADER, h);
    curl_easy_setopt(c, CURLOPT_POSTFIELDS, data.c_str());
    curl_easy_setopt(c, CURLOPT_TIMEOUT, 120L);
    curl_easy_setopt(c, CURLOPT_SSL_VERIFYPEER, 1L);
    curl_easy_setopt(c, CURLOPT_SSL_VERIFYHOST, 2L);

    struct Ctx {
        std::string buf;
        std::function<void(const std::string&)>* cb;
        SseResult* out;
        std::unordered_map<int, SseToolCall> tc_buf;
    } ctx{std::string(), &onChunk, &out, {}};
    ctx.buf.reserve(65536);

    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION,
        static_cast<size_t(*)(char*,size_t,size_t,void*)>(
            [](char* p, size_t s, size_t n, void* d) -> size_t {
                auto* x = static_cast<Ctx*>(d);
                x->buf.append(p, s*n);
                size_t pos;
                while ((pos = x->buf.find("\n\n")) != std::string::npos) {
                    std::string ev = x->buf.substr(0, pos);
                    x->buf.erase(0, pos+2);
                    if (ev.rfind("data: ",0) != 0) continue;
                    std::string js = ev.substr(6);
                    if (js == "[DONE]") continue;
                    try {
                        auto j = nlohmann::json::parse(js);
                        if (j.contains("choices") && j["choices"].is_array() && !j["choices"].empty()) {
                            auto& c0 = j["choices"][0];
                            // Text delta
                            if (c0.contains("delta") && c0["delta"].is_object()) {
                                auto& d = c0["delta"];
                                if (d.contains("content") && d["content"].is_string()) {
                                    std::string t = d["content"].get<std::string>();
                                    if (!t.empty()) { x->out->text += t; if (*x->cb) (*x->cb)(t); }
                                }
                                // Tool call deltas
                                if (d.contains("tool_calls") && d["tool_calls"].is_array()) {
                                    for (const auto& tc : d["tool_calls"]) {
                                        int idx = tc.value("index", 0);
                                        auto& buf = x->tc_buf[idx];
                                        if (tc.contains("id") && tc["id"].is_string())
                                            buf.id = tc["id"].get<std::string>();
                                        if (tc.contains("type") && tc["type"].is_string())
                                            buf.type = tc["type"].get<std::string>();
                                        if (tc.contains("function") && tc["function"].is_object()) {
                                            auto& fn = tc["function"];
                                            if (fn.contains("name") && fn["name"].is_string())
                                                buf.name = fn["name"].get<std::string>();
                                            if (fn.contains("arguments") && fn["arguments"].is_string()) {
                                                std::string a = fn["arguments"].get<std::string>();
                                                x->tc_buf[idx].arg_buf += a;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (j.contains("usage")) {
                            x->out->input_tokens = j["usage"].value("prompt_tokens",0);
                            x->out->output_tokens = j["usage"].value("completion_tokens",0);
                        }
                    } catch (...) {}
                }
                return s*n;
            }));
    curl_easy_setopt(c, CURLOPT_WRITEDATA, &ctx);
    CURLcode rc = curl_easy_perform(c);
    curl_slist_free_all(h); curl_easy_cleanup(c);

    // Finalize tool calls from accumulated deltas
    for (auto& [idx, stc] : ctx.tc_buf) {
        if (!stc.name.empty()) {
            axiom::ToolCall tc;
            tc.id = stc.id; tc.type = stc.type; tc.name = stc.name;
            if (!stc.arg_buf.empty()) {
                try { tc.arguments = nlohmann::json::parse(stc.arg_buf); }
                catch (...) { tc.arguments = nlohmann::json::object(); }
            }
            out.tool_calls.push_back(tc);
        }
    }

    return (rc == CURLE_OK) ? "" : std::string(curl_easy_strerror(rc));
}

} // anonymous namespace

namespace axiom {

// ══════════════════════════════════════════════════
// Claude Adapter
// ══════════════════════════════════════════════════
class ClaudeAdapter : public IModelAdapter {
public:
    std::string providerName() const override { return "Anthropic Claude"; }
    std::string defaultModel() const override { return "claude-sonnet-4-20250514"; }
    std::vector<std::string> availableModels() const override {
        return {"claude-sonnet-4-20250514","claude-opus-4-20250514",
                "claude-3-5-sonnet-20241022","claude-3-opus-20240229",
                "claude-3-haiku-20240307"};
    }
    ChatResponse send(const std::string& k, const std::string& m,
                      const std::vector<ChatMessage>& msgs, const std::vector<ToolSchema>& ts) override
    { return sendStreaming(k,m,msgs,ts,nullptr); }
    ChatResponse sendStreaming(const std::string&,const std::string&,const std::vector<ChatMessage>&,
                               const std::vector<ToolSchema>&,std::function<void(const std::string&)>) override;
};

// ══════════════════════════════════════════════════
// OpenAI Adapter (single-phase streaming)
// ══════════════════════════════════════════════════
class OpenAIAdapter : public IModelAdapter {
public:
    std::string providerName() const override { return "OpenAI"; }
    std::string defaultModel() const override { return "gpt-4o-mini"; }
    std::vector<std::string> availableModels() const override {
        return {"gpt-4o","gpt-4o-mini","gpt-4-turbo","gpt-3.5-turbo","o3-mini"};
    }
    ChatResponse send(const std::string& k, const std::string& m,
                      const std::vector<ChatMessage>& msgs, const std::vector<ToolSchema>& ts) override
    { return sendStreaming(k,m,msgs,ts,nullptr); }
    ChatResponse sendStreaming(const std::string&,const std::string&,const std::vector<ChatMessage>&,
                               const std::vector<ToolSchema>&,std::function<void(const std::string&)>) override;
    static nlohmann::json buildBody(const std::string&,const std::vector<ChatMessage>&,
                                    const std::vector<ToolSchema>&,bool);
};

// ══════════════════════════════════════════════════
// DeepSeek Adapter
// ══════════════════════════════════════════════════
class DeepSeekAdapter : public IModelAdapter {
public:
    std::string providerName() const override { return "DeepSeek"; }
    std::string defaultModel() const override { return "deepseek-chat"; }
    std::vector<std::string> availableModels() const override {
        return {"deepseek-chat","deepseek-coder","deepseek-reasoner","deepseek-v3"};
    }
    ChatResponse send(const std::string& k, const std::string& m,
                      const std::vector<ChatMessage>& msgs, const std::vector<ToolSchema>& ts) override
    { return sendStreaming(k,m,msgs,ts,nullptr); }
    ChatResponse sendStreaming(const std::string&,const std::string&,const std::vector<ChatMessage>&,
                               const std::vector<ToolSchema>&,std::function<void(const std::string&)>) override;
};

// ══════════════════════════════════════════════════
// Ollama Adapter
// ══════════════════════════════════════════════════
class OllamaAdapter : public IModelAdapter {
public:
    std::string providerName() const override { return "Ollama/LlamaCpp"; }
    std::string defaultModel() const override { return "llama3"; }
    bool supportsNativeTools() const override { return false; }
    std::vector<std::string> availableModels() const override {
        return {"llama3","mistral","codellama","qwen2.5"};
    }
    ChatResponse send(const std::string& k, const std::string& m,
                      const std::vector<ChatMessage>& msgs, const std::vector<ToolSchema>& ts) override
    { return sendStreaming(k,m,msgs,ts,nullptr); }
    ChatResponse sendStreaming(const std::string&,const std::string&,const std::vector<ChatMessage>&,
                               const std::vector<ToolSchema>&,std::function<void(const std::string&)>) override;
};

// ══════════════════════════════════════════════════
// Claude Implementation
// ══════════════════════════════════════════════════
ChatResponse ClaudeAdapter::sendStreaming(
    const std::string& key, const std::string& model,
    const std::vector<ChatMessage>& msgs, const std::vector<ToolSchema>& tools,
    std::function<void(const std::string&)>)
{
    ChatResponse r;
    nlohmann::json body;
    body["model"] = model; body["max_tokens"] = 4096;
    body["messages"] = nlohmann::json::array();
    std::string sys;
    for (const auto& m : msgs) {
        if (m.role == "system") sys = m.content;
        else {
            nlohmann::json j = {{"role", m.role}};
            j["content"] = m.content_blocks.is_null() ? nlohmann::json(m.content) : m.content_blocks;
            body["messages"].push_back(j);
        }
    }
    if (!sys.empty()) body["system"] = sys;
    if (!tools.empty()) {
        body["tools"] = nlohmann::json::array();
        for (const auto& t : tools)
            body["tools"].push_back({{"name",t.name},{"description",t.description},{"input_schema",t.parameters}});
    }
    std::string raw = curlPost("https://api.anthropic.com/v1/messages", body.dump(), key, "Anthropic");
    try {
        auto j = nlohmann::json::parse(raw);
        if (j.contains("content") && j["content"].is_array()) {
            for (const auto& b : j["content"]) {
                if (!b.is_object()) continue;
                std::string t = b.value("type","");
                if (t == "text" && b.contains("text") && b["text"].is_string())
                    r.content += b["text"].get<std::string>();
                else if (t == "tool_use") {
                    ToolCall tc; tc.id = b.value("id",""); tc.name = b.value("name","");
                    tc.input = (b.contains("input")&&!b["input"].is_null())?b["input"]:nlohmann::json::object();
                    if (!tc.name.empty()) r.tool_calls.push_back(tc);
                }
            }
        }
        if (j.contains("usage") && j["usage"].is_object()) {
            r.input_tokens = j["usage"].value("input_tokens",0);
            r.output_tokens = j["usage"].value("output_tokens",0);
        }
        r.success = !r.content.empty() || !r.tool_calls.empty();
    } catch (...) {}
    return r;
}

// ══════════════════════════════════════════════════
// OpenAI Implementation — single-phase streaming
// ══════════════════════════════════════════════════
nlohmann::json OpenAIAdapter::buildBody(const std::string& model,
    const std::vector<ChatMessage>& msgs, const std::vector<ToolSchema>& tools, bool stream)
{
    nlohmann::json body;
    body["model"] = model; body["stream"] = stream;
    body["temperature"] = 0.7; body["max_tokens"] = 4096;
    body["messages"] = nlohmann::json::array();
    for (const auto& m : msgs) {
        nlohmann::json j = {{"role",m.role},{"content",m.content}};
        if (m.role == "tool" && !m.tool_call_id.empty()) j["tool_call_id"] = m.tool_call_id;
        if (m.role == "assistant" && !m.tool_calls.empty()) {
            nlohmann::json a = nlohmann::json::array();
            for (const auto& tc : m.tool_calls) {
                nlohmann::json t; t["id"]=tc.id; t["type"]=tc.type.empty()?"function":tc.type;
                t["function"]["name"]=tc.name;
                t["function"]["arguments"]=tc.arguments.is_null()?tc.input.dump():tc.arguments.dump();
                a.push_back(t);
            }
            j["tool_calls"] = a;
        }
        body["messages"].push_back(j);
    }
    if (!tools.empty()) {
        body["tools"] = nlohmann::json::array();
        for (const auto& t : tools)
            body["tools"].push_back({{"type","function"},{"function",{{"name",t.name},{"description",t.description},{"parameters",t.parameters}}}});
    }
    return body;
}

ChatResponse OpenAIAdapter::sendStreaming(
    const std::string& key, const std::string& model,
    const std::vector<ChatMessage>& msgs, const std::vector<ToolSchema>& tools,
    std::function<void(const std::string&)> onChunk)
{
    ChatResponse r;

    if (onChunk) {
        // Single-phase: SSE stream with tool_call delta accumulation
        SseResult sse;
        auto body = buildBody(model, msgs, tools, true);
        curlPostSSE_v2("https://api.openai.com/v1/chat/completions", body.dump(), key, onChunk, sse);
        r.content = sse.text;
        r.tool_calls = sse.tool_calls;
        r.input_tokens = sse.input_tokens;
        r.output_tokens = sse.output_tokens;
    } else {
        // Non-streaming fallback
        auto body = buildBody(model, msgs, tools, false);
        std::string raw = curlPost("https://api.openai.com/v1/chat/completions", body.dump(), key, "OpenAI");
        try {
            auto j = nlohmann::json::parse(raw);
            if (j.is_object() && j.contains("choices") && j["choices"].is_array()
                && !j["choices"].empty() && j["choices"][0].is_object()
                && j["choices"][0].contains("message") && j["choices"][0]["message"].is_object()) {
                auto& msg = j["choices"][0]["message"];
                if (msg.contains("content") && msg["content"].is_string())
                    r.content = msg["content"].get<std::string>();
                if (msg.contains("tool_calls") && msg["tool_calls"].is_array()) {
                    for (const auto& tc : msg["tool_calls"]) {
                        if (!tc.is_object() || !tc.contains("function") || !tc["function"].is_object()) continue;
                        ToolCall c; c.id=tc.value("id",""); c.type=tc.value("type","function");
                        c.name=tc["function"].value("name","");
                        try { c.arguments = nlohmann::json::parse(tc["function"].value("arguments","{}")); }
                        catch(...) { c.arguments = nlohmann::json::object(); }
                        if (!c.name.empty()) r.tool_calls.push_back(c);
                    }
                }
            }
            if (j.contains("usage") && j["usage"].is_object()) {
                r.input_tokens = j["usage"].value("prompt_tokens",0);
                r.output_tokens = j["usage"].value("completion_tokens",0);
            }
        } catch (...) {}
    }

    r.success = !r.content.empty() || !r.tool_calls.empty();
    return r;
}

// ══════════════════════════════════════════════════
// DeepSeek Implementation
// ══════════════════════════════════════════════════
ChatResponse DeepSeekAdapter::sendStreaming(
    const std::string& key, const std::string& model,
    const std::vector<ChatMessage>& msgs, const std::vector<ToolSchema>& tools,
    std::function<void(const std::string&)> onChunk)
{
    ChatResponse r;
    if (onChunk) {
        SseResult sse;
        auto body = OpenAIAdapter::buildBody(model, msgs, tools, true);
        curlPostSSE_v2("https://api.deepseek.com/v1/chat/completions", body.dump(), key, onChunk, sse);
        r.content = sse.text; r.tool_calls = sse.tool_calls;
        r.input_tokens = sse.input_tokens; r.output_tokens = sse.output_tokens;
    } else {
        OpenAIAdapter oai;
        r = oai.send(key, model, msgs, tools);
    }
    r.success = !r.content.empty() || !r.tool_calls.empty();
    return r;
}

// ══════════════════════════════════════════════════
// Ollama Implementation
// ══════════════════════════════════════════════════
ChatResponse OllamaAdapter::sendStreaming(
    const std::string&, const std::string& model,
    const std::vector<ChatMessage>& msgs, const std::vector<ToolSchema>&,
    std::function<void(const std::string&)> onChunk)
{
    ChatResponse r;
    nlohmann::json body;
    body["model"] = model; body["stream"] = (onChunk != nullptr);
    body["messages"] = nlohmann::json::array();
    for (const auto& m : msgs)
        body["messages"].push_back({{"role",m.role},{"content",m.content}});
    std::string raw = curlPost("http://localhost:11434/api/chat", body.dump(), "", "Ollama");
    try {
        std::istringstream ls(raw); std::string line;
        while (std::getline(ls, line)) {
            if (line.empty()) continue;
            try {
                auto j = nlohmann::json::parse(line);
                if (j.contains("message") && j["message"].contains("content")) {
                    std::string t = j["message"]["content"].get<std::string>();
                    if (onChunk && !t.empty()) onChunk(t);
                    r.content += t;
                }
            } catch (...) {}
        }
        if (r.content.empty()) {
            auto j = nlohmann::json::parse(raw);
            if (j.contains("message") && j["message"].contains("content"))
                r.content = j["message"]["content"].get<std::string>();
        }
        r.success = !r.content.empty();
    } catch (...) {}
    return r;
}

// ══════════════════════════════════════════════════
// Factory
// ══════════════════════════════════════════════════
std::unique_ptr<IModelAdapter> AdapterFactory::create(ProviderType p) {
    switch (p) {
        case ProviderType::Claude:   return std::make_unique<ClaudeAdapter>();
        case ProviderType::OpenAI:   return std::make_unique<OpenAIAdapter>();
        case ProviderType::DeepSeek: return std::make_unique<DeepSeekAdapter>();
        case ProviderType::Ollama:   return std::make_unique<OllamaAdapter>();
        default: return nullptr;
    }
}

} // namespace axiom
