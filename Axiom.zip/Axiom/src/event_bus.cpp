#include "axiom/event_bus.hpp"
#include <chrono>
#include <algorithm>

namespace axiom {

EventBus::HandlerId EventBus::subscribe(EventType type, Handler handler) {
    std::lock_guard<std::mutex> lock(mutex_);
    HandlerId id = next_id_++;
    subscribers_[type].emplace_back(id, std::move(handler));
    return id;
}

EventBus::HandlerId EventBus::subscribeAll(Handler handler) {
    std::lock_guard<std::mutex> lock(mutex_);
    HandlerId id = next_id_++;
    catchall_subscribers_.emplace_back(id, std::move(handler));
    return id;
}

void EventBus::unsubscribe(HandlerId id) {
    std::lock_guard<std::mutex> lock(mutex_);

    for (auto& [type, handlers] : subscribers_) {
        handlers.erase(
            std::remove_if(handlers.begin(), handlers.end(),
                [id](const auto& pair) { return pair.first == id; }),
            handlers.end());
    }

    catchall_subscribers_.erase(
        std::remove_if(catchall_subscribers_.begin(), catchall_subscribers_.end(),
            [id](const auto& pair) { return pair.first == id; }),
        catchall_subscribers_.end());
}

void EventBus::publish(const Event& event) {
    // 记录时间戳
    Event timestamped = event;
    timestamped.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();

    // 记录历史
    {
        std::lock_guard<std::mutex> lock(mutex_);
        history_.push_back(timestamped);
        if (history_.size() > kMaxHistory) {
            history_.erase(history_.begin());
        }
    }

    // 分发给类型订阅者
    {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = subscribers_.find(event.type);
        if (it != subscribers_.end()) {
            for (const auto& [id, handler] : it->second) {
                handler(timestamped);
            }
        }
    }

    // 分发给全类型订阅者
    {
        std::lock_guard<std::mutex> lock(mutex_);
        for (const auto& [id, handler] : catchall_subscribers_) {
            handler(timestamped);
        }
    }
}

void EventBus::publishAsync(const Event& event) {
    std::lock_guard<std::mutex> lock(mutex_);
    async_queue_.push(event);
}

void EventBus::pump() {
    std::queue<Event> pending;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        std::swap(pending, async_queue_);
    }

    while (!pending.empty()) {
        publish(pending.front());
        pending.pop();
    }
}

std::vector<Event> EventBus::recentEvents(size_t maxCount) const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (history_.size() <= maxCount) return history_;

    std::vector<Event> result;
    size_t start = history_.size() - maxCount;
    for (size_t i = start; i < history_.size(); ++i) {
        result.push_back(history_[i]);
    }
    return result;
}

void EventBus::clearHistory() {
    std::lock_guard<std::mutex> lock(mutex_);
    history_.clear();
}

size_t EventBus::historySize() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return history_.size();
}

} // namespace axiom
