#include "axiom/cli.hpp"
#include <iostream>

int main(int argc, char* argv[]) {
    axiom::Runtime runtime;
    axiom::CLI cli(runtime);
    return cli.run(argc, argv);
}
