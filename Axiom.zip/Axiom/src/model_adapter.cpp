#include "axiom/model_adapter.hpp"
#include <algorithm>

namespace axiom {

// AdapterFactory::create() is defined in claude_adapter.cpp
// (needs to see concrete adapter class definitions)

ProviderType AdapterFactory::detectProvider(const std::string& url) {
    std::string lower = url;
    std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);

    if (lower.find("anthropic") != std::string::npos)  return ProviderType::Claude;
    if (lower.find("openai") != std::string::npos)     return ProviderType::OpenAI;
    if (lower.find("deepseek") != std::string::npos)   return ProviderType::DeepSeek;
    if (lower.find("localhost") != std::string::npos ||
        lower.find("127.0.0.1") != std::string::npos ||
        lower.find("ollama") != std::string::npos)     return ProviderType::Ollama;

    return ProviderType::Unknown;
}

std::string AdapterFactory::providerName(ProviderType p) {
    switch (p) {
        case ProviderType::Claude:   return "Anthropic Claude";
        case ProviderType::OpenAI:   return "OpenAI";
        case ProviderType::DeepSeek: return "DeepSeek";
        case ProviderType::Ollama:   return "Ollama/LlamaCpp";
        default: return "Unknown";
    }
}

} // namespace axiom
