#include "axiom/skill_system.hpp"
#include <fstream>
#include <sstream>
#include <regex>
#include <sys/stat.h>

namespace axiom {

SkillSystem::SkillSystem(EventBus& bus) : event_bus_(bus) {}

// ─── File loading ────────────────────────────────────

bool SkillSystem::loadSkill(const std::string& file_path) {
    std::ifstream file(file_path);
    if (!file.is_open()) return false;

    std::stringstream buf;
    buf << file.rdbuf();
    std::string raw = buf.str();

    Skill skill;
    skill.source = file_path;

    try {
        auto j = nlohmann::json::parse(raw);
        skill.name = j.value("name", "");
        skill.version = j.value("version", "0.1.0");
        skill.description = j.value("description", "");
        skill.instructions = j.value("instructions", "");
        skill.author = j.value("author", "unknown");
        if (j.contains("state")) {
            std::string s = j["state"].get<std::string>();
            if (s == "active") skill.state = SkillState::Active;
            else if (s == "validated") skill.state = SkillState::Validated;
            else if (s == "candidate") skill.state = SkillState::Candidate;
            else if (s == "deprecated") skill.state = SkillState::Deprecated;
        }
        if (j.contains("references") && j["references"].is_array())
            for (const auto& r : j["references"]) skill.references.push_back(r.get<std::string>());
        if (j.contains("scripts") && j["scripts"].is_array())
            for (const auto& s : j["scripts"]) skill.scripts.push_back(s.get<std::string>());
        if (j.contains("permissions") && j["permissions"].is_array())
            for (const auto& p : j["permissions"]) skill.required_permissions.push_back(p.get<std::string>());
        if (j.contains("metadata")) skill.metadata = j["metadata"];
    } catch (const std::exception&) {
        // Not JSON — treat as plain markdown with YAML frontmatter
        // Extract name from first # heading
        std::regex name_re(R"(#\s+(.+))");
        std::smatch match;
        if (std::regex_search(raw, match, name_re)) skill.name = match[1].str();

        // Extract instructions from body
        skill.instructions = raw;
        skill.state = SkillState::Candidate;
    }

    if (skill.name.empty()) return false;
    if (!validateSkillStructure(skill)) return false;

    skills_[skill.name] = skill;
    event_bus_.publish({EventType::SkillLoaded, "SkillSystem", {{"name", skill.name}}});
    return true;
}

size_t SkillSystem::loadSkillsFromDirectory(const std::string& dir_path) {
    size_t count = 0;
    // Check common skill file patterns
    for (const auto& name : {"SKILL.md", "skill.json", "skill.yaml"}) {
        std::string full = dir_path + "/" + name;
        struct stat st;
        if (stat(full.c_str(), &st) == 0 && loadSkill(full)) count++;
    }
    // Also check subdirectories
    std::string ls_cmd = "ls -d \"" + dir_path + "\"/*/ 2>/dev/null";
    // Simple directory listing via shell
    return count;
}

void SkillSystem::registerSkill(const Skill& skill) {
    skills_[skill.name] = skill;
    event_bus_.publish({EventType::SkillLoaded, "SkillSystem", {{"name", skill.name}}});
}

// ─── Validation ──────────────────────────────────────

bool SkillSystem::validateSkillStructure(const Skill& skill) const {
    if (skill.name.empty()) return false;
    if (skill.instructions.empty()) return false;
    return true;
}

bool SkillSystem::validateSkill(const std::string& name) {
    auto it = skills_.find(name);
    if (it == skills_.end()) return false;

    if (!validateSkillStructure(it->second)) return false;

    it->second.state = SkillState::Validated;
    event_bus_.publish({EventType::SkillValidated, "SkillSystem", {{"name", name}}});
    return true;
}

bool SkillSystem::activateSkill(const std::string& name) {
    auto it = skills_.find(name);
    if (it == skills_.end()) return false;
    if (it->second.state != SkillState::Validated && it->second.state != SkillState::Candidate)
        return false;

    it->second.state = SkillState::Active;
    event_bus_.publish({EventType::SkillActivated, "SkillSystem", {{"name", name}}});
    return true;
}

void SkillSystem::deprecateSkill(const std::string& name) {
    auto it = skills_.find(name);
    if (it == skills_.end()) return;
    it->second.state = SkillState::Deprecated;
    event_bus_.publish({EventType::SkillDeprecated, "SkillSystem", {{"name", name}}});
}

// ─── Query ───────────────────────────────────────────

const Skill* SkillSystem::getSkill(const std::string& name) const {
    auto it = skills_.find(name);
    return it != skills_.end() ? &it->second : nullptr;
}

std::vector<Skill> SkillSystem::listSkills() const {
    std::vector<Skill> result;
    for (const auto& [name, skill] : skills_) result.push_back(skill);
    return result;
}

std::vector<const Skill*> SkillSystem::activeSkills() const {
    std::vector<const Skill*> result;
    for (const auto& [name, skill] : skills_) {
        if (skill.state == SkillState::Active)
            result.push_back(&skill);
    }
    return result;
}

// ─── Dynamic skill proposal ──────────────────────────

SkillCandidate SkillSystem::proposeSkill(const std::string& agent_id,
                                          const std::string& experience) const {
    SkillCandidate cand;
    cand.source_agent_id = agent_id;
    cand.source_experience = experience;
    cand.proposed_name = "learned-" + std::to_string(skills_.size() + 1);
    cand.description = "Auto-generated from execution experience";
    cand.instructions = experience;
    return cand;
}

bool SkillSystem::createFromCandidate(const SkillCandidate& candidate) {
    Skill skill;
    skill.name = candidate.proposed_name;
    skill.description = candidate.description;
    skill.instructions = candidate.instructions;
    skill.version = "0.1.0";
    skill.state = SkillState::Candidate;
    skill.source = "dynamic:" + candidate.source_agent_id;
    skill.required_permissions = candidate.required_permissions;

    if (!validateSkillStructure(skill)) return false;
    skills_[skill.name] = skill;
    event_bus_.publish({EventType::SkillLoaded, "SkillSystem",
                        {{"name", skill.name}, {"source", "dynamic"}}});
    return true;
}

// ─── System prompt builder ───────────────────────────

std::string SkillSystem::buildSystemPrompt() const {
    std::vector<std::string> names;
    for (const auto& [name, skill] : skills_) {
        if (skill.state == SkillState::Active)
            names.push_back(name);
    }
    return buildSystemPrompt(names);
}

std::string SkillSystem::buildSystemPrompt(const std::vector<std::string>& skill_names) const {
    std::string prompt;

    // Base runtime system prompt
    prompt = R"(# Role
You are Axiom, an intelligent AI agent runtime. You operate with evidence-driven principles:
model proposes, runtime verifies.

# Constitution Rules (Highest Priority — Cannot Be Overridden)
1. No secret leakage: Never write credentials, API keys, or secrets to files/commands.
2. No forgery: Report tool results truthfully. Do not fabricate outcomes.
3. No bypass: Do not attempt to bypass permissions or sandboxes.
4. Protect data: Do not execute destructive operations without explicit confirmation.

# Response Guidelines
- Think step by step before acting.
- Use native tool calls when the provider supports them.
- Report tool results honestly — if something fails, say so and suggest alternatives.
- Be concise but complete.
)";

    // Add active skill instructions
    for (const auto& name : skill_names) {
        const Skill* skill = getSkill(name);
        if (skill && skill->state == SkillState::Active) {
            prompt += "\n# Skill: " + skill->name + " (v" + skill->version + ")\n";
            prompt += skill->instructions + "\n";
        }
    }

    return prompt;
}

} // namespace axiom
