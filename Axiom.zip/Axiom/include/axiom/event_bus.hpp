#ifndef AXIOM_EVENT_BUS_HPP
#define AXIOM_EVENT_BUS_HPP

#include <string>
#include <vector>
#include <functional>
#include <unordered_map>
#include <queue>
#include <mutex>
#include <nlohmann/json.hpp>

namespace axiom {

// ─── 事件类型 ───────────────────────────────────────────
enum class EventType {
    AgentStarted, AgentPaused, AgentResumed, AgentCompleted, AgentFailed,
    ToolPreCall, ToolPostCall, ToolTimeout, ToolCancelled,
    PermissionRequested, PermissionGranted, PermissionDenied,
    SkillLoaded, SkillValidated, SkillActivated, SkillDeprecated,
    FileChanged, FileCreated, FileDeleted,
    RuntimeStarting, RuntimeReady, RuntimeStopping, RuntimeError,
    UserPromptSubmitted, UserInterrupted,
    ModelRequestSent, ModelResponseReceived, ModelStreamChunk
};

inline const char* eventTypeName(EventType t) {
    switch (t) {
        case EventType::AgentStarted:  return "AgentStarted";
        case EventType::AgentPaused:   return "AgentPaused";
        case EventType::AgentResumed:  return "AgentResumed";
        case EventType::AgentCompleted:return "AgentCompleted";
        case EventType::AgentFailed:   return "AgentFailed";
        case EventType::ToolPreCall:   return "ToolPreCall";
        case EventType::ToolPostCall:  return "ToolPostCall";
        case EventType::ToolTimeout:   return "ToolTimeout";
        case EventType::ToolCancelled: return "ToolCancelled";
        case EventType::PermissionRequested: return "PermissionRequested";
        case EventType::PermissionGranted:   return "PermissionGranted";
        case EventType::PermissionDenied:    return "PermissionDenied";
        case EventType::SkillLoaded:    return "SkillLoaded";
        case EventType::SkillValidated: return "SkillValidated";
        case EventType::SkillActivated: return "SkillActivated";
        case EventType::SkillDeprecated:return "SkillDeprecated";
        case EventType::FileChanged:   return "FileChanged";
        case EventType::FileCreated:   return "FileCreated";
        case EventType::FileDeleted:   return "FileDeleted";
        case EventType::RuntimeStarting: return "RuntimeStarting";
        case EventType::RuntimeReady:  return "RuntimeReady";
        case EventType::RuntimeStopping: return "RuntimeStopping";
        case EventType::RuntimeError:  return "RuntimeError";
        case EventType::UserPromptSubmitted: return "UserPromptSubmitted";
        case EventType::UserInterrupted:     return "UserInterrupted";
        case EventType::ModelRequestSent:    return "ModelRequestSent";
        case EventType::ModelResponseReceived: return "ModelResponseReceived";
        case EventType::ModelStreamChunk:    return "ModelStreamChunk";
        default: return "Unknown";
    }
}

// ─── 事件数据 ───────────────────────────────────────────
struct Event {
    EventType type;
    std::string source;       // 来源模块名
    std::string agent_id;     // 关联 Agent（可选）
    nlohmann::json data;      // 事件负载
    int64_t timestamp;        // epoch ms

    Event() : type(EventType::RuntimeError), timestamp(0) {}
    Event(EventType t, std::string src, nlohmann::json d = {})
        : type(t), source(std::move(src)), data(std::move(d)), timestamp(0) {}

    std::string typeName() const { return eventTypeName(type); }
};

// ─── Event Bus ──────────────────────────────────────────
class EventBus {
public:
    using Handler = std::function<void(const Event&)>;
    using HandlerId = uint64_t;

    EventBus() = default;
    ~EventBus() = default;

    // 订阅事件（同步回调，在 publish 线程中执行）
    HandlerId subscribe(EventType type, Handler handler);

    // 订阅所有事件
    HandlerId subscribeAll(Handler handler);

    // 取消订阅
    void unsubscribe(HandlerId id);

    // 发布事件（同步通知所有订阅者）
    void publish(const Event& event);

    // 发布事件（放入异步队列，由 pump() 分发）
    void publishAsync(const Event& event);

    // 处理异步队列中的所有事件
    void pump();

    // 获取历史事件（用于调试/回放）
    std::vector<Event> recentEvents(size_t maxCount = 100) const;

    // 清空历史
    void clearHistory();

    // 事件数量统计
    size_t historySize() const;

private:
    HandlerId next_id_ = 1;
    mutable std::mutex mutex_;

    // 同步订阅：事件类型 → [(id, handler)]
    std::unordered_map<EventType, std::vector<std::pair<HandlerId, Handler>>> subscribers_;

    // "*" 订阅者（所有事件）
    std::vector<std::pair<HandlerId, Handler>> catchall_subscribers_;

    // 异步队列
    std::queue<Event> async_queue_;

    // 历史记录
    std::vector<Event> history_;
    static constexpr size_t kMaxHistory = 1000;
};

} // namespace axiom

#endif // AXIOM_EVENT_BUS_HPP
