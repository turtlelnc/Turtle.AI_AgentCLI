#ifndef AXIOM_RUNTIME_HPP
#define AXIOM_RUNTIME_HPP

#include <string>
#include <memory>
#include "event_bus.hpp"
#include "agent_engine.hpp"
#include "tool_system.hpp"
#include "policy_engine.hpp"
#include "skill_system.hpp"
#include "model_adapter.hpp"
#include "token_tracker.hpp"
#include "git_manager.hpp"

namespace axiom {

// ─── Runtime 配置 ───────────────────────────────────────
struct RuntimeConfig {
    ProviderType provider = ProviderType::Unknown;
    std::string api_url;
    std::string api_key;
    std::string model;
    std::string work_dir = ".";
    bool use_git = true;
    bool stream_output = true;
    std::string skills_dir;          // Skill 文件目录
    std::string system_skill_name;   // 默认系统 Skill
};

// ─── Runtime ────────────────────────────────────────────
class Runtime {
public:
    Runtime();
    explicit Runtime(const RuntimeConfig& config);
    ~Runtime();

    // 初始化：创建所有模块并连接
    bool initialize(const RuntimeConfig& config);

    // 启动 Runtime
    void start();

    // 优雅关闭
    void shutdown();

    // 运行一次用户提示词
    std::string processUserPrompt(const std::string& prompt);

    // 获取各模块引用
    EventBus& eventBus() { return *event_bus_; }
    AgentEngine& agentEngine() { return *agent_engine_; }
    ToolBroker& toolBroker() { return *tool_broker_; }
    PolicyEngine& policyEngine() { return *policy_engine_; }
    SkillSystem& skillSystem() { return *skill_system_; }
    IModelAdapter& modelAdapter() { return *model_adapter_; }
    TokenTracker& tokenTracker() { return *token_tracker_; }
    GitManager& gitManager() { return *git_manager_; }

    // 状态
    bool isRunning() const { return running_; }
    RuntimeConfig config() const { return config_; }

    // 自助检测（无需 API key，编译后即可运行）
    bool selfTestEventBus();
    bool selfTestPolicy();
    bool selfTestToolSystem();
    bool selfTestSkills();
    bool selfTestMarkdown();
    bool selfTestAll();  // 运行全部

private:
    RuntimeConfig config_;
    bool running_ = false;

    std::unique_ptr<EventBus> event_bus_;
    std::unique_ptr<ToolBroker> tool_broker_;
    std::unique_ptr<PolicyEngine> policy_engine_;
    std::unique_ptr<SkillSystem> skill_system_;
    std::unique_ptr<IModelAdapter> model_adapter_;
    std::unique_ptr<AgentEngine> agent_engine_;
    std::unique_ptr<TokenTracker> token_tracker_;
    std::unique_ptr<GitManager> git_manager_;
};

} // namespace axiom

#endif // AXIOM_RUNTIME_HPP
