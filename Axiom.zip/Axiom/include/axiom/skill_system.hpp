#ifndef AXIOM_SKILL_SYSTEM_HPP
#define AXIOM_SKILL_SYSTEM_HPP

#include <string>
#include <vector>
#include <unordered_map>
#include <memory>
#include <nlohmann/json.hpp>
#include "event_bus.hpp"

namespace axiom {

// ─── Skill 状态 ─────────────────────────────────────────
enum class SkillState {
    Draft,      // 创建但未验证
    Candidate,  // 待验证
    Validated,  // 验证通过
    Active,     // 已激活可用
    Deprecated  // 已弃用
};

inline const char* skillStateName(SkillState s) {
    switch (s) {
        case SkillState::Draft:      return "draft";
        case SkillState::Candidate:  return "candidate";
        case SkillState::Validated:  return "validated";
        case SkillState::Active:     return "active";
        case SkillState::Deprecated: return "deprecated";
        default: return "unknown";
    }
}

// ─── Skill 定义 ─────────────────────────────────────────
struct Skill {
    std::string name;             // 唯一标识
    std::string version;          // 语义化版本
    SkillState state = SkillState::Draft;
    std::string description;      // 简短描述
    std::string instructions;     // 核心指令（给 LLM 的提示词）
    std::string author;
    std::string source;           // 来源：文件路径 或 "dynamic:<agent_id>"

    // 资源文件路径（相对于 Skill 目录）
    std::vector<std::string> references;   // 参考文档
    std::vector<std::string> scripts;      // 可执行脚本
    std::vector<std::string> examples;     // 示例

    // 权限要求
    std::vector<std::string> required_permissions;

    // 元数据
    nlohmann::json metadata;
};

// ─── Skill 候选（动态生成） ─────────────────────────────
struct SkillCandidate {
    std::string proposed_name;
    std::string description;
    std::string instructions;
    std::string source_agent_id;   // 来源 Agent
    std::string source_experience; // 执行经验描述
    std::vector<std::string> required_permissions;
};

// ─── SkillSystem ─────────────────────────────────────────
class SkillSystem {
public:
    SkillSystem(EventBus& bus);

    // 从文件加载 Skill（JSON/YAML）
    bool loadSkill(const std::string& file_path);

    // 从目录批量加载
    size_t loadSkillsFromDirectory(const std::string& dir_path);

    // 手动注册 Skill
    void registerSkill(const Skill& skill);

    // 验证 Skill
    bool validateSkill(const std::string& name);

    // 激活 Skill
    bool activateSkill(const std::string& name);

    // 弃用 Skill
    void deprecateSkill(const std::string& name);

    // 获取 Skill
    const Skill* getSkill(const std::string& name) const;

    // 列出所有 Skill
    std::vector<Skill> listSkills() const;

    // 列出活跃的 Skill
    std::vector<const Skill*> activeSkills() const;

    // 动态 Skill 提议（从执行经验生成）
    SkillCandidate proposeSkill(const std::string& agent_id,
                                const std::string& experience) const;

    // 从候选创建 Skill
    bool createFromCandidate(const SkillCandidate& candidate);

    // 获取所有活跃 Skill 的组合系统提示词
    std::string buildSystemPrompt() const;

    // 获取指定 Skill 列表的系统提示词
    std::string buildSystemPrompt(const std::vector<std::string>& skill_names) const;

private:
    EventBus& event_bus_;
    std::unordered_map<std::string, Skill> skills_;

    bool validateSkillStructure(const Skill& skill) const;
};

} // namespace axiom

#endif // AXIOM_SKILL_SYSTEM_HPP
