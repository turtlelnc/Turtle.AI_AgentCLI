#ifndef AXIOM_TOOL_SYSTEM_HPP
#define AXIOM_TOOL_SYSTEM_HPP

#include <string>
#include <vector>
#include <functional>
#include <chrono>
#include <nlohmann/json.hpp>
#include "event_bus.hpp"
#include "model_adapter.hpp"

namespace axiom {

// ─── 工具定义 ───────────────────────────────────────────
struct ToolDefinition {
    std::string name;
    std::string description;
    nlohmann::json parameters;       // JSON Schema
    std::function<nlohmann::json(const nlohmann::json&)> handler;
};

// ─── 工具调用结果 ──────────────────────────────────────
struct ToolResult {
    bool success;
    std::string output;
    nlohmann::json data;
    int exit_code = 0;
    std::chrono::milliseconds duration;
};

// ─── Sandbox ─────────────────────────────────────────────
class Sandbox {
public:
    Sandbox();

    // 检查命令是否被允许
    bool isAllowed(const std::string& command) const;

    // 获取拦截原因（isAllowed == false 时调用）
    std::string blockReason(const std::string& command) const;

    // 是否为危险命令
    bool isDangerous(const std::string& command) const;

    // 包装为沙盒命令（未来扩展：bubblewrap/firejail）
    std::string wrap(const std::string& command) const;

    // 添加自定义允许前缀
    void addAllowedPrefix(const std::string& prefix);
    void addBlockedPattern(const std::string& pattern);

private:
    std::vector<std::string> allowed_prefixes_;
    std::vector<std::string> dangerous_patterns_;
};

// ─── ToolBroker ──────────────────────────────────────────
class ToolBroker {
public:
    ToolBroker(EventBus& bus);

    // 注册工具
    void registerTool(const ToolDefinition& tool);

    // 注册内置工具（文件读写、终端命令等）
    void registerBuiltinTools();

    // 执行工具调用（包含权限检查）
    ToolResult execute(const std::string& name, const nlohmann::json& params);

    // 取消工具调用
    void cancel(const std::string& callId);

    // 获取工具 Schema 列表（给 LLM 用）
    std::vector<ToolSchema> getToolsSchema() const;

    // 检查工具是否存在
    bool hasTool(const std::string& name) const;

    // 获取工具定义
    const ToolDefinition* getTool(const std::string& name) const;

private:
    EventBus& event_bus_;
    Sandbox sandbox_;
    std::vector<ToolDefinition> tools_;

    // 内置工具实现
    nlohmann::json toolReadFile(const nlohmann::json& args);
    nlohmann::json toolWriteFile(const nlohmann::json& args);
    nlohmann::json toolEditFile(const nlohmann::json& args);
    nlohmann::json toolListDirectory(const nlohmann::json& args);
    nlohmann::json toolRunTerminal(const nlohmann::json& args);
    nlohmann::json toolSearchFiles(const nlohmann::json& args);
    nlohmann::json toolGrep(const nlohmann::json& args);

    std::string executeShell(const std::string& cmd);
    bool writeFileContent(const std::string& path, const std::string& content);
    std::string readFileContent(const std::string& path);
};

} // namespace axiom

#endif // AXIOM_TOOL_SYSTEM_HPP
