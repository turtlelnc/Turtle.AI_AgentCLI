#ifndef AXIOM_CLI_HPP
#define AXIOM_CLI_HPP

#include <string>
#include <vector>
#include <memory>
#include <atomic>
#include "runtime.hpp"
#include "markdown.hpp"

namespace axiom {

class CLI {
public:
    CLI(Runtime& runtime);
    ~CLI();

    // 主入口：启动交互式 CLI
    int run(int argc, char* argv[]);

private:
    Runtime& runtime_;
    MarkdownRenderer md_;

    // 显示
    void showWelcome();
    void showBanner();
    void showHelp();
    void showAgentStatus();
    void showSessionSummary();

    // 配置向导
    bool runConfigWizard();

    // 对话循环
    void chatLoop();

    // 输入输出
    std::string getInput(const std::string& prompt);
    void displayAIResponse(const std::string& content);
    void displayToolExecution(const std::string& name, const ToolResult& result);
    void displayError(const std::string& message);
    void clearScreen();

    // UTF-8 工具
    static std::string fixUtf8Encoding(const std::string& input);

    // 内部命令处理
    bool handleInternalCommand(const std::string& input);

    // 配置持久化
    void saveConfig();
    bool loadConfig();

    // 配置状态
    ProviderType selected_provider_ = ProviderType::Unknown;
    std::string api_key_;
    std::string model_;
    std::string work_dir_;
    bool use_git_ = false;
};

} // namespace axiom

#endif // AXIOM_CLI_HPP
