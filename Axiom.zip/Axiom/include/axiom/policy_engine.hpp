#ifndef AXIOM_POLICY_ENGINE_HPP
#define AXIOM_POLICY_ENGINE_HPP

#include <string>
#include <vector>
#include <chrono>
#include <unordered_map>
#include <nlohmann/json.hpp>
#include "event_bus.hpp"

namespace axiom {

// ─── 能力式权限 ─────────────────────────────────────────
enum class Capability {
    FilesystemRead,
    FilesystemWrite,
    ProcessExecute,
    NetworkConnect,
    GitRead,
    GitWrite,
    RuntimeUpdate
};

inline const char* capabilityName(Capability c) {
    switch (c) {
        case Capability::FilesystemRead:  return "filesystem.read";
        case Capability::FilesystemWrite: return "filesystem.write";
        case Capability::ProcessExecute:  return "process.execute";
        case Capability::NetworkConnect:  return "network.connect";
        case Capability::GitRead:         return "git.read";
        case Capability::GitWrite:        return "git.write";
        case Capability::RuntimeUpdate:   return "runtime.update";
        default: return "unknown";
    }
}

// ─── 权限授予 ───────────────────────────────────────────
struct Permission {
    Capability capability;
    std::string scope;               // 范围（路径、域名等，空=无限制）
    std::chrono::seconds lifetime;   // 有效期
    std::string source;              // "user", "constitution", "skill:<name>"
    std::chrono::system_clock::time_point granted_at;

    bool isExpired() const {
        return std::chrono::system_clock::now() > granted_at + lifetime;
    }
};

// ─── Constitution（不可违背的核心规则）──────────────────
class Constitution {
public:
    Constitution();

    // 验证一个行动是否合法
    bool validate(const std::string& action_type, const nlohmann::json& params) const;

    // 获取违规原因
    std::string violationReason(const std::string& action_type, const nlohmann::json& params) const;

    // 核心规则列表
    std::vector<std::string> rules() const;

private:
    struct Rule {
        std::string name;
        std::function<bool(const std::string& action_type, const nlohmann::json& params)> check;
        std::string description;
    };
    std::vector<Rule> rules_;
};

// ─── Policy Engine ───────────────────────────────────────
class PolicyEngine {
public:
    PolicyEngine(EventBus& bus);

    // 检查 Agent 是否有权执行指定操作
    bool checkPermission(const std::string& agent_id,
                         Capability capability,
                         const std::string& scope = "") const;

    // 检查是否违反 Constitution
    bool checkConstitution(const std::string& action_type,
                           const nlohmann::json& params,
                           std::string& out_reason) const;

    // 授予临时权限（用户批准）
    void grantTemporary(const std::string& agent_id,
                        Capability capability,
                        std::chrono::seconds lifetime,
                        const std::string& scope = "");

    // 撤销权限
    void revoke(const std::string& agent_id, Capability capability);

    // 加载配置
    void loadConfig(const nlohmann::json& config);
    nlohmann::json getConfig() const;

    // API Key 掩码
    static std::string maskApiKey(const std::string& key);

    const Constitution& constitution() const { return constitution_; }

private:
    EventBus& event_bus_;
    Constitution constitution_;

    // agent_id → [(capability, scope, lifetime, source)]
    std::unordered_map<std::string, std::vector<Permission>> grants_;

    // 全局默认权限策略
    bool default_deny_all_ = false;
    std::vector<Capability> default_allowed_;
};

} // namespace axiom

#endif // AXIOM_POLICY_ENGINE_HPP
