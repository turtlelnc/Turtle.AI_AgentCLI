#ifndef AXIOM_MODEL_ADAPTER_HPP
#define AXIOM_MODEL_ADAPTER_HPP

#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <nlohmann/json.hpp>

namespace axiom {

// ─── 消息结构（从旧项目复用） ──────────────────────────
struct ToolCall {
    std::string id;
    std::string type;
    std::string name;
    nlohmann::json arguments;  // OpenAI format
    nlohmann::json input;      // Anthropic format
};

struct ChatMessage {
    std::string role;  // "system", "user", "assistant", "tool"
    std::string content;
    nlohmann::json content_blocks = nullptr;  // Anthropic multi-block
    std::string tool_call_id;                 // OpenAI tool message
    std::vector<ToolCall> tool_calls;          // Assistant tool calls
};

struct ChatResponse {
    std::string content;
    std::vector<ToolCall> tool_calls;
    int64_t input_tokens = 0;
    int64_t output_tokens = 0;
    bool success = false;
    std::string error_message;
    nlohmann::json content_blocks;  // Anthropic raw response
};

struct ToolSchema {
    std::string name;
    std::string description;
    nlohmann::json parameters;  // JSON Schema
};

// ─── 抽象模型适配器接口 ──────────────────────────────────
class IModelAdapter {
public:
    virtual ~IModelAdapter() = default;

    // 提供商名称
    virtual std::string providerName() const = 0;

    // 默认模型
    virtual std::string defaultModel() const = 0;

    // 支持的工具调用格式：native（API原生）| xml_fallback
    virtual bool supportsNativeTools() const { return true; }

    // 发送聊天请求（非流式）
    virtual ChatResponse send(
        const std::string& api_key,
        const std::string& model,
        const std::vector<ChatMessage>& messages,
        const std::vector<ToolSchema>& tools) = 0;

    // 发送流式请求
    virtual ChatResponse sendStreaming(
        const std::string& api_key,
        const std::string& model,
        const std::vector<ChatMessage>& messages,
        const std::vector<ToolSchema>& tools,
        std::function<void(const std::string& chunk)> onChunk) = 0;

    // 支持的模型列表
    virtual std::vector<std::string> availableModels() const = 0;
};

// ─── 适配器工厂 ──────────────────────────────────────────
enum class ProviderType {
    Claude,
    OpenAI,
    DeepSeek,
    Ollama,
    Unknown
};

class AdapterFactory {
public:
    static std::unique_ptr<IModelAdapter> create(ProviderType provider);
    static std::unique_ptr<IModelAdapter> createFromUrl(const std::string& url);
    static ProviderType detectProvider(const std::string& url);
    static std::string providerName(ProviderType p);
};

} // namespace axiom

#endif // AXIOM_MODEL_ADAPTER_HPP
