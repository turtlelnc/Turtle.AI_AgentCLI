#ifndef AXIOM_TOKEN_TRACKER_HPP
#define AXIOM_TOKEN_TRACKER_HPP

#include <string>
#include <unordered_map>
#include <cstdint>

namespace axiom {

struct ModelPricing {
    double input_price_per_1m;   // USD per 1M input tokens
    double output_price_per_1m;  // USD per 1M output tokens
};

class TokenTracker {
public:
    TokenTracker();

    void setModel(const std::string& model);
    void recordTokens(int64_t input_tokens, int64_t output_tokens);

    int64_t getTotalInputTokens() const;
    int64_t getTotalOutputTokens() const;
    double getTotalCostUSD() const;

    void reset();

    static ModelPricing getModelPrice(const std::string& model);

private:
    std::string current_model_;
    int64_t total_input_tokens_;
    int64_t total_output_tokens_;
    double total_cost_usd_;

    static const std::unordered_map<std::string, ModelPricing> model_prices_;
};

} // namespace axiom

#endif // AXIOM_TOKEN_TRACKER_HPP
