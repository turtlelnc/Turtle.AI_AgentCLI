#ifndef AXIOM_AGENT_ENGINE_HPP
#define AXIOM_AGENT_ENGINE_HPP

#include <string>
#include <vector>
#include <unordered_map>
#include <memory>
#include <atomic>
#include "event_bus.hpp"
#include "model_adapter.hpp"
#include "tool_system.hpp"
#include "policy_engine.hpp"
#include "skill_system.hpp"

namespace axiom {

// ─── Agent 状态 ─────────────────────────────────────────
enum class AgentState {
    Created,
    Planning,
    Executing,
    Waiting,
    Verifying,
    Completed,
    Failed,
    Paused
};

inline const char* agentStateName(AgentState s) {
    switch (s) {
        case AgentState::Created:    return "Created";
        case AgentState::Planning:   return "Planning";
        case AgentState::Executing:  return "Executing";
        case AgentState::Waiting:    return "Waiting";
        case AgentState::Verifying:  return "Verifying";
        case AgentState::Completed:  return "Completed";
        case AgentState::Failed:     return "Failed";
        case AgentState::Paused:     return "Paused";
        default: return "Unknown";
    }
}

// ─── Agent 配置 ─────────────────────────────────────────
struct AgentConfig {
    std::string goal;                  // 任务目标
    std::string model;                 // 模型名
    std::vector<std::string> skills;   // 加载的 Skill 名
    std::vector<std::string> allowed_tools;  // 允许的工具（空=全部）
    std::string system_prompt_extra;   // 额外系统提示词
    std::string work_dir;              // 工作目录
    int max_turns = 50;                // 最大对话轮次
};

// ─── Agent ──────────────────────────────────────────────
struct Agent {
    std::string id;
    AgentConfig config;
    AgentState state = AgentState::Created;
    std::vector<ChatMessage> messages;  // 对话上下文
    int turn_count = 0;
    int64_t total_input_tokens = 0;
    int64_t total_output_tokens = 0;
    std::string parent_id;  // 父 Agent（子 Agent 时非空）

    // 临时权限
    std::vector<std::string> temporary_permissions;
};

// ─── Agent 观察者（透明化执行过程） ──────────────────────
struct AgentObserver {
    // AI 正在生成文本（流式 chunk）
    std::function<void(const std::string& chunk)> onThinking;
    // AI 完成一段思考，准备调用工具
    std::function<void()> onThinkingComplete;
    // 即将执行工具
    std::function<void(const std::string& name, const nlohmann::json& params)> onToolPreCall;
    // 工具执行完毕
    std::function<void(const std::string& name, const ToolResult& result)> onToolPostCall;
    // 一轮对话完成（tokens, cost）
    std::function<void(int64_t input_tokens, int64_t output_tokens, double cost)> onTurnComplete;
    // Agent 状态变化
    std::function<void(AgentState from, AgentState to)> onStateChange;
};

// ─── Agent Engine ────────────────────────────────────────
class AgentEngine {
public:
    AgentEngine(EventBus& bus,
                ToolBroker& tools,
                PolicyEngine& policy,
                SkillSystem& skills,
                IModelAdapter& model);

    // 设置观察者（透明化 Agent 执行过程）
    void setObserver(AgentObserver observer) { observer_ = std::move(observer); }

    // 创建 Agent
    std::string createAgent(const AgentConfig& config);

    // 创建子 Agent（受限工具集）
    std::string spawnSubAgent(const std::string& parent_id,
                              const AgentConfig& config);

    // 运行 Agent（阻塞直到完成）
    void runAgent(const std::string& id);

    // 暂停/恢复
    void pauseAgent(const std::string& id);
    void resumeAgent(const std::string& id);

    // 获取 Agent
    Agent* getAgent(const std::string& id);
    const Agent* getAgent(const std::string& id) const;

    // 设置 API Key
    void setApiKey(const std::string& key) { api_key_ = key; }
    void setModel(const std::string& model) { current_model_ = model; }

    // 获取 Token 统计
    int64_t totalInputTokens() const { return total_input_tokens_; }
    int64_t totalOutputTokens() const { return total_output_tokens_; }

    // 中断标志
    void interrupt() { interrupted_ = true; }
    void clearInterrupt() { interrupted_ = false; }

private:
    EventBus& event_bus_;
    ToolBroker& tools_;
    PolicyEngine& policy_;
    SkillSystem& skills_;
    IModelAdapter& model_adapter_;

    std::unordered_map<std::string, Agent> agents_;
    std::string api_key_;
    std::string current_model_;
    AgentObserver observer_;
    std::atomic<bool> interrupted_{false};
    int64_t total_input_tokens_ = 0;
    int64_t total_output_tokens_ = 0;

    // 内部方法
    void transitionState(Agent& agent, AgentState new_state);
    std::string buildSystemPrompt(const Agent& agent);
    bool checkToolPermission(const Agent& agent, const std::string& tool_name);
    std::string generateId();
};

} // namespace axiom

#endif // AXIOM_AGENT_ENGINE_HPP
