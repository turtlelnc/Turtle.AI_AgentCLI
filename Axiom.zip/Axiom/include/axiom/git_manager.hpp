#ifndef AXIOM_GIT_MANAGER_HPP
#define AXIOM_GIT_MANAGER_HPP

#include <string>
#include <vector>

namespace axiom {

struct GitStatus {
    bool is_repo = false;
    bool has_uncommitted_changes = false;
    bool is_ahead_remote = false;
    bool is_behind_remote = false;
    int commits_behind = 0;
    int commits_ahead = 0;
    std::vector<std::string> modified_files;
    std::string current_branch;
};

class GitManager {
public:
    GitManager();

    GitStatus checkStatus(const std::string& path);
    std::vector<std::string> getUncommittedFiles(const std::string& path);
    int checkBehindRemote(const std::string& path);

    bool pull(const std::string& path);
    bool stash(const std::string& path);
    bool stashPop(const std::string& path);
    bool checkout(const std::string& path);

    static bool isGitAvailable();

private:
    std::string executeGitCommand(const std::string& cmd, const std::string& path);
};

} // namespace axiom

#endif // AXIOM_GIT_MANAGER_HPP
