#ifndef AXIOM_MARKDOWN_HPP
#define AXIOM_MARKDOWN_HPP

#include <string>
#include <vector>
#include <functional>

namespace axiom {

// ─── ANSI 终端样式 ───────────────────────────────────
namespace Ansi {
    constexpr const char* Reset   = "\033[0m";
    constexpr const char* Bold    = "\033[1m";
    constexpr const char* Dim     = "\033[2m";
    constexpr const char* Italic  = "\033[3m";
    constexpr const char* Underline = "\033[4m";
    constexpr const char* Reverse = "\033[7m";

    // 前景色
    constexpr const char* Black   = "\033[30m";
    constexpr const char* Red     = "\033[31m";
    constexpr const char* Green   = "\033[32m";
    constexpr const char* Yellow  = "\033[33m";
    constexpr const char* Blue    = "\033[34m";
    constexpr const char* Magenta = "\033[35m";
    constexpr const char* Cyan    = "\033[36m";
    constexpr const char* White   = "\033[37m";
    constexpr const char* Gray    = "\033[90m";

    // 背景色
    constexpr const char* BgGray  = "\033[100m";
    constexpr const char* BgBlue  = "\033[44m";

    // 组合
    inline std::string bold(const std::string& s) { return std::string(Bold) + s + Reset; }
    inline std::string italic(const std::string& s) { return std::string(Italic) + s + Reset; }
    inline std::string dim(const std::string& s)   { return std::string(Dim) + s + Reset; }
    inline std::string code(const std::string& s)  { return std::string(Cyan) + s + Reset; }
    inline std::string header(const std::string& s){ return std::string(Bold) + Cyan + s + Reset; }
    inline std::string bullet()                     { return std::string(Green) + "•" + Reset; }
    inline std::string hr() {
        return std::string(Dim) + std::string(72, '-') + Reset;
    }
}

// ─── Markdown 渲染器 ──────────────────────────────────
class MarkdownRenderer {
public:
    MarkdownRenderer();

    // 渲染 markdown 文本为 ANSI 格式
    std::string render(const std::string& markdown) const;

    // 设置终端宽度
    void setWidth(int w) { width_ = w; }
    int width() const { return width_; }

private:
    int width_ = 80;

    // 分块类型
    enum class BlockType { Paragraph, Header, CodeBlock, ListItem, OrderedItem, Blockquote, HRule, Table };

    struct Block {
        BlockType type;
        int header_level = 0;  // 1-6 for headers
        std::vector<std::string> lines;
        std::string language;  // code block language hint
        std::vector<int> col_widths;  // table column widths
    };

    // 解析
    std::vector<Block> parseBlocks(const std::string& text) const;

    // 行内渲染
    std::string renderInline(const std::string& text) const;

    // 块渲染
    std::string renderBlock(const Block& block) const;
    std::string renderCodeBlock(const Block& block) const;
    std::string renderListItem(const Block& block, int order = 0) const;
    std::string renderBlockquote(const Block& block) const;
    std::string renderTable(const Block& block) const;
};

} // namespace axiom

#endif // AXIOM_MARKDOWN_HPP
