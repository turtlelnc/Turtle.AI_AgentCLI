#ifndef TOOL_POLICY_HPP
#define TOOL_POLICY_HPP

#include <string>
#include <nlohmann/json.hpp>

namespace opencode {

struct ToolApproval {
    bool required;
    std::string action;
    std::string detail;
    std::string preview;
};

class ToolPolicy {
public:
    static ToolApproval assess(
        const std::string& tool_name,
        const nlohmann::json& arguments
    );
};

} // namespace opencode

#endif // TOOL_POLICY_HPP
