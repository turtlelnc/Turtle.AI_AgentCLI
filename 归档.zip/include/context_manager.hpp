#ifndef CONTEXT_MANAGER_HPP
#define CONTEXT_MANAGER_HPP

#include <cstddef>
#include <vector>

#include "http_client.hpp"
#include "model_provider.hpp"

namespace opencode {

struct ContextStats {
    std::size_t original_messages = 0;
    std::size_t visible_messages = 0;
    std::size_t omitted_messages = 0;
    std::size_t estimated_tokens = 0;
    bool compressed = false;
};

struct ContextWindow {
    std::vector<ChatMessage> messages;
    ContextStats stats;
};

class ContextManager {
public:
    ContextWindow build(
        const std::vector<ChatMessage>& full_history,
        const ModelCapabilities& capabilities
    ) const;

    static std::size_t estimateTokens(const std::vector<ChatMessage>& messages);

private:
    static constexpr std::size_t kTokenReserve = 1024;
    static constexpr std::size_t kMaxToolResultBytes = 32768;
};

} // namespace opencode

#endif
