#ifndef MODEL_PROVIDER_HPP
#define MODEL_PROVIDER_HPP

#include <functional>
#include <memory>
#include <string>
#include <vector>
#include <nlohmann/json.hpp>
#include "http_client.hpp"

namespace opencode {

struct ModelCapabilities {
    std::size_t context_window = 128000;
    std::size_t max_output_tokens = 4096;
    bool native_tool_calls = true;
    bool streaming_usage = true;
    bool image_input = false;
};

class ModelProvider {
public:
    virtual ~ModelProvider() = default;
    virtual std::string name() const = 0;
    virtual std::string model() const = 0;
    virtual ModelCapabilities capabilities() const = 0;
    virtual ChatResponse request(
        const std::vector<ChatMessage>& messages,
        const std::vector<nlohmann::json>& tools,
        const std::function<void(const std::string&)>& on_delta
    ) = 0;
    virtual void appendToolResults(
        std::vector<ChatMessage>& messages,
        const std::vector<ToolCall>& calls,
        const std::vector<nlohmann::json>& results
    ) const = 0;
};

std::unique_ptr<ModelProvider> createModelProvider(
    const std::string& provider,
    HttpClient& client,
    std::string endpoint,
    std::string api_key,
    std::string model
);

} // namespace opencode

#endif
