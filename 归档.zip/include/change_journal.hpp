#ifndef CHANGE_JOURNAL_HPP
#define CHANGE_JOURNAL_HPP

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>
#include <nlohmann/json.hpp>

namespace opencode {

class ChangeJournal {
public:
    struct Snapshot {
        std::filesystem::path target;
        bool existed = false;
        bool directory = false;
        std::vector<std::pair<std::filesystem::path, std::string>> files;
    };

    Snapshot capture(const std::filesystem::path& target) const;
    std::uint64_t record(
        const std::string& action,
        const std::filesystem::path& target,
        Snapshot before
    );
    nlohmann::json list() const;
    nlohmann::json undo(std::uint64_t id = 0);

private:
    struct Entry {
        std::uint64_t id;
        std::string action;
        std::filesystem::path target;
        Snapshot before;
        bool undone = false;
    };

    std::vector<Entry> entries_;
    std::uint64_t next_id_ = 1;
};

} // namespace opencode

#endif
