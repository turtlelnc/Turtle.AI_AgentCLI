#include "tool_policy.hpp"

#include <iostream>
#include <string>

namespace {

bool expect(bool condition, const std::string& message) {
    if (!condition) {
        std::cerr << "FAILED: " << message << '\n';
    }
    return condition;
}

} // namespace

int main() {
    bool passed = true;

    passed &= expect(
        !opencode::ToolPolicy::assess("read_file", {{"path", "README.md"}}).required,
        "read_file does not require approval"
    );
    passed &= expect(
        !opencode::ToolPolicy::assess("list_directory", {{"path", "."}}).required,
        "list_directory does not require approval"
    );

    const auto write = opencode::ToolPolicy::assess(
        "write_file",
        {{"path", "src/main.cpp"}, {"content", "line one\nline two"}}
    );
    passed &= expect(write.required, "write_file requires approval");
    passed &= expect(write.detail == "src/main.cpp", "write approval names its target");
    passed &= expect(
        write.preview.find("+ line one") != std::string::npos,
        "write approval includes a diff preview"
    );

    const auto terminal =
        opencode::ToolPolicy::assess("run_terminal", {{"command", "git status"}});
    passed &= expect(terminal.required, "run_terminal requires approval");
    passed &= expect(terminal.detail == "git status", "terminal approval shows exact command");
    passed &= expect(
        terminal.preview == "$ git status",
        "terminal approval uses command preview"
    );

    passed &= expect(
        opencode::ToolPolicy::assess("custom_tool", nlohmann::json::object()).required,
        "unknown tools fail closed"
    );

    return passed ? 0 : 1;
}
