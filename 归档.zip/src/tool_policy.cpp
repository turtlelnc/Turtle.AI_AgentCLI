#include "tool_policy.hpp"

#include <sstream>

namespace opencode {

namespace {

std::string stringArgument(
    const nlohmann::json& arguments,
    const std::string& name,
    const std::string& fallback
) {
    if (!arguments.contains(name) || !arguments[name].is_string()) {
        return fallback;
    }
    return arguments[name].get<std::string>();
}

std::string prefixedPreview(
    const std::string& content,
    const std::string& prefix,
    std::size_t max_lines = 16
) {
    std::istringstream input(content);
    std::ostringstream output;
    std::string line;
    std::size_t count = 0;
    while (count < max_lines && std::getline(input, line)) {
        output << prefix << line << '\n';
        ++count;
    }
    if (input.good()) {
        output << "... preview truncated\n";
    }
    return output.str();
}

} // namespace

ToolApproval ToolPolicy::assess(
    const std::string& tool_name,
    const nlohmann::json& arguments
) {
    if (tool_name == "read_file" || tool_name == "list_directory" ||
        tool_name == "list_skills" || tool_name == "load_skill") {
        return {false, "", "", ""};
    }
    if (tool_name == "write_file") {
        const std::string path =
            stringArgument(arguments, "path", "<missing path>");
        return {
            true,
            "Write or overwrite a file",
            path,
            "--- /dev/null\n+++ " + path + "\n" +
                prefixedPreview(stringArgument(arguments, "content", ""), "+ ")
        };
    }
    if (tool_name == "edit_file") {
        const std::string path =
            stringArgument(arguments, "path", "<missing path>");
        return {
            true,
            "Edit a file",
            path,
            "--- " + path + "\n+++ " + path + "\n" +
                prefixedPreview(stringArgument(arguments, "old_text", ""), "- ") +
                prefixedPreview(stringArgument(arguments, "new_text", ""), "+ ")
        };
    }
    if (tool_name == "manage_skill") {
        const std::string action =
            stringArgument(arguments, "action", "<missing action>");
        const std::string name =
            stringArgument(arguments, "name", "<missing name>");
        return {
            true,
            action == "delete" ? "Delete a workspace skill"
                               : "Create or replace a workspace skill",
            "$" + name,
            action == "delete"
                ? "- .turtle/skills/" + name
                : prefixedPreview(
                    stringArgument(arguments, "content", ""), "+ "
                )
        };
    }
    if (tool_name == "run_terminal" ||
        tool_name == "terminal" ||
        tool_name == "execute_command") {
        return {
            true,
            "Run a sandboxed terminal command",
            stringArgument(arguments, "command", "<missing command>"),
            "$ " + stringArgument(arguments, "command", "<missing command>")
        };
    }

    // Unknown and custom tools are not assumed to be read-only.
    return {true, "Run tool", tool_name, arguments.dump(2)};
}

} // namespace opencode
