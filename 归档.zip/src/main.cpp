#include <iostream>
#include <string>
#include <vector>
#include <csignal>
#include <atomic>
#include <regex>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <array>
#include <memory>
#include <cctype>
#include <chrono>

#include "config_manager.hpp"
#include "token_tracker.hpp"
#include "git_manager.hpp"
#include "tool_registry.hpp"
#include "http_client.hpp"
#include "ui.hpp"
#include "prompt.hpp"
#include "tool_policy.hpp"
#include "skill_manager.hpp"
#include "change_journal.hpp"
#include "session_manager.hpp"
#include "secret_store.hpp"
#include "endpoint_policy.hpp"
#include "agent_session.hpp"
#include "model_provider.hpp"

using namespace opencode;

volatile std::sig_atomic_t g_interrupted = 0;
volatile std::sig_atomic_t g_operation_active = 0;
volatile std::sig_atomic_t g_cancel_requested = 0;
CancellationToken g_cancellation(&g_cancel_requested);

void signalHandler(int /* signum */) {
    if (g_operation_active) {
        if (g_cancel_requested) {
            g_interrupted = 1;
        } else {
            g_cancel_requested = 1;
        }
    } else {
        g_interrupted = 1;
    }
}

namespace {

struct ParsedToolCall {
    std::string name;
    std::string body;
};

std::string trimWhitespace(const std::string& input) {
    size_t first = 0;
    while (first < input.size() && std::isspace(static_cast<unsigned char>(input[first]))) {
        ++first;
    }

    size_t last = input.size();
    while (last > first && std::isspace(static_cast<unsigned char>(input[last - 1]))) {
        --last;
    }

    return input.substr(first, last - first);
}

std::string stripMarkdownFence(const std::string& input) {
    std::string trimmed = trimWhitespace(input);
    if (trimmed.rfind("```", 0) != 0) {
        return input;
    }

    size_t first_line_end = trimmed.find('\n');
    if (first_line_end == std::string::npos) {
        return input;
    }

    size_t closing_fence = trimmed.rfind("```");
    if (closing_fence == 0 || closing_fence == std::string::npos) {
        return input;
    }

    std::string body = trimmed.substr(first_line_end + 1, closing_fence - first_line_end - 1);
    return trimWhitespace(body);
}

std::vector<ParsedToolCall> parseToolCalls(const std::string& response) {
    std::vector<ParsedToolCall> calls;

    // Accept current full-width tags, variants with a trailing full-width bar,
    // legacy full-width slash placement, and plain ASCII XML-style tags.
    const std::regex calls_start_re(R"(<(?:｜)?tool_calls(?:｜)?\s*>)");
    const std::regex calls_end_re(R"((?:</(?:｜)?tool_calls(?:｜)?\s*>|<｜/tool_calls(?:｜)?\s*>))");

    std::smatch start_match;
    if (!std::regex_search(response, start_match, calls_start_re)) {
        return calls;
    }

    const size_t content_start = static_cast<size_t>(start_match.position() + start_match.length());
    std::string after_start = response.substr(content_start);
    std::smatch end_match;
    if (!std::regex_search(after_start, end_match, calls_end_re)) {
        return calls;
    }

    std::string tools_content = after_start.substr(0, static_cast<size_t>(end_match.position()));

    const std::regex tool_start_re(R"(<(?:｜)?tool_call(?:｜)?\s+[^>]*name\s*=\s*(['"])(.*?)\1[^>]*>)");
    const std::regex tool_end_re(R"((?:</(?:｜)?tool_call(?:｜)?\s*>|<｜/tool_call(?:｜)?\s*>))");

    std::string::const_iterator search_begin = tools_content.cbegin();
    while (search_begin != tools_content.cend()) {
        std::smatch tool_start_match;
        if (!std::regex_search(search_begin, tools_content.cend(), tool_start_match, tool_start_re)) {
            break;
        }

        const auto body_begin = tool_start_match.suffix().first;
        std::smatch tool_end_match;
        if (!std::regex_search(body_begin, tools_content.cend(), tool_end_match, tool_end_re)) {
            break;
        }

        calls.push_back({tool_start_match[2].str(), stripMarkdownFence(std::string(body_begin, tool_end_match.prefix().second))});
        search_begin = tool_end_match.suffix().first;
    }

    return calls;
}

bool runToolCallParserChecks() {
    const std::vector<std::pair<std::string, ParsedToolCall>> checks = {
        {
            "<｜tool_calls｜><｜tool_call name=\"run_terminal\">{\"command\":\"echo current\"}</｜tool_call></｜tool_calls｜>",
            {"run_terminal", "{\"command\":\"echo current\"}"}
        },
        {
            "<tool_calls><tool_call name=\"read_file\">{\"path\":\"README.md\"}</tool_call></tool_calls>",
            {"read_file", "{\"path\":\"README.md\"}"}
        },
        {
            "<tool_calls><tool_call   name='terminal'>{\"command\":\"pwd\"}</tool_call></tool_calls>",
            {"terminal", "{\"command\":\"pwd\"}"}
        },
        {
            "<tool_calls><tool_call name=\"execute_command\">```json\n{\"command\":\"echo fenced\"}\n```</tool_call></tool_calls>",
            {"execute_command", "{\"command\":\"echo fenced\"}"}
        }
    };

    for (const auto& check : checks) {
        auto parsed = parseToolCalls(check.first);
        if (parsed.size() != 1 || parsed[0].name != check.second.name || parsed[0].body != check.second.body) {
            std::cerr << "Tool call parser check failed for input: " << check.first << std::endl;
            return false;
        }
    }

    std::cout << "Tool call parser checks passed\n";
    return true;
}


} // namespace

int main(int argc, char* argv[]) {
    if (argc > 1 && (std::string(argv[1]) == "--help" ||
                    std::string(argv[1]) == "-h")) {
        std::cout << "Turtle.AI AgentCLI\n\n"
                  << "Usage: Turtle.AI_AgentCLI [--help] [--self-test-tool-parser]\n";
        return 0;
    }
    if (argc > 1 && std::string(argv[1]) == "--self-test-tool-parser") {
        return runToolCallParserChecks() ? 0 : 1;
    }
    // 设置信号处理
    std::signal(SIGINT, signalHandler);
    
    UI ui;
    ConfigManager config_mgr;
    TokenTracker token_tracker;
    GitManager git_mgr;
    ToolRegistry tool_registry;
    SkillManager skill_mgr;
    ChangeJournal change_journal;
    SessionManager session_mgr;
    HttpClient http_client;
    PromptManager prompt_mgr;
    auto secret_store = createSecretStore();
    config_mgr.loadDefaultConfig();
    http_client.setCancellationToken(&g_cancellation);
    tool_registry.setCancellationToken(&g_cancellation);
    
    ui.showWelcome();
    
    // 配置向导
    std::string selected_model;
    bool use_previous_api = false;
    int provider_choice = ui.showConfigWizard(config_mgr, selected_model, use_previous_api);
    
    std::string api_url, api_key, model;
    ProviderType provider;
    
    switch (provider_choice) {
        case 1:  // DeepSeek
            provider = ProviderType::DeepSeek;
            api_url = "https://api.deepseek.com/v1/chat/completions";
            model = "deepseek-v4-flash";
            break;
        case 2:  // OpenAI
            provider = ProviderType::OpenAI;
            api_url = "https://api.openai.com/v1/chat/completions";
            model = "gpt-4o-mini";
            break;
        case 3:  // Anthropic
            provider = ProviderType::Anthropic;
            api_url = "https://api.anthropic.com/v1/messages";
            model = "claude-3-5-sonnet-20241022";
            break;
        case 4:  // LlamaCpp
            provider = ProviderType::LlamaCpp;
            api_url = "http://localhost:8080/v1/chat/completions";
            model = "llama3";
            break;
        case 5:  // Custom OpenAI-compatible
            provider = ProviderType::OpenAICompatible;
            api_url = ui.getInput(
                "OpenAI-compatible chat completions endpoint URL"
            );
            model = ui.getInput("Model name");
            if (model.empty()) {
                ui.showError("Model name is required");
                return 1;
            }
            break;
        default:
            ui.showError("Invalid provider choice");
            return 1;
    }
    
    // 获取 API Key (本地模式可选)
    if (provider == ProviderType::OpenAICompatible) {
        api_key = ui.getSecretInput(
            "API key for custom endpoint (optional, input hidden)"
        );
    } else if (provider != ProviderType::LlamaCpp) {
        const std::string provider_name =
            ConfigManager::providerToString(provider);
        bool offer_persistent_store = false;
        bool credential_from_legacy_file = false;
        bool credential_secured = false;
        if (const auto stored = secret_store->get(provider_name)) {
            api_key = stored->value;
            ui.showMessage("Credentials", "Using " + stored->source);
        } else if (const auto legacy = config_mgr.takeLegacyApiKey(provider)) {
            api_key = *legacy;
            offer_persistent_store = true;
            credential_from_legacy_file = true;
            ui.showMessage(
                "Credentials",
                "Migrated credential from legacy config into process memory"
            );
        } else {
            api_key = ui.getSecretInput("Enter your API key (input hidden)");
            offer_persistent_store = true;
        }
        if (api_key.empty()) {
            ui.showError("API key is required");
            return 1;
        }
        if (offer_persistent_store &&
            secret_store->supportsPersistentStore()) {
            const std::string save_key =
                ui.getInput("Store this credential in macOS Keychain? (y/n)");
            if (save_key == "y" || save_key == "Y") {
                std::string store_error;
                if (!secret_store->store(
                        provider_name, api_key, &store_error
                    )) {
                    ui.showError("Could not store credential: " + store_error);
                } else {
                    credential_secured = true;
                    ui.showMessage(
                        "Credentials",
                        "Stored securely in macOS Keychain"
                    );
                }
            }
        }
        if (credential_from_legacy_file) {
            bool remove_plaintext = credential_secured;
            if (!remove_plaintext) {
                const std::string choice = ui.getInput(
                    "Remove the plaintext legacy credential now? "
                    "(it will remain only for this process) (y/n)"
                );
                remove_plaintext = choice == "y" || choice == "Y";
            }
            if (remove_plaintext) {
                if (!config_mgr.sanitizeLegacyCredentials()) {
                    ui.showError(
                        "Could not fully remove the legacy plaintext credential"
                    );
                } else {
                    ui.showMessage(
                        "Credentials",
                        "Removed plaintext credential from legacy files"
                    );
                }
            } else {
                ui.showMessage(
                    "Credentials",
                    "Legacy plaintext credential was left unchanged"
                );
            }
        } else if (config_mgr.hasLegacyApiKey()) {
            const std::string choice = ui.getInput(
                "A plaintext credential remains in a legacy configuration. "
                "Remove it now? (y/n)"
            );
            if (choice == "y" || choice == "Y") {
                if (config_mgr.sanitizeLegacyCredentials()) {
                    ui.showMessage(
                        "Credentials",
                        "Removed plaintext credential from legacy files"
                    );
                } else {
                    ui.showError(
                        "Could not fully remove the legacy plaintext credential"
                    );
                }
            }
        }
    } else {
        api_key = "";  // 本地模式不需要 API key
    }

    const auto endpoint_decision = EndpointPolicy::assess(
        ConfigManager::providerToString(provider),
        api_url,
        !api_key.empty()
    );
    if (!endpoint_decision.allowed) {
        ui.showError(endpoint_decision.error);
        return 1;
    }
    if (endpoint_decision.credential_confirmation_required) {
        const std::string confirmed = ui.getInput(
            "Send credential to host '" + endpoint_decision.host + "'? (y/n)"
        );
        if (confirmed != "y" && confirmed != "Y") {
            ui.showError("Credential transmission was not approved");
            return 1;
        }
    }
    
    // 确认模型
    std::cout << "\nUsing model: " << model << "\n";
    
    // 设置 token 追踪
    token_tracker.setModel(model);
    
    // 选择工作目录
    std::string work_dir = ui.getInput("Enter working directory (default: current)");
    if (work_dir.empty()) {
        work_dir = ".";
    }
    if (!tool_registry.setWorkspaceRoot(work_dir)) {
        ui.showError("Working directory does not exist or is not accessible");
        return 1;
    }
    tool_registry.setChangeJournal(&change_journal);
    std::error_code workspace_error;
    const auto workspace_root =
        std::filesystem::weakly_canonical(work_dir, workspace_error);
    if (workspace_error) {
        ui.showError("Working directory cannot be resolved");
        return 1;
    }
    if (!session_mgr.setWorkspace(workspace_root)) {
        ui.showError("Cannot initialize session storage for this workspace");
        return 1;
    }
    std::string requested_session_id;
    const auto saved_sessions = session_mgr.list();
    if (!saved_sessions.empty()) {
        std::cout << "\n[Saved sessions]\n";
        const std::size_t shown = std::min<std::size_t>(saved_sessions.size(), 10);
        for (std::size_t i = 0; i < shown; ++i) {
            const auto& session = saved_sessions[i];
            std::cout << "  " << session.id << "  "
                      << session.title << "  [" << session.message_count
                      << " messages]\n";
        }
        requested_session_id = ui.getInput(
            "Session ID to resume (Enter for new)"
        );
    }

    std::vector<std::filesystem::path> skill_roots;
    std::error_code skill_path_error;
    const auto executable = std::filesystem::weakly_canonical(argv[0], skill_path_error);
    if (!skill_path_error) {
        skill_roots.push_back(executable.parent_path().parent_path() / "skills");
    }
    skill_roots.push_back(std::filesystem::current_path() / "skills");
    if (const char* home = std::getenv("HOME")) {
        skill_roots.push_back(std::filesystem::path(home) / ".turtle" / "skills");
    }
    skill_roots.push_back(std::filesystem::path(work_dir) / ".turtle" / "skills");
    skill_mgr.discover(skill_roots);

    const nlohmann::json no_parameters = {
        {"type", "object"},
        {"properties", nlohmann::json::object()},
        {"additionalProperties", false}
    };
    tool_registry.registerTool({
        "list_skills",
        "List available task-specific skills and their trigger descriptions",
        [&](const nlohmann::json&) { return skill_mgr.listSkills(); },
        no_parameters
    });
    tool_registry.registerTool({
        "manage_skill",
        "Create, replace, or delete a workspace-local skill. Use only when the user asks to manage skills.",
        [&](const nlohmann::json& args) {
            auto result =
                skill_mgr.manageSkill(args, workspace_root, change_journal);
            if (result.value("success", false)) skill_mgr.discover(skill_roots);
            return result;
        },
        {
            {"type", "object"},
            {"properties", {
                {"action", {
                    {"type", "string"},
                    {"enum", nlohmann::json::array({"upsert", "delete"})}
                }},
                {"name", {{"type", "string"}}},
                {"content", {
                    {"type", "string"},
                    {"description", "Complete SKILL.md; required for upsert"}
                }}
            }},
            {"required", nlohmann::json::array({"action", "name"})},
            {"additionalProperties", false}
        }
    });
    tool_registry.registerTool({
        "load_skill",
        "Load the complete instructions for one available skill",
        [&](const nlohmann::json& args) {
            if (!args.contains("name") || !args["name"].is_string()) {
                return nlohmann::json({
                    {"success", false}, {"error", "Missing string argument: name"}
                });
            }
            return skill_mgr.loadSkill(args["name"].get<std::string>());
        },
        {
            {"type", "object"},
            {"properties", {{"name", {{"type", "string"}}}}},
            {"required", nlohmann::json::array({"name"})},
            {"additionalProperties", false}
        }
    });
    
    // Git 集成询问
    std::string use_git_str = ui.getInput("Enable Git integration? (y/n)");
    bool use_git = (use_git_str == "y" || use_git_str == "Y");
    
    // 检查 Git 状态
    if (use_git && git_mgr.isGitAvailable()) {
        GitStatus status = git_mgr.checkStatus(work_dir);
        if (status.is_repo) {
            std::cout << "\nGit repository detected: " << status.current_branch << "\n";
            if (status.has_uncommitted_changes) {
                std::cout << "Warning: You have " << status.modified_files.size() << " uncommitted file(s)\n";
            }
            if (status.is_behind_remote) {
                std::cout << "Warning: Local branch is " << status.commits_behind << " commit(s) behind remote\n";
            }
        } else {
            std::cout << "\nDirectory is not a Git repository\n";
        }
    }
    
    // 保存配置
    auto& config = config_mgr.getConfig();
    config.provider = provider;
    config.api_url = api_url;
    config.api_key = api_key;
    config.model = model;
    config.work_dir = work_dir;
    config.use_git = use_git;
    if (!config_mgr.saveConfig(config_mgr.getDefaultConfigPath())) {
        ui.showError("Could not save non-secret configuration");
    }
    
    ui.clearScreen();
    ui.showConfigurationSummary(config);
    std::cout << "  Skills:    " << skill_mgr.size() << " loaded\n\n";
    
    // 对话循环
    std::vector<ChatMessage> messages;
    const std::string current_system_prompt =
        prompt_mgr.getSystemPrompt() + skill_mgr.getCatalogPrompt();
    std::string session_id;
    if (!requested_session_id.empty()) {
        SessionInfo resumed;
        std::string resume_error;
        if (session_mgr.load(
                requested_session_id, messages, resumed, &resume_error
            )) {
            if (!messages.empty() && messages.front().role == "system") {
                messages.front().content = current_system_prompt;
                messages.front().content_blocks = nullptr;
                messages.front().tool_calls.clear();
                messages.front().tool_call_id.clear();
            } else {
                messages.insert(messages.begin(), {
                    "system", current_system_prompt, nullptr, "", {}
                });
            }
            session_id = requested_session_id;
            ui.showMessage(
                "Session",
                "Resumed " + resumed.title + " (" +
                    std::to_string(resumed.message_count) + " messages)"
            );
            if ((!resumed.provider.empty() && resumed.provider !=
                    ConfigManager::providerToString(provider)) ||
                (!resumed.model.empty() && resumed.model != model)) {
                ui.showMessage(
                    "Session",
                    "Saved with " + resumed.provider + "/" + resumed.model +
                        "; continuing with " +
                        ConfigManager::providerToString(provider) + "/" + model
                );
            }
        } else {
            ui.showError("Cannot resume session: " + resume_error);
        }
    }
    if (session_id.empty()) {
        session_id = session_mgr.create(
            ConfigManager::providerToString(provider), model
        );
        messages.push_back({
            "system", current_system_prompt, nullptr, "", {}
        });
    }
    auto saveSession = [&]() {
        std::string save_error;
        if (!session_mgr.save(
                session_id,
                ConfigManager::providerToString(provider),
                model,
                messages,
                &save_error
            )) {
            ui.showError("Session autosave failed: " + save_error);
        }
    };
    saveSession();

    bool event_streaming = false;
    auto finishEventStream = [&]() {
        ui.stopThinking();
        if (event_streaming) {
            ui.endStreamingResponse(0.0);
            event_streaming = false;
        }
    };
    AgentSessionCallbacks agent_callbacks;
    agent_callbacks.approve_tool = [&](const ToolApproval& approval) {
        return ui.confirmToolCall(
            approval.action, approval.detail, approval.preview
        );
    };
    agent_callbacks.execute_tool = [&](const std::string& name,
                                       const nlohmann::json& arguments) {
        return tool_registry.executeTool(name, arguments);
    };
    agent_callbacks.persist = saveSession;
    agent_callbacks.emit = [&](const AgentEvent& event) {
        switch (event.type) {
            case AgentEventType::ModelRequestStarted:
                finishEventStream();
                ui.startThinking();
                break;
            case AgentEventType::ContextCompacted:
                ui.showMessage("Context", event.detail);
                break;
            case AgentEventType::ModelTextDelta:
                if (!event_streaming) {
                    ui.stopThinking();
                    ui.beginStreamingResponse();
                    event_streaming = true;
                }
                ui.appendStreamingChunk(event.text);
                break;
            case AgentEventType::ModelResponse:
                finishEventStream();
                ui.showAIResponse(event.text);
                break;
            case AgentEventType::ToolRequested:
                finishEventStream();
                ui.showToolCall(event.tool_name, event.detail);
                break;
            case AgentEventType::ToolDenied:
                ui.showToolResult(
                    event.tool_name, false, "Denied by user"
                );
                break;
            case AgentEventType::ToolCompleted:
                ui.showToolResult(
                    event.tool_name, event.success, event.detail
                );
                break;
            case AgentEventType::UsageUpdated:
                if (event.turn_cost_usd > 0.000001) {
                    std::cout << "   This step: $" << std::fixed
                              << std::setprecision(6)
                              << event.turn_cost_usd << " USD\n";
                }
                std::cout << "   Session total: "
                          << token_tracker.getTotalInputTokens() +
                                 token_tracker.getTotalOutputTokens()
                          << " tokens, $" << std::fixed
                          << std::setprecision(6)
                          << event.total_cost_usd << " USD\n\n";
                break;
            case AgentEventType::TurnFailed:
                finishEventStream();
                ui.showError("Agent error: " + event.text);
                break;
            case AgentEventType::TurnCompleted:
                finishEventStream();
                break;
            default:
                break;
        }
    };
    auto model_provider = createModelProvider(
        ConfigManager::providerToString(provider),
        http_client,
        api_url,
        api_key,
        model
    );
    AgentSession agent_session(
        *model_provider,
        messages,
        tool_registry.getToolsSchema(),
        token_tracker,
        std::move(agent_callbacks),
        &g_cancellation
    );
    
    std::cout << "Chat started. Type /help to see available commands.\n\n";
    
    while (!g_interrupted) {
        std::string user_input;
        {
            user_input = ui.getInput("You");
            
            if (user_input == "/exit" || user_input == "exit" || user_input == "quit") {
                break;
            }
            
            if (user_input == "/stats" || user_input == "stats") {
                ui.showTokenStats(
                    token_tracker.getTotalInputTokens(),
                    token_tracker.getTotalOutputTokens(),
                    token_tracker.getTotalCostUSD()
                );
                continue;
            }

            if (user_input == "/help" || user_input == "help") {
                ui.showHelp();
                continue;
            }

            if (user_input == "/clear" || user_input == "clear") {
                ui.clearScreen();
                continue;
            }

            if (user_input == "/theme") {
                ui.showAppearanceSettings();
                continue;
            }

            if (user_input == "/skills") {
                const auto listed = skill_mgr.listSkills();
                std::cout << "\n[Skills]\n";
                for (const auto& skill : listed["skills"]) {
                    std::cout << "  $" << skill.value("name", "")
                              << " - " << skill.value("description", "") << '\n';
                }
                continue;
            }

            if (user_input == "/sessions") {
                const auto sessions = session_mgr.list();
                std::cout << "\n[Saved sessions]\n";
                for (const auto& session : sessions) {
                    std::cout << "  " << session.id << "  "
                              << session.title << "  ["
                              << session.message_count << " messages]\n";
                }
                continue;
            }

            if (user_input == "/session") {
                ui.showMessage("Session", session_id + " (autosave enabled)");
                continue;
            }

            if (user_input.rfind("/resume ", 0) == 0) {
                const std::string target =
                    trimWhitespace(user_input.substr(8));
                std::vector<ChatMessage> resumed_messages;
                SessionInfo resumed;
                std::string resume_error;
                if (!session_mgr.load(
                        target, resumed_messages, resumed, &resume_error
                    )) {
                    ui.showError("Cannot resume session: " + resume_error);
                    continue;
                }
                if (!resumed_messages.empty() &&
                    resumed_messages.front().role == "system") {
                    resumed_messages.front().content = current_system_prompt;
                } else {
                    resumed_messages.insert(resumed_messages.begin(), {
                        "system", current_system_prompt, nullptr, "", {}
                    });
                }
                messages = std::move(resumed_messages);
                session_id = target;
                ui.showMessage(
                    "Session",
                    "Resumed " + resumed.title + " (" +
                        std::to_string(resumed.message_count) + " messages)"
                );
                saveSession();
                continue;
            }

            if (user_input == "/changes") {
                const auto listed = change_journal.list();
                std::cout << "\n[Reversible changes]\n";
                for (const auto& change : listed["changes"]) {
                    std::cout << "  #" << change.value("id", 0)
                              << (change.value("undone", false) ? " [undone] " : " ")
                              << change.value("action", "") << "  "
                              << change.value("target", "") << '\n';
                }
                continue;
            }

            if (user_input == "/undo" || user_input.rfind("/undo ", 0) == 0) {
                std::uint64_t id = 0;
                if (user_input.size() > 5) {
                    try {
                        id = std::stoull(trimWhitespace(user_input.substr(6)));
                    } catch (...) {
                        ui.showError("Usage: /undo or /undo <change-id>");
                        continue;
                    }
                }
                const auto result = change_journal.undo(id);
                if (result.value("success", false)) {
                    skill_mgr.discover(skill_roots);
                    ui.showMessage(
                        "Undo",
                        "Restored change #" +
                            std::to_string(result.value("change_id", 0))
                    );
                } else {
                    ui.showError(result.value("error", "Undo failed"));
                }
                continue;
            }

            if (user_input.rfind("/theme ", 0) == 0) {
                std::string theme = user_input.substr(7);
                std::transform(theme.begin(), theme.end(), theme.begin(), [](unsigned char c) {
                    return static_cast<char>(std::tolower(c));
                });
                if (ui.setTheme(theme)) {
                    ui.showMessage("Settings", "Theme changed to " + theme);
                } else {
                    ui.showError("Unknown theme. Use /theme to list available themes.");
                }
                continue;
            }

            if (user_input == "/animation on") {
                if (ui.setAnimations(true)) {
                    ui.showMessage("Settings", "Thinking animation enabled");
                } else {
                    ui.showError("Animation requires an interactive terminal.");
                }
                continue;
            }

            if (user_input == "/animation off") {
                ui.setAnimations(false);
                ui.showMessage("Settings", "Thinking animation disabled");
                continue;
            }

            if (user_input == "/mouse on") {
                if (ui.setMouseLinks(true)) {
                    ui.showMessage("Settings", "Clickable file links enabled");
                } else {
                    ui.showError("Mouse links require an interactive terminal.");
                }
                continue;
            }

            if (user_input == "/mouse off") {
                ui.setMouseLinks(false);
                ui.showMessage("Settings", "Clickable file links disabled");
                continue;
            }

            if (!user_input.empty() && user_input.front() == '/') {
                ui.showError("Unknown command. Type /help for available commands.");
                continue;
            }
            
            if (user_input.empty()) {
                continue;
            }
            
            g_cancellation.reset();
            g_operation_active = 1;
            agent_session.runTurn(user_input);
            g_operation_active = 0;
            if (g_cancellation.requested() && !g_interrupted) {
                ui.showMessage(
                    "Cancelled",
                    "Current operation stopped. Press Ctrl-C again while busy "
                    "to exit, or continue with another prompt."
                );
            }
            continue;
        }
    }

    
    // 最终统计
    saveSession();
    std::cout << "\n[Session Summary]\n"
              << "  Total input tokens:  " << token_tracker.getTotalInputTokens() << '\n'
              << "  Total output tokens: " << token_tracker.getTotalOutputTokens() << '\n'
              << "  Estimated cost:      $" << std::fixed << std::setprecision(6)
              << token_tracker.getTotalCostUSD() << " USD\n";
    
    std::cout << "\nGoodbye.\n";
    
    return 0;
}
