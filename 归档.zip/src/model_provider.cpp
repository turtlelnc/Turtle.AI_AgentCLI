#include "model_provider.hpp"

#include <stdexcept>
#include <utility>

namespace opencode {

namespace {

std::string resultContent(const nlohmann::json& result) {
    if (result.contains("error") && result["error"].is_string()) {
        return "Error: " + result["error"].get<std::string>();
    }
    if (result.contains("output") && result["output"].is_string()) {
        return result["output"].get<std::string>();
    }
    if (result.contains("content") && result["content"].is_string()) {
        return result["content"].get<std::string>();
    }
    return result.dump();
}

enum class ToolResultProtocol {
    OpenAI,
    Anthropic
};

class HttpModelProvider : public ModelProvider {
public:
    HttpModelProvider(
        std::string provider,
        HttpClient& client,
        std::string endpoint,
        std::string api_key,
        std::string model,
        ModelCapabilities capabilities,
        ToolResultProtocol tool_protocol
    ) : provider_(std::move(provider)),
        client_(client),
        endpoint_(std::move(endpoint)),
        api_key_(std::move(api_key)),
        model_(std::move(model)),
        capabilities_(capabilities),
        tool_protocol_(tool_protocol) {}

    std::string name() const override { return provider_; }
    std::string model() const override { return model_; }

    ModelCapabilities capabilities() const override { return capabilities_; }

    ChatResponse request(
        const std::vector<ChatMessage>& messages,
        const std::vector<nlohmann::json>& tools,
        const std::function<void(const std::string&)>& on_delta
    ) override {
        return client_.sendChatRequestStreaming(
            endpoint_, api_key_, model_, messages, provider_, tools, on_delta
        );
    }

    void appendToolResults(
        std::vector<ChatMessage>& messages,
        const std::vector<ToolCall>& calls,
        const std::vector<nlohmann::json>& results
    ) const override {
        if (tool_protocol_ == ToolResultProtocol::Anthropic) {
            nlohmann::json blocks = nlohmann::json::array();
            for (std::size_t i = 0; i < calls.size(); ++i) {
                blocks.push_back({
                    {"type", "tool_result"},
                    {"tool_use_id", calls[i].id},
                    {"content", resultContent(results[i])},
                    {"is_error", !results[i].value("success", false)}
                });
            }
            messages.push_back({"user", "", blocks, "", {}});
            return;
        }
        for (std::size_t i = 0; i < calls.size(); ++i) {
            messages.push_back({
                "tool", resultContent(results[i]), nullptr, calls[i].id, {}
            });
        }
    }

private:
    std::string provider_;
    HttpClient& client_;
    std::string endpoint_;
    std::string api_key_;
    std::string model_;
    ModelCapabilities capabilities_;
    ToolResultProtocol tool_protocol_;
};

ModelCapabilities openAICapabilities() {
    ModelCapabilities value;
    value.image_input = true;
    return value;
}

ModelCapabilities anthropicCapabilities() {
    ModelCapabilities value;
    value.context_window = 200000;
    value.image_input = true;
    return value;
}

ModelCapabilities deepSeekCapabilities() {
    ModelCapabilities value;
    value.context_window = 128000;
    value.image_input = false;
    return value;
}

ModelCapabilities compatibleCapabilities() {
    ModelCapabilities value;
    value.context_window = 32768;
    value.streaming_usage = false;
    value.image_input = false;
    return value;
}

class OpenAIProvider final : public HttpModelProvider {
public:
    OpenAIProvider(HttpClient& client, std::string endpoint,
                   std::string key, std::string model)
        : HttpModelProvider(
            "OpenAI", client, std::move(endpoint), std::move(key),
            std::move(model), openAICapabilities(),
            ToolResultProtocol::OpenAI
        ) {}
};

class AnthropicProvider final : public HttpModelProvider {
public:
    AnthropicProvider(HttpClient& client, std::string endpoint,
                      std::string key, std::string model)
        : HttpModelProvider(
            "Anthropic", client, std::move(endpoint), std::move(key),
            std::move(model), anthropicCapabilities(),
            ToolResultProtocol::Anthropic
        ) {}
};

class DeepSeekProvider final : public HttpModelProvider {
public:
    DeepSeekProvider(HttpClient& client, std::string endpoint,
                     std::string key, std::string model)
        : HttpModelProvider(
            "DeepSeek", client, std::move(endpoint), std::move(key),
            std::move(model), deepSeekCapabilities(),
            ToolResultProtocol::OpenAI
        ) {}
};

class OpenAICompatibleProvider final : public HttpModelProvider {
public:
    OpenAICompatibleProvider(std::string provider, HttpClient& client,
                             std::string endpoint, std::string key,
                             std::string model)
        : HttpModelProvider(
            std::move(provider), client, std::move(endpoint), std::move(key),
            std::move(model), compatibleCapabilities(),
            ToolResultProtocol::OpenAI
        ) {}
};

} // namespace

std::unique_ptr<ModelProvider> createModelProvider(
    const std::string& provider,
    HttpClient& client,
    std::string endpoint,
    std::string api_key,
    std::string model
) {
    if (provider == "OpenAI") {
        return std::make_unique<OpenAIProvider>(
            client, std::move(endpoint), std::move(api_key), std::move(model)
        );
    }
    if (provider == "Anthropic") {
        return std::make_unique<AnthropicProvider>(
            client, std::move(endpoint), std::move(api_key), std::move(model)
        );
    }
    if (provider == "DeepSeek") {
        return std::make_unique<DeepSeekProvider>(
            client, std::move(endpoint), std::move(api_key), std::move(model)
        );
    }
    if (provider == "LlamaCpp" || provider == "OpenAICompatible") {
        return std::make_unique<OpenAICompatibleProvider>(
            provider, client, std::move(endpoint), std::move(api_key),
            std::move(model)
        );
    }
    throw std::invalid_argument("Unsupported model provider: " + provider);
}

} // namespace opencode
