#include "sandbox_runner.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <thread>

#if defined(__APPLE__)
#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

namespace opencode {

namespace {

#if defined(__APPLE__)
constexpr const char* kSandboxExecutable = "/usr/bin/sandbox-exec";

constexpr const char* kSeatbeltPolicy = R"SBPL(
(version 1)
(deny default)

(allow process-exec)
(allow process-fork)
(allow signal (target same-sandbox))
(allow process-info* (target same-sandbox))

; Commands may inspect the host, but may only mutate the selected workspace.
(allow file-read*)
(allow file-write* (subpath (param "WORKSPACE")))
(allow file-write-data (literal "/dev/null"))
(allow file-read* file-write* file-ioctl (literal "/dev/null"))

; Common runtime discovery required by shells, compilers, and developer tools.
(allow sysctl-read)
(allow mach-lookup)
(allow user-preference-read)
(allow ipc-posix-shm-read*)

; No network rules are granted: outbound, inbound, and bind are denied.
)SBPL";

void appendOutput(int fd, std::string& output, std::size_t max_output_bytes) {
    std::array<char, 4096> buffer;
    while (true) {
        const ssize_t count = read(fd, buffer.data(), buffer.size());
        if (count > 0) {
            const std::size_t remaining =
                max_output_bytes > output.size() ? max_output_bytes - output.size() : 0;
            output.append(buffer.data(), std::min<std::size_t>(remaining, count));
            continue;
        }
        if (count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
            return;
        }
        return;
    }
}
#endif

} // namespace

bool SandboxRunner::isAvailable() {
#if defined(__APPLE__)
    // macOS does not permit nesting a second Seatbelt profile. Fail closed
    // when Turtle itself is already running inside a Codex-style sandbox.
    const char* existing_sandbox = std::getenv("CODEX_SANDBOX");
    return access(kSandboxExecutable, X_OK) == 0 &&
           (!existing_sandbox || existing_sandbox[0] == '\0');
#else
    return false;
#endif
}

SandboxResult SandboxRunner::run(
    const std::string& command,
    const std::filesystem::path& workspace,
    int timeout_seconds,
    std::size_t max_output_bytes,
    const CancellationToken* cancellation
) {
    SandboxResult result;

#if !defined(__APPLE__)
    result.error = "A native sandbox backend is not available on this platform";
    return result;
#else
    if (!isAvailable()) {
        result.error = "macOS sandbox-exec is unavailable";
        return result;
    }
    if (command.empty()) {
        result.error = "Command is empty";
        return result;
    }

    std::error_code filesystem_error;
    const auto canonical_workspace =
        std::filesystem::canonical(workspace, filesystem_error);
    if (filesystem_error || !std::filesystem::is_directory(canonical_workspace)) {
        result.error = "Workspace cannot be resolved";
        return result;
    }

    int output_pipe[2];
    if (pipe(output_pipe) != 0) {
        result.error = std::string("Unable to create output pipe: ") + std::strerror(errno);
        return result;
    }

    const pid_t child = fork();
    if (child < 0) {
        close(output_pipe[0]);
        close(output_pipe[1]);
        result.error = std::string("Unable to fork sandbox process: ") + std::strerror(errno);
        return result;
    }

    if (child == 0) {
        setpgid(0, 0);
        close(output_pipe[0]);
        dup2(output_pipe[1], STDOUT_FILENO);
        dup2(output_pipe[1], STDERR_FILENO);
        close(output_pipe[1]);

        if (chdir(canonical_workspace.c_str()) != 0) {
            _exit(126);
        }

        const std::string workspace_value = canonical_workspace.string();
        const char* argv[] = {
            kSandboxExecutable,
            "-p",
            kSeatbeltPolicy,
            "-D",
            nullptr,
            "/bin/sh",
            "-lc",
            command.c_str(),
            nullptr
        };
        const std::string parameter = "WORKSPACE=" + workspace_value;
        argv[4] = parameter.c_str();
        execv(kSandboxExecutable, const_cast<char* const*>(argv));
        _exit(127);
    }

    result.launched = true;
    close(output_pipe[1]);
    const int flags = fcntl(output_pipe[0], F_GETFL, 0);
    fcntl(output_pipe[0], F_SETFL, flags | O_NONBLOCK);

    const auto deadline =
        std::chrono::steady_clock::now() + std::chrono::seconds(timeout_seconds);
    int status = 0;
    while (true) {
        appendOutput(output_pipe[0], result.output, max_output_bytes);
        const pid_t wait_result = waitpid(child, &status, WNOHANG);
        if (wait_result == child) {
            break;
        }
        if (wait_result < 0) {
            result.error = std::string("Unable to wait for sandbox process: ") +
                           std::strerror(errno);
            break;
        }
        if (std::chrono::steady_clock::now() >= deadline) {
            result.timed_out = true;
            kill(-child, SIGKILL);
            waitpid(child, &status, 0);
            break;
        }
        if (cancellation && cancellation->requested()) {
            result.cancelled = true;
            kill(-child, SIGTERM);
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            if (waitpid(child, &status, WNOHANG) == 0) {
                kill(-child, SIGKILL);
            }
            waitpid(child, &status, 0);
            break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    appendOutput(output_pipe[0], result.output, max_output_bytes);
    close(output_pipe[0]);
    if (result.output.size() >= max_output_bytes) {
        result.output += "\n... [output truncated]";
    }

    if (result.cancelled) {
        result.exit_code = 130;
        result.error = "Command cancelled";
    } else if (result.timed_out) {
        result.exit_code = 124;
    } else if (WIFEXITED(status)) {
        result.exit_code = WEXITSTATUS(status);
    } else if (WIFSIGNALED(status)) {
        result.exit_code = 128 + WTERMSIG(status);
    }
    return result;
#endif
}

} // namespace opencode
