#include "http_client.hpp"
#include "stream_parser.hpp"
#include "endpoint_policy.hpp"
#include "http_retry_policy.hpp"
#include <curl/curl.h>
#include <chrono>
#include <algorithm>
#include <cctype>
#include <iostream>
#include <functional>
#include <thread>
#include <ctime>

namespace opencode {

namespace {

std::string makeErrorResponse(
    const std::string& message,
    ErrorCategory category = ErrorCategory::Provider
) {
    return nlohmann::json({
        {"error", message},
        {"error_category", errorCategoryName(category)}
    }).dump();
}

void configureCommonCurlOptions(CURL* curl) {
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 120L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);

    // libcurl verifies certificates by default. Keep the policy explicit so a
    // future refactor cannot silently turn authenticated API calls into an
    // insecure transport.
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    // Authenticated requests never follow redirects. This prevents libcurl
    // policy changes from forwarding credentials to another host.
    curl_easy_setopt(
        curl,
        CURLOPT_FOLLOWLOCATION,
        EndpointPolicy::allowHttpRedirects() ? 1L : 0L
    );
    curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 0L);
}

std::string curlErrorResponse(CURLcode result, ErrorCategory category) {
    return makeErrorResponse(std::string("Network request failed: ") +
                             curl_easy_strerror(result), category);
}

std::string httpErrorResponse(
    long status,
    const std::string& response_body,
    ErrorCategory category
) {
    std::string message = "HTTP " + std::to_string(status);
    if (!response_body.empty()) {
        message += ": " + response_body;
    }
    return makeErrorResponse(message, category);
}

size_t HeaderCallback(
    char* buffer, size_t size, size_t nitems, void* userdata
) {
    const size_t total = size * nitems;
    std::string line(buffer, total);
    std::string prefix = "retry-after:";
    std::string lowered = line;
    std::transform(lowered.begin(), lowered.end(), lowered.begin(),
                   [](unsigned char c) { return std::tolower(c); });
    if (lowered.rfind(prefix, 0) == 0) {
        try {
            const std::string value = line.substr(prefix.size());
            try {
                *static_cast<long*>(userdata) = std::stol(value) * 1000L;
            } catch (...) {
                const std::time_t when = curl_getdate(value.c_str(), nullptr);
                const std::time_t now = std::time(nullptr);
                if (when >= now) {
                    *static_cast<long*>(userdata) =
                        static_cast<long>(when - now) * 1000L;
                }
            }
        } catch (...) {
            // Invalid values fall back to the normal bounded backoff.
        }
    }
    return total;
}

int ProgressCallback(
    void* userdata, curl_off_t, curl_off_t, curl_off_t, curl_off_t
) {
    const auto* token = static_cast<const CancellationToken*>(userdata);
    return token && token->requested() ? 1 : 0;
}

bool waitForRetry(long delay_ms, const CancellationToken* cancellation) {
    long remaining = delay_ms;
    while (remaining > 0) {
        if (cancellation && cancellation->requested()) return false;
        const long slice = std::min<long>(remaining, 50);
        std::this_thread::sleep_for(std::chrono::milliseconds(slice));
        remaining -= slice;
    }
    return !(cancellation && cancellation->requested());
}

std::string visibleTextDelta(
    const std::string& event,
    const std::string& provider_type
) {
    try {
        const auto payload = nlohmann::json::parse(event);
        if (provider_type == "Anthropic") {
            const auto delta = payload.value("delta", nlohmann::json::object());
            if (payload.value("type", "") == "content_block_delta" &&
                delta.value("type", "") == "text_delta") {
                return delta.value("text", "");
            }
            return "";
        }
        if (payload.contains("choices") && !payload["choices"].empty()) {
            const auto delta = payload["choices"][0].value(
                "delta", nlohmann::json::object()
            );
            if (delta.contains("content") && delta["content"].is_string()) {
                return delta["content"].get<std::string>();
            }
        }
    } catch (...) {
    }
    return "";
}

} // namespace

static size_t WriteCallback(void* contents, size_t size, size_t nmemb, std::string* userp) {
    size_t total_size = size * nmemb;
    userp->append(static_cast<char*>(contents), total_size);
    return total_size;
}

// 流式写入回调结构体
struct StreamCallbackData {
    std::function<void(const std::string&)> onChunk;
    std::string provider_type;
    std::string pending_data;
    std::string raw_response;
    std::vector<std::string> events;
    bool delivered_output = false;
};

static size_t StreamWriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    size_t total_size = size * nmemb;
    StreamCallbackData* cb_data = static_cast<StreamCallbackData*>(userp);
    
    std::string chunk(static_cast<char*>(contents), total_size);
    cb_data->raw_response += chunk;
    cb_data->pending_data += chunk;

    // Normalize HTTP/SSE CRLF so delimiters split correctly even across curl
    // callback boundaries.
    size_t crlf_pos = 0;
    while ((crlf_pos = cb_data->pending_data.find("\r\n", crlf_pos)) !=
           std::string::npos) {
        cb_data->pending_data.replace(crlf_pos, 2, "\n");
    }
    
    // 处理 SSE 格式 (data: {...}\n\n)
    size_t pos = 0;
    while ((pos = cb_data->pending_data.find("\n\n")) != std::string::npos) {
        std::string block = cb_data->pending_data.substr(0, pos);
        cb_data->pending_data.erase(0, pos + 2);

        std::string data;
        size_t line_start = 0;
        while (line_start <= block.size()) {
            const size_t line_end = block.find('\n', line_start);
            const std::string line = block.substr(
                line_start,
                line_end == std::string::npos
                    ? std::string::npos
                    : line_end - line_start
            );
            if (line.rfind("data:", 0) == 0) {
                std::string value = line.substr(5);
                if (!value.empty() && value.front() == ' ') {
                    value.erase(0, 1);
                }
                if (!data.empty()) {
                    data += '\n';
                }
                data += value;
            }
            if (line_end == std::string::npos) {
                break;
            }
            line_start = line_end + 1;
        }

        if (!data.empty()) {
            if (data == "[DONE]") {
                continue;
            }
            cb_data->events.push_back(data);
            if (cb_data->onChunk) {
                const std::string text =
                    visibleTextDelta(data, cb_data->provider_type);
                if (!text.empty()) {
                    cb_data->delivered_output = true;
                    cb_data->onChunk(text);
                }
            }
        }
    }
    
    return total_size;
}

HttpClient::HttpClient() {
    curl_global_init(CURL_GLOBAL_ALL);
}

void HttpClient::setCancellationToken(CancellationToken* token) {
    cancellation_token_ = token;
}

std::string HttpClient::performCurlRequest(const std::string& url, const std::string& data, const std::string& api_key, const std::string& provider_type, std::size_t retry_count) {
    if (cancellation_token_ && cancellation_token_->requested()) {
        return makeErrorResponse("Request cancelled", ErrorCategory::Cancelled);
    }
    CURL* curl = curl_easy_init();
    if (!curl) {
        return "{\"error\": \"Failed to initialize CURL\"}";
    }
    
    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    
    if (!api_key.empty()) {
        if (provider_type == "Anthropic") {
            std::string api_key_header = "x-api-key: " + api_key;
            headers = curl_slist_append(headers, api_key_header.c_str());
            headers = curl_slist_append(headers, "anthropic-version: 2023-06-01");
        } else {
            std::string auth_header = "Authorization: Bearer " + api_key;
            headers = curl_slist_append(headers, auth_header.c_str());
        }
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    
    std::string response_data;
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_data);
    long retry_after_ms = -1;
    curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, HeaderCallback);
    curl_easy_setopt(curl, CURLOPT_HEADERDATA, &retry_after_ms);
    configureCommonCurlOptions(curl);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, ProgressCallback);
    curl_easy_setopt(curl, CURLOPT_XFERINFODATA, cancellation_token_);
    
    CURLcode res = curl_easy_perform(curl);
    
    long http_code = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    
    if (res != CURLE_OK || http_code < 200 || http_code >= 300) {
        const RetryDecision decision = HttpRetryPolicy::assess(
            http_code, res, response_data, retry_count, retry_after_ms
        );
        if (decision.retry) {
            if (!waitForRetry(decision.delay_ms, cancellation_token_)) {
                return makeErrorResponse(
                    "Request cancelled during retry backoff",
                    ErrorCategory::Cancelled
                );
            }
            return performCurlRequest(
                url, data, api_key, provider_type, retry_count + 1
            );
        }
        if (res != CURLE_OK) {
            return curlErrorResponse(res, decision.category);
        }
        return httpErrorResponse(http_code, response_data, decision.category);
    }
    
    return response_data;
}

std::string HttpClient::performCurlRequestStreaming(const std::string& url, const std::string& data, const std::string& api_key, const std::string& provider_type, std::function<void(const std::string&)> onChunk, std::size_t retry_count) {
    if (cancellation_token_ && cancellation_token_->requested()) {
        return makeErrorResponse("Request cancelled", ErrorCategory::Cancelled);
    }
    CURL* curl = curl_easy_init();
    if (!curl) {
        return "{\"error\": \"Failed to initialize CURL\"}";
    }
    
    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    
    if (!api_key.empty()) {
        if (provider_type == "Anthropic") {
            std::string api_key_header = "x-api-key: " + api_key;
            headers = curl_slist_append(headers, api_key_header.c_str());
            headers = curl_slist_append(headers, "anthropic-version: 2023-06-01");
        } else {
            std::string auth_header = "Authorization: Bearer " + api_key;
            headers = curl_slist_append(headers, auth_header.c_str());
        }
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, StreamWriteCallback);
    
    StreamCallbackData cb_data;
    cb_data.onChunk = onChunk;
    cb_data.provider_type = provider_type;
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &cb_data);
    long retry_after_ms = -1;
    curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, HeaderCallback);
    curl_easy_setopt(curl, CURLOPT_HEADERDATA, &retry_after_ms);
    configureCommonCurlOptions(curl);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, ProgressCallback);
    curl_easy_setopt(curl, CURLOPT_XFERINFODATA, cancellation_token_);
    
    CURLcode res = curl_easy_perform(curl);
    
    long http_code = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    
    if (res != CURLE_OK || http_code < 200 || http_code >= 300) {
        RetryDecision decision = HttpRetryPolicy::assess(
            http_code, res, cb_data.raw_response, retry_count, retry_after_ms
        );
        // Once any stream bytes have been observed, retrying could replay text
        // or a completed tool call. Surface the interruption instead.
        if (cb_data.delivered_output) decision.retry = false;
        if (decision.retry) {
            if (!waitForRetry(decision.delay_ms, cancellation_token_)) {
                return makeErrorResponse(
                    "Request cancelled during retry backoff",
                    ErrorCategory::Cancelled
                );
            }
            return performCurlRequestStreaming(
                url, data, api_key, provider_type, onChunk, retry_count + 1
            );
        }
        if (res != CURLE_OK) {
            return curlErrorResponse(res, decision.category);
        }
        return httpErrorResponse(
            http_code, cb_data.raw_response, decision.category
        );
    }

    return nlohmann::json({{"sse_events", cb_data.events}}).dump();
}

nlohmann::json HttpClient::buildRequestBody(const std::string& model, const std::vector<ChatMessage>& messages, const std::string& provider_type, const std::vector<nlohmann::json>& tools, bool stream) {
    nlohmann::json body;
    
    // DeepSeek/OpenAI/兼容格式
    if (provider_type == "DeepSeek" || provider_type == "OpenAI" ||
        provider_type == "OpenAICompatible" || provider_type == "Unknown") {
        body["model"] = model;
        body["messages"] = nlohmann::json::array();
        
        for (const auto& msg : messages) {
            nlohmann::json message = {
                {"role", msg.role},
                {"content", msg.content}
            };
            // 对于 tool 消息，添加 tool_call_id
            if (msg.role == "tool" && !msg.tool_call_id.empty()) {
                message["tool_call_id"] = msg.tool_call_id;
            }
            // 对于 assistant 消息，如果有 tool_calls，添加该字段
            if (msg.role == "assistant" && !msg.tool_calls.empty()) {
                nlohmann::json tool_calls_json = nlohmann::json::array();
                for (const auto& tc : msg.tool_calls) {
                    nlohmann::json tool_call_obj = {
                        {"id", tc.id},
                        {"type", tc.type.empty() ? "function" : tc.type},
                        {"function", {
                            {"name", tc.name},
                            {"arguments", tc.arguments.is_null() ? tc.input.dump() : tc.arguments.dump()}
                        }}
                    };
                    tool_calls_json.push_back(tool_call_obj);
                }
                message["tool_calls"] = tool_calls_json;
            }
            body["messages"].push_back(message);
        }
        
        body["stream"] = stream;
        body["temperature"] = 0.7;
        body["max_tokens"] = 4096;
        if (!tools.empty()) {
            body["tools"] = tools;
        }
    }
    // Anthropic 格式
    else if (provider_type == "Anthropic") {
        body["model"] = model;
        body["max_tokens"] = 4096;
        body["stream"] = stream;
        
        // 分离 system 消息
        std::string system_content;
        for (const auto& msg : messages) {
            if (msg.role == "system") {
                system_content = msg.content;
            } else {
                nlohmann::json message = {{"role", msg.role}};
                if (!msg.content_blocks.is_null()) {
                    message["content"] = msg.content_blocks;
                } else if (msg.role == "assistant" && !msg.tool_calls.empty()) {
                    nlohmann::json blocks = nlohmann::json::array();
                    if (!msg.content.empty()) {
                        blocks.push_back({{"type", "text"}, {"text", msg.content}});
                    }
                    for (const auto& call : msg.tool_calls) {
                        blocks.push_back({
                            {"type", "tool_use"},
                            {"id", call.id},
                            {"name", call.name},
                            {"input", call.input.is_null()
                                ? call.arguments
                                : call.input}
                        });
                    }
                    message["content"] = std::move(blocks);
                } else {
                    message["content"] = msg.content;
                }
                body["messages"].push_back(message);
            }
        }
        
        if (!system_content.empty()) {
            body["system"] = system_content;
        }
        
        if (!tools.empty()) {
            body["tools"] = nlohmann::json::array();
            for (const auto& tool : tools) {
                if (tool.contains("function")) {
                    body["tools"].push_back({
                        {"name", tool["function"].value("name", "")},
                        {"description", tool["function"].value("description", "")},
                        {"input_schema", tool["function"].value("parameters", nlohmann::json::object())}
                    });
                }
            }
        }
    }
    // LlamaCpp/Ollama 格式
    else if (provider_type == "LlamaCpp") {
        body["model"] = model;
        body["messages"] = nlohmann::json::array();
        
        for (const auto& msg : messages) {
            body["messages"].push_back({
                {"role", msg.role},
                {"content", msg.content}
            });
        }
        
        body["stream"] = stream;
    }
    
    return body;
}

ChatResponse HttpClient::sendChatRequest(
    const std::string& url,
    const std::string& api_key,
    const std::string& model,
    const std::vector<ChatMessage>& messages,
    const std::string& provider_type,
    const std::vector<nlohmann::json>& tools
) {
    return sendChatRequestStreaming(url, api_key, model, messages, provider_type, tools, nullptr);
}

ChatResponse HttpClient::sendChatRequestStreaming(
    const std::string& url,
    const std::string& api_key,
    const std::string& model,
    const std::vector<ChatMessage>& messages,
    const std::string& provider_type,
    const std::vector<nlohmann::json>& tools,
    std::function<void(const std::string&)> onChunk
) {
    ChatResponse response;
    response.success = false;
    response.input_tokens = 0;
    response.output_tokens = 0;

    const auto endpoint =
        EndpointPolicy::assess(provider_type, url, !api_key.empty());
    if (!endpoint.allowed) {
        response.error_message = "Endpoint policy rejected request: " + endpoint.error;
        return response;
    }
    
    bool stream = (onChunk != nullptr);
    nlohmann::json body = buildRequestBody(model, messages, provider_type, tools, stream);
    
    std::string result;
    if (stream) {
        result = performCurlRequestStreaming(url, body.dump(), api_key, provider_type, onChunk);
    } else {
        result = performCurlRequest(url, body.dump(), api_key, provider_type);
    }
    
    try {
        nlohmann::json json_result = nlohmann::json::parse(result);

        if (stream && json_result.contains("sse_events")) {
            return parseStreamingEvents(
                json_result["sse_events"].get<std::vector<std::string>>(),
                provider_type
            );
        }
        
        // 检查错误
        if (json_result.contains("error")) {
            response.error_message = json_result["error"].is_string() ? 
                json_result["error"].get<std::string>() : json_result["error"].dump();
            response.error_category = errorCategoryFromName(
                json_result.value("error_category", "provider_error")
            );
            return response;
        }
        
        // 解析响应 (OpenAI/DeepSeek 格式)
        if (json_result.contains("choices") && !json_result["choices"].empty()) {
            auto& choice = json_result["choices"][0];
            if (choice.contains("message")) {
                auto& message = choice["message"];
                
                // 解析文本内容
                if (message.contains("content") && !message["content"].is_null()) {
                    response.content = message["content"].get<std::string>();
                }
                
                // 解析原生 tool_calls (OpenAI/DeepSeek 格式)
                if (message.contains("tool_calls") && message["tool_calls"].is_array()) {
                    for (const auto& tc : message["tool_calls"]) {
                        ToolCall call;
                        call.id = tc.value("id", "");
                        call.type = tc.value("type", "function");
                        if (tc.contains("function")) {
                            call.name = tc["function"].value("name", "");
                            std::string args_str = tc["function"].value("arguments", "{}");
                            try {
                                call.arguments = nlohmann::json::parse(args_str);
                            } catch (...) {
                                call.arguments = nlohmann::json::object();
                            }
                        }
                        response.tool_calls.push_back(call);
                    }
                }
            }
            
            if (json_result.contains("usage")) {
                if (json_result["usage"].contains("prompt_tokens")) {
                    response.input_tokens = json_result["usage"]["prompt_tokens"].get<int64_t>();
                }
                if (json_result["usage"].contains("completion_tokens")) {
                    response.output_tokens = json_result["usage"]["completion_tokens"].get<int64_t>();
                }
            }
        }
        // Anthropic 格式
        else if (json_result.contains("content") && json_result["content"].is_array()) {
            response.content_blocks = json_result["content"];
            for (const auto& content : json_result["content"]) {
                std::string type = content.value("type", "");
                if (type == "text" && content.contains("text") && content["text"].is_string()) {
                    if (!response.content.empty()) {
                        response.content += "\n";
                    }
                    response.content += content["text"].get<std::string>();
                } else if (type == "tool_use") {
                    ToolCall call;
                    call.id = content.value("id", "");
                    call.name = content.value("name", "");
                    call.input = content.contains("input") ? content["input"] : nlohmann::json::object();
                    response.tool_calls.push_back(call);
                }
            }
            
            if (json_result.contains("usage")) {
                if (json_result["usage"].contains("input_tokens")) {
                    response.input_tokens = json_result["usage"]["input_tokens"].get<int64_t>();
                }
                if (json_result["usage"].contains("output_tokens")) {
                    response.output_tokens = json_result["usage"]["output_tokens"].get<int64_t>();
                }
            }
        }
        
        response.has_tool_calls = !response.tool_calls.empty();
        response.success = !response.content.empty() || !response.tool_calls.empty();
        
    } catch (const std::exception& e) {
        response.error_message = "JSON parse error: " + std::string(e.what());
        response.content = result;  // 返回原始响应以便调试
    }
    
    return response;
}

bool HttpClient::validateApiKey(const std::string& url, const std::string& api_key, const std::string& model) {
    std::vector<ChatMessage> test_messages = {
        {"user", "Hello", nullptr, "", {}}
    };
    
    ChatResponse response = sendChatRequest(
        url, api_key, model, test_messages, "OpenAICompatible"
    );
    return response.success;
}

} // namespace opencode
