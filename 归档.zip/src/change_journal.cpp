#include "change_journal.hpp"

#include <fstream>
#include <sstream>
#include <system_error>

namespace opencode {

namespace {

constexpr std::size_t kMaxSnapshotFiles = 256;
constexpr std::size_t kMaxSnapshotBytes = 2 * 1024 * 1024;

bool overlaps(const std::filesystem::path& left, const std::filesystem::path& right) {
    const auto l = left.lexically_normal();
    const auto r = right.lexically_normal();
    auto isPrefix = [](const auto& parent, const auto& child) {
        auto p = parent.begin();
        auto c = child.begin();
        for (; p != parent.end(); ++p, ++c) {
            if (c == child.end() || *p != *c) return false;
        }
        return true;
    };
    return isPrefix(l, r) || isPrefix(r, l);
}

} // namespace

ChangeJournal::Snapshot ChangeJournal::capture(
    const std::filesystem::path& target
) const {
    Snapshot snapshot;
    snapshot.target = target;
    std::error_code error;
    snapshot.existed = std::filesystem::exists(target, error) && !error;
    if (!snapshot.existed) return snapshot;
    snapshot.directory = std::filesystem::is_directory(target, error) && !error;

    std::size_t total_bytes = 0;
    auto captureFile = [&](const std::filesystem::path& file) {
        if (snapshot.files.size() >= kMaxSnapshotFiles) {
            throw std::runtime_error("Change snapshot exceeds 256 files");
        }
        std::ifstream input(file, std::ios::binary);
        if (!input) throw std::runtime_error("Cannot snapshot: " + file.string());
        std::string content(
            (std::istreambuf_iterator<char>(input)),
            std::istreambuf_iterator<char>()
        );
        total_bytes += content.size();
        if (total_bytes > kMaxSnapshotBytes) {
            throw std::runtime_error("Change snapshot exceeds 2 MiB");
        }
        snapshot.files.emplace_back(
            snapshot.directory ? std::filesystem::relative(file, target)
                               : std::filesystem::path(),
            std::move(content)
        );
    };

    if (!snapshot.directory) {
        captureFile(target);
        return snapshot;
    }
    for (std::filesystem::recursive_directory_iterator it(target, error), end;
         !error && it != end; it.increment(error)) {
        if (it->is_symlink(error)) {
            throw std::runtime_error("Cannot snapshot a directory containing symlinks");
        }
        if (it->is_regular_file(error)) captureFile(it->path());
    }
    if (error) throw std::runtime_error("Cannot snapshot directory: " + error.message());
    return snapshot;
}

std::uint64_t ChangeJournal::record(
    const std::string& action,
    const std::filesystem::path& target,
    Snapshot before
) {
    const std::uint64_t id = next_id_++;
    entries_.push_back({id, action, target, std::move(before), false});
    return id;
}

nlohmann::json ChangeJournal::list() const {
    nlohmann::json changes = nlohmann::json::array();
    for (auto it = entries_.rbegin(); it != entries_.rend(); ++it) {
        changes.push_back({
            {"id", it->id},
            {"action", it->action},
            {"target", it->target.string()},
            {"undone", it->undone}
        });
    }
    return {{"success", true}, {"changes", changes}};
}

nlohmann::json ChangeJournal::undo(std::uint64_t requested_id) {
    auto selected = entries_.end();
    if (requested_id == 0) {
        for (auto it = entries_.end(); it != entries_.begin();) {
            --it;
            if (!it->undone) {
                selected = it;
                break;
            }
        }
    } else {
        for (auto it = entries_.begin(); it != entries_.end(); ++it) {
            if (it->id == requested_id && !it->undone) {
                selected = it;
                break;
            }
        }
    }
    if (selected == entries_.end()) {
        return {{"success", false}, {"error", "No matching active change to undo"}};
    }
    for (auto it = std::next(selected); it != entries_.end(); ++it) {
        if (!it->undone && overlaps(selected->target, it->target)) {
            return {
                {"success", false},
                {"error", "A newer change affects the same target; undo it first"},
                {"blocking_change_id", it->id}
            };
        }
    }

    std::error_code error;
    std::filesystem::remove_all(selected->target, error);
    if (error) {
        return {{"success", false}, {"error", "Cannot clear current target: " + error.message()}};
    }
    if (selected->before.existed) {
        if (selected->before.directory) {
            std::filesystem::create_directories(selected->target, error);
        } else {
            std::filesystem::create_directories(selected->target.parent_path(), error);
        }
        if (error) {
            return {{"success", false}, {"error", "Cannot restore target: " + error.message()}};
        }
        for (const auto& [relative, content] : selected->before.files) {
            const auto output_path = selected->before.directory
                ? selected->target / relative : selected->target;
            std::filesystem::create_directories(output_path.parent_path(), error);
            if (error) break;
            std::ofstream output(output_path, std::ios::binary);
            if (!output) {
                return {{"success", false}, {"error", "Cannot restore: " + output_path.string()}};
            }
            output << content;
        }
        if (error) {
            return {{"success", false}, {"error", "Cannot restore target: " + error.message()}};
        }
    }
    selected->undone = true;
    return {
        {"success", true},
        {"message", "Change undone"},
        {"change_id", selected->id},
        {"path", selected->target.string()}
    };
}

} // namespace opencode
