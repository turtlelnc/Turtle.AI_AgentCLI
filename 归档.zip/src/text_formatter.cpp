#include "text_formatter.hpp"

#include <algorithm>
#include <climits>
#include <cwchar>
#include <numeric>
#include <sstream>
#include <vector>

namespace opencode {

namespace {

std::string trim(const std::string& value) {
    const auto first = value.find_first_not_of(" \t");
    if (first == std::string::npos) {
        return "";
    }
    const auto last = value.find_last_not_of(" \t");
    return value.substr(first, last - first + 1);
}

std::string visibleMarkdownCell(std::string value) {
    for (const std::string marker : {"**", "__", "~~"}) {
        size_t position = 0;
        while ((position = value.find(marker, position)) != std::string::npos) {
            value.erase(position, marker.size());
        }
    }
    value.erase(
        std::remove(value.begin(), value.end(), '`'),
        value.end()
    );

    // Markdown links display only their label in a terminal table.
    size_t start = 0;
    while ((start = value.find('[', start)) != std::string::npos) {
        const size_t label_end = value.find("](", start + 1);
        const size_t target_end =
            label_end == std::string::npos ? std::string::npos :
            value.find(')', label_end + 2);
        if (label_end == std::string::npos || target_end == std::string::npos) {
            break;
        }
        const std::string label =
            value.substr(start + 1, label_end - start - 1);
        value.replace(start, target_end - start + 1, label);
        start += label.size();
    }

    size_t tab = 0;
    while ((tab = value.find('\t', tab)) != std::string::npos) {
        value.replace(tab, 1, "    ");
        tab += 4;
    }
    return value;
}

std::vector<std::string> splitTableRow(const std::string& line) {
    std::string body = trim(line);
    if (!body.empty() && body.front() == '|') {
        body.erase(body.begin());
    }
    if (!body.empty() && body.back() == '|') {
        body.pop_back();
    }

    std::vector<std::string> cells;
    std::string cell;
    bool escaped = false;
    for (char c : body) {
        if (c == '|' && !escaped) {
            cells.push_back(visibleMarkdownCell(trim(cell)));
            cell.clear();
        } else {
            cell += c;
        }
        escaped = c == '\\' && !escaped;
        if (c != '\\') {
            escaped = false;
        }
    }
    cells.push_back(visibleMarkdownCell(trim(cell)));
    return cells;
}

bool isSeparatorCell(const std::string& cell) {
    std::string value = trim(cell);
    if (!value.empty() && value.front() == ':') {
        value.erase(value.begin());
    }
    if (!value.empty() && value.back() == ':') {
        value.pop_back();
    }
    return value.size() >= 3 &&
           std::all_of(value.begin(), value.end(), [](char c) { return c == '-'; });
}

bool isSeparatorRow(const std::string& line) {
    const auto cells = splitTableRow(line);
    return !cells.empty() &&
           std::all_of(cells.begin(), cells.end(), isSeparatorCell);
}

std::string padCell(const std::string& cell, std::size_t width) {
    const std::size_t current = terminalDisplayWidth(cell);
    return cell + std::string(width > current ? width - current : 0, ' ');
}

std::vector<std::string> wrapCell(const std::string& cell, std::size_t width) {
    if (cell.empty()) {
        return {""};
    }

    std::vector<std::string> lines;
    std::string current;
    for (std::size_t offset = 0; offset < cell.size();) {
        const unsigned char first = static_cast<unsigned char>(cell[offset]);
        std::size_t length = 1;
        if ((first & 0xE0) == 0xC0) length = 2;
        else if ((first & 0xF0) == 0xE0) length = 3;
        else if ((first & 0xF8) == 0xF0) length = 4;
        length = std::min(length, cell.size() - offset);

        const std::string character = cell.substr(offset, length);
        const std::string candidate = current + character;
        if (!current.empty() && terminalDisplayWidth(candidate) > width) {
            lines.push_back(current);
            current = character;
        } else {
            current = candidate;
        }
        offset += length;
    }
    if (!current.empty()) {
        lines.push_back(current);
    }
    return lines;
}

std::string tableBorder(
    const std::vector<std::size_t>& widths,
    const std::string& left,
    const std::string& middle,
    const std::string& right
) {
    std::ostringstream output;
    output << left;
    for (std::size_t column = 0; column < widths.size(); ++column) {
        for (std::size_t index = 0; index < widths[column]; ++index) {
            output << "─";
        }
        if (column + 1 < widths.size()) {
            output << middle;
        }
    }
    output << right;
    return output.str();
}

std::string renderTable(
    const std::vector<std::string>& lines,
    std::size_t max_width
) {
    std::vector<std::vector<std::string>> rows;
    std::size_t column_count = 0;
    for (const auto& line : lines) {
        rows.push_back(splitTableRow(line));
        column_count = std::max(column_count, rows.back().size());
    }

    std::vector<std::size_t> widths(column_count, 3);
    for (std::size_t row = 0; row < rows.size(); ++row) {
        if (row == 1 && isSeparatorRow(lines[row])) {
            continue;
        }
        for (std::size_t column = 0; column < rows[row].size(); ++column) {
            widths[column] = std::max(
                widths[column], terminalDisplayWidth(rows[row][column])
            );
        }
    }

    const std::size_t border_width = column_count + 1;
    const std::size_t natural_width =
        border_width +
        std::accumulate(widths.begin(), widths.end(), std::size_t{0});
    if (max_width > border_width + column_count * 3 &&
        natural_width > max_width) {
        const std::size_t available = max_width - border_width;
        std::vector<std::size_t> constrained(column_count, 3);
        std::size_t remaining = available - column_count * 3;
        while (remaining > 0) {
            bool assigned = false;
            for (std::size_t column = 0;
                 column < column_count && remaining > 0;
                 ++column) {
                if (constrained[column] < widths[column]) {
                    ++constrained[column];
                    --remaining;
                    assigned = true;
                }
            }
            if (!assigned) break;
        }
        widths = std::move(constrained);
    }

    // The Markdown separator row controls alignment but is not rendered as
    // content. Terminal tables use connected box-drawing borders without
    // extra left/right cell margins.
    std::vector<std::vector<std::string>> content_rows;
    for (std::size_t row = 0; row < rows.size(); ++row) {
        if (row != 1 || !isSeparatorRow(lines[row])) {
            content_rows.push_back(rows[row]);
        }
    }

    std::ostringstream output;
    output << tableBorder(widths, "┌", "┬", "┐") << '\n';
    for (std::size_t row = 0; row < content_rows.size(); ++row) {
        std::vector<std::vector<std::string>> wrapped(column_count);
        std::size_t row_height = 1;
        for (std::size_t column = 0; column < column_count; ++column) {
            const std::string cell =
                column < content_rows[row].size() ? content_rows[row][column] : "";
            wrapped[column] = wrapCell(cell, widths[column]);
            row_height = std::max(row_height, wrapped[column].size());
        }
        for (std::size_t physical_row = 0;
             physical_row < row_height;
             ++physical_row) {
            output << "│";
            for (std::size_t column = 0; column < column_count; ++column) {
                const std::string fragment =
                    physical_row < wrapped[column].size()
                    ? wrapped[column][physical_row]
                    : "";
                output << padCell(fragment, widths[column]) << "│";
            }
            output << '\n';
        }
        if (row + 1 < content_rows.size()) {
            output << tableBorder(widths, "├", "┼", "┤") << '\n';
        } else {
            output << tableBorder(widths, "└", "┴", "┘");
        }
    }
    return output.str();
}

} // namespace

std::size_t terminalDisplayWidth(const std::string& text) {
    std::mbstate_t state{};
    std::size_t width = 0;
    const char* current = text.data();
    std::size_t remaining = text.size();
    while (remaining > 0) {
        if (remaining >= 2 && current[0] == '\033' && current[1] == '[') {
            current += 2;
            remaining -= 2;
            while (remaining > 0) {
                const unsigned char c = static_cast<unsigned char>(*current);
                ++current;
                --remaining;
                if (c >= 0x40 && c <= 0x7E) {
                    break;
                }
            }
            continue;
        }
        if (remaining >= 2 && current[0] == '\033' && current[1] == ']') {
            current += 2;
            remaining -= 2;
            while (remaining > 0) {
                if (*current == '\a') {
                    ++current;
                    --remaining;
                    break;
                }
                if (remaining >= 2 && current[0] == '\033' && current[1] == '\\') {
                    current += 2;
                    remaining -= 2;
                    break;
                }
                ++current;
                --remaining;
            }
            continue;
        }

        wchar_t character = 0;
        const std::size_t consumed = std::mbrtowc(
            &character, current, remaining, &state
        );
        if (consumed == static_cast<std::size_t>(-1) ||
            consumed == static_cast<std::size_t>(-2)) {
            state = std::mbstate_t{};
            ++current;
            --remaining;
            ++width;
            continue;
        }
        if (consumed == 0) {
            break;
        }
        int character_width = ::wcwidth(character);
        bool joined_emoji = false;
        bool regional_pair = false;
        current += consumed;
        remaining -= consumed;

        if (character >= 0x1F1E6 && character <= 0x1F1FF && remaining > 0) {
            std::mbstate_t regional_state = state;
            wchar_t regional = 0;
            const std::size_t regional_size = std::mbrtowc(
                &regional, current, remaining, &regional_state
            );
            if (regional_size != static_cast<std::size_t>(-1) &&
                regional_size != static_cast<std::size_t>(-2) &&
                regional_size != 0 &&
                regional >= 0x1F1E6 && regional <= 0x1F1FF) {
                regional_pair = true;
                state = regional_state;
                current += regional_size;
                remaining -= regional_size;
            }
        }

        // A zero-width joiner combines multiple emoji codepoints into one
        // terminal glyph. Consume the complete cluster and count it as two
        // columns rather than summing every component.
        while (remaining > 0) {
            std::mbstate_t lookahead_state = state;
            wchar_t next = 0;
            const std::size_t next_size = std::mbrtowc(
                &next, current, remaining, &lookahead_state
            );
            if (next_size == static_cast<std::size_t>(-1) ||
                next_size == static_cast<std::size_t>(-2) ||
                next_size == 0) {
                break;
            }
            const bool modifier =
                (next >= 0xFE00 && next <= 0xFE0F) ||
                (next >= 0x1F3FB && next <= 0x1F3FF);
            if (modifier) {
                state = lookahead_state;
                current += next_size;
                remaining -= next_size;
                continue;
            }
            if (next != 0x200D) {
                break;
            }
            joined_emoji = true;
            state = lookahead_state;
            current += next_size;
            remaining -= next_size;
            if (remaining == 0) {
                break;
            }
            wchar_t joined = 0;
            const std::size_t joined_size = std::mbrtowc(
                &joined, current, remaining, &state
            );
            if (joined_size == static_cast<std::size_t>(-1) ||
                joined_size == static_cast<std::size_t>(-2) ||
                joined_size == 0) {
                break;
            }
            current += joined_size;
            remaining -= joined_size;
        }
        width += (joined_emoji || regional_pair)
            ? 2
            : (character_width > 0 ? static_cast<std::size_t>(character_width) : 0);
    }
    return width;
}

std::string formatMarkdownTables(
    const std::string& text,
    std::size_t max_width
) {
    std::vector<std::string> lines;
    std::istringstream input(text);
    std::string line;
    while (std::getline(input, line)) {
        lines.push_back(line);
    }

    std::ostringstream output;
    for (std::size_t index = 0; index < lines.size();) {
        if (index + 1 < lines.size() &&
            lines[index].find('|') != std::string::npos &&
            isSeparatorRow(lines[index + 1])) {
            std::vector<std::string> table = {lines[index], lines[index + 1]};
            index += 2;
            while (index < lines.size() &&
                   lines[index].find('|') != std::string::npos &&
                   !trim(lines[index]).empty()) {
                table.push_back(lines[index++]);
            }
            output << renderTable(table, max_width);
        } else {
            output << lines[index++];
        }
        if (index < lines.size()) {
            output << '\n';
        }
    }
    if (!text.empty() && text.back() == '\n') {
        output << '\n';
    }
    return output.str();
}

} // namespace opencode
